module example.invalid/no-docs

go 1.26.9
