package sample
func Consensus()int{return 1}
