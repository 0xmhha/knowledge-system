package common

// SharedConsensus returns an owned test marker.
func SharedConsensus() int { return 808 }
