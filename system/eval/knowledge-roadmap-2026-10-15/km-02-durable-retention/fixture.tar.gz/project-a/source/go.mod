module example.invalid/common

go 1.26.9
