package common
// SharedConsensus returns an owned marker.
func SharedConsensus() int { return 1001 }
