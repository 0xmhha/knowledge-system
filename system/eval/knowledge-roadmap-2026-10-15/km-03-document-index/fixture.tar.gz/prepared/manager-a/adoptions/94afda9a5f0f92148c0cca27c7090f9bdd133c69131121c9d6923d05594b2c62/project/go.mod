module example.invalid/same-project

go 1.26.9
