# Proposed source observations

Review status: proposed. Human approval: not recorded. Design rationale is not inferred.

Project: project-9093700b4fbf4621a5570e070d95536f
Collection: 44dccf5f8370b3b12fb75be5507f537aac7e03ef979da0c5aa4950ad5bda9faa

## 8e105d1c957fde33b8cb6d7d80ba7551118e9df3b034394a325e1c4dff5baf20

Kind: observed_excerpt

Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "go.mod", "start_line": 1, "end_line": 3, "file_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d", "content_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    module example.invalid/actual-host
    
    go 1.26.9

## 9b37cd5c134f0cc269c4b256896129f79ca278d419b73d0853c3c2b2427e19b0

Kind: observed_excerpt

Recorded source excerpt from value.go; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "value.go", "start_line": 1, "end_line": 4, "file_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09", "content_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

