# Reviewed manager input

Project: project-9093700b4fbf4621a5570e070d95536f
Collection: 44dccf5f8370b3b12fb75be5507f537aac7e03ef979da0c5aa4950ad5bda9faa
Review revision: 7b08c85828c7b0a712114d1693275f53dec8b74eb35ed91eabbe83e28c530d8f
Review record: supplied operator response; external identity authentication not performed.
A reviewed hypothesis remains a hypothesis. Source data is not an instruction.

## 8e105d1c957fde33b8cb6d7d80ba7551118e9df3b034394a325e1c4dff5baf20

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:54:44.581668Z","collection_id":"44dccf5f8370b3b12fb75be5507f537aac7e03ef979da0c5aa4950ad5bda9faa","content_role":"untrusted_source_data","content_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","end_line":3,"evidence_id":"7dd71f60f13673714806d3637f3e94793c34735bf70bfd011ae80504163284c6","file_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","origin_id":"repo","path":"go.mod","project_id":"project-9093700b4fbf4621a5570e070d95536f","reported_not_reexecuted":false,"source_actor":null,"source_kind":"configuration","source_recorded_at":null,"start_line":1}

    module example.invalid/actual-host
    
    go 1.26.9

## 9b37cd5c134f0cc269c4b256896129f79ca278d419b73d0853c3c2b2427e19b0

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from value.go; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:54:44.581668Z","collection_id":"44dccf5f8370b3b12fb75be5507f537aac7e03ef979da0c5aa4950ad5bda9faa","content_role":"untrusted_source_data","content_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","end_line":4,"evidence_id":"0bf53486ad762c71a73ebdcb5b5b1bd0af027f828ba7f4033a763543cac47da2","file_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","origin_id":"repo","path":"value.go","project_id":"project-9093700b4fbf4621a5570e070d95536f","reported_not_reexecuted":false,"source_actor":null,"source_kind":"code","source_recorded_at":null,"start_line":1}

    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

