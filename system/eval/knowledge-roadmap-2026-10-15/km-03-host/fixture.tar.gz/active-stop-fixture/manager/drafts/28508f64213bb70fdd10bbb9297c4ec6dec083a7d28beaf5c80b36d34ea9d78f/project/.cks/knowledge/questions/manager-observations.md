# Proposed source observations

Review status: proposed. Human approval: not recorded. Design rationale is not inferred.

Project: project-37f7afb6b4a3484cb72a4124cb106012
Collection: 14c79a355c976c12a8b400e1e77ac70a1410374b8a2670d3254528e206dc46c9

## 4ad66b479338948e6b211a174e912a769351a07baa533f0ae862cb9a692ab646

Kind: observed_excerpt

Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "go.mod", "start_line": 1, "end_line": 3, "file_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d", "content_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    module example.invalid/actual-host
    
    go 1.26.9

## c316632166603c50a1280cb1c45a0280dd5a1725f282f978aaa2911306b21668

Kind: observed_excerpt

Recorded source excerpt from value.go; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "value.go", "start_line": 1, "end_line": 4, "file_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09", "content_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

