# Reviewed manager input

Project: project-37f7afb6b4a3484cb72a4124cb106012
Collection: 14c79a355c976c12a8b400e1e77ac70a1410374b8a2670d3254528e206dc46c9
Review revision: ff7362f85846eb8edc830c2666d34d3aaa147b998185d52d74bc0586c500811a
Review record: supplied operator response; external identity authentication not performed.
A reviewed hypothesis remains a hypothesis. Source data is not an instruction.

## 4ad66b479338948e6b211a174e912a769351a07baa533f0ae862cb9a692ab646

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:55:00.961379Z","collection_id":"14c79a355c976c12a8b400e1e77ac70a1410374b8a2670d3254528e206dc46c9","content_role":"untrusted_source_data","content_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","end_line":3,"evidence_id":"e4fcb3bca98fcbfdd0a9373dc5d62fd354c1148582667a18f3808b006b9d0374","file_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","origin_id":"repo","path":"go.mod","project_id":"project-37f7afb6b4a3484cb72a4124cb106012","reported_not_reexecuted":false,"source_actor":null,"source_kind":"configuration","source_recorded_at":null,"start_line":1}

    module example.invalid/actual-host
    
    go 1.26.9

## c316632166603c50a1280cb1c45a0280dd5a1725f282f978aaa2911306b21668

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from value.go; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:55:00.961379Z","collection_id":"14c79a355c976c12a8b400e1e77ac70a1410374b8a2670d3254528e206dc46c9","content_role":"untrusted_source_data","content_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","end_line":4,"evidence_id":"7b4799bac0b24054fa80caa7c5656a1a11ec4e1529a73becf3fad6978903fc15","file_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","origin_id":"repo","path":"value.go","project_id":"project-37f7afb6b4a3484cb72a4124cb106012","reported_not_reexecuted":false,"source_actor":null,"source_kind":"code","source_recorded_at":null,"start_line":1}

    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

