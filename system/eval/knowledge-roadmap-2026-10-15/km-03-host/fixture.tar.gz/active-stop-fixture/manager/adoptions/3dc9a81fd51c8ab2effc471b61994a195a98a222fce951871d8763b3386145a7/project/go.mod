module example.invalid/actual-host

go 1.26.9
