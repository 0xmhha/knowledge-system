package fixture

// HostValue returns the owned fixture marker.
func HostValue() int { return 42 }
