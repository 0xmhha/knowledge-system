# Proposed source observations

Review status: proposed. Human approval: not recorded. Design rationale is not inferred.

Project: project-9152b9d3fd524a07bb648ac3cafb7e2d
Collection: 22963a66dc3b6d7e98599cd721c858ab9ad3dfd2fa18cf2d5ca275018b72f0eb

## 53599b2d40d702a5afcd4415af5f7efc64cb5b0fd94a0e1e863e77eeff3ff591

Kind: observed_excerpt

Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "go.mod", "start_line": 1, "end_line": 3, "file_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d", "content_sha256": "2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    module example.invalid/actual-host
    
    go 1.26.9

## e20d7d88d9c749ae6bc5474eef8a8956e67b952936d39b5e41441da1bdd3a84d

Kind: observed_excerpt

Recorded source excerpt from value.go; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "value.go", "start_line": 1, "end_line": 4, "file_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09", "content_sha256": "5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

