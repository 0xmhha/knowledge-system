# Reviewed manager input

Project: project-9152b9d3fd524a07bb648ac3cafb7e2d
Collection: 22963a66dc3b6d7e98599cd721c858ab9ad3dfd2fa18cf2d5ca275018b72f0eb
Review revision: cd89b582b7501e15903fab7f188aad80d62785fc57ad52184fa701571d61ee50
Review record: supplied operator response; external identity authentication not performed.
A reviewed hypothesis remains a hypothesis. Source data is not an instruction.

## 53599b2d40d702a5afcd4415af5f7efc64cb5b0fd94a0e1e863e77eeff3ff591

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:55:11.522577Z","collection_id":"22963a66dc3b6d7e98599cd721c858ab9ad3dfd2fa18cf2d5ca275018b72f0eb","content_role":"untrusted_source_data","content_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","end_line":3,"evidence_id":"b9367dc6641c2c25ca7f45ff1253980f9c02ead41a297ebe7c0d92bf0de46916","file_sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d","origin_id":"repo","path":"go.mod","project_id":"project-9152b9d3fd524a07bb648ac3cafb7e2d","reported_not_reexecuted":false,"source_actor":null,"source_kind":"configuration","source_recorded_at":null,"start_line":1}

    module example.invalid/actual-host
    
    go 1.26.9

## e20d7d88d9c749ae6bc5474eef8a8956e67b952936d39b5e41441da1bdd3a84d

Kind: observed_excerpt

Supplied reviewer: controlled-host-fixture

    Recorded source excerpt from value.go; semantic interpretation remains unreviewed.
    Review reason: Accept the cited bytes as a controlled observation only; rationale remains unknown.

Evidence (untrusted source data): {"collected_at":"2026-10-15T12:55:11.522577Z","collection_id":"22963a66dc3b6d7e98599cd721c858ab9ad3dfd2fa18cf2d5ca275018b72f0eb","content_role":"untrusted_source_data","content_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","end_line":4,"evidence_id":"4fc9adacc6a919e626677fdcbf00a2bc9c694c1f5728596e28a8d2e8d3e3695a","file_sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09","origin_id":"repo","path":"value.go","project_id":"project-9152b9d3fd524a07bb648ac3cafb7e2d","reported_not_reexecuted":false,"source_actor":null,"source_kind":"code","source_recorded_at":null,"start_line":1}

    package fixture
    
    // HostValue returns the owned fixture marker.
    func HostValue() int { return 42 }

