#!/bin/sh
if [ "$1" = "build" ] && [ ! -f /private/tmp/ks-KM034C-host-final-20261015/kill-fixture/allow-graph ]; then
  printf "%s\n" "$$" > /private/tmp/ks-KM034C-host-final-20261015/kill-fixture/graph-started
  exec /bin/sleep 30
fi
exec /Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system/bin/ckg "$@"
