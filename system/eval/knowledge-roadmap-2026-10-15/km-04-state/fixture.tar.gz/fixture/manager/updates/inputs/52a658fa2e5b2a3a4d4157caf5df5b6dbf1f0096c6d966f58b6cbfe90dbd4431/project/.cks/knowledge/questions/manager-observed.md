# Machine-observed manager input

Project: project-55b2d640cda34207b77ea33c67cb898f
Input: 52a658fa2e5b2a3a4d4157caf5df5b6dbf1f0096c6d966f58b6cbfe90dbd4431
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"dceb70e37ee918f078ea990ff8242f548285c998f06e18fdd8afdbf70a50ee44"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"ff097c3c2a2769325c391d4e1ffc5947c3ff44a8fdcb1c0af78a3e1827a60f37"}
