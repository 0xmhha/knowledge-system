module example.invalid/manager-state

go 1.26.9
