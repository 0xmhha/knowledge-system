package common

// SharedConsensus returns the fixture marker.
func SharedConsensus() int { return 101 }
