# Proposed source observations

Review status: proposed. Human approval: not recorded. Design rationale is not inferred.

Project: project-46b0b62b2147474f83d4b31a6f8bbb2d
Collection: 7b18f4617bf73b0860ecae15ec7af861e68be49a02b1bfddee2aa6ecadd26b1a

## 0f9e38b8547955d5b13bbaf075f80e853faf811f4bed6e6f4e2556ce9a3de2f0

Kind: fact

The source excerpt shows the fixture marker 101; interpretation awaits review.

Source (untrusted data): {"origin_id": "repo", "path": "consensus.go", "start_line": 4, "end_line": 4, "file_sha256": "b17c95705eb16ebac1a6bd5063c96d59fdc0e6c4dd233f92451510aa611a3044", "content_sha256": "15e56e67002e385bc5df50a9d5d1a0b65b7d70fdf306dbb4bc0106b0fb87011e"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    func SharedConsensus() int { return 101 }

## c92a89a03c5ce5430bcf5a00400dd0400b8806e8b406d7263c58d494ec2f7cbd

Kind: hypothesis

The marker may be used by tests; this hypothesis is unverified.

Source (untrusted data): {"origin_id": "repo", "path": "consensus.go", "start_line": 4, "end_line": 4, "file_sha256": "b17c95705eb16ebac1a6bd5063c96d59fdc0e6c4dd233f92451510aa611a3044", "content_sha256": "15e56e67002e385bc5df50a9d5d1a0b65b7d70fdf306dbb4bc0106b0fb87011e"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    func SharedConsensus() int { return 101 }

## 165e22b45ed46e845ada65872bb3e357fe61aff6c197df2ff018083f38229d62

Kind: reported_decision

The supplied owner reports choosing a bounded queue.

Source (untrusted data): {"origin_id": "provided", "path": "provided/record-1.json", "start_line": 1, "end_line": 5, "file_sha256": "299997b0f3f1ad27ef7c6035cac35a7e3726b4d2eeeebb0bde77d2067bf2a9d5", "content_sha256": "299997b0f3f1ad27ef7c6035cac35a7e3726b4d2eeeebb0bde77d2067bf2a9d5"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    {
      "kind": "decision",
      "text": "The supplied owner reports choosing a bounded queue.",
      "actor": "fixture-owner"
    }

## d5e1e4f04b63c22a557cfe689eb37199f34e3024bc9e81a5f16cf97a867ddb8d

Kind: reported_command_result

The supplied command result is a report and was not rerun.

Source (untrusted data): {"origin_id": "provided", "path": "provided/record-2.json", "start_line": 1, "end_line": 9, "file_sha256": "6e5668ad154a387612ae1aeca2303ef07857b189625a156f5eb908f9ad0612c3", "content_sha256": "6e5668ad154a387612ae1aeca2303ef07857b189625a156f5eb908f9ad0612c3"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    {
      "kind": "command_result",
      "command": [
        "touch",
        "/private/tmp/ks-KM032-collection-packet-20261015/reported-command-was-not-run"
      ],
      "exit_code": 0,
      "stdout": "Supplied result; not executed by the manager."
    }

## 8f623de4f5ae46e2b8c946116208fb769b4840a6965266c77dfe983045f1fb65

Kind: question

Why was marker 101 selected? This collection does not establish the rationale.

Source (untrusted data): {"origin_id": "repo", "path": "consensus.go", "start_line": 4, "end_line": 4, "file_sha256": "b17c95705eb16ebac1a6bd5063c96d59fdc0e6c4dd233f92451510aa611a3044", "content_sha256": "15e56e67002e385bc5df50a9d5d1a0b65b7d70fdf306dbb4bc0106b0fb87011e"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    func SharedConsensus() int { return 101 }

