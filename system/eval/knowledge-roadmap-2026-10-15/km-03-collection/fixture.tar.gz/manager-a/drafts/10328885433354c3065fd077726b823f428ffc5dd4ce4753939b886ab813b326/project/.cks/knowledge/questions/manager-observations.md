# Proposed source observations

Review status: proposed. Human approval: not recorded. Design rationale is not inferred.

Project: project-46b0b62b2147474f83d4b31a6f8bbb2d
Collection: 7b18f4617bf73b0860ecae15ec7af861e68be49a02b1bfddee2aa6ecadd26b1a

## b35816aca65eca3f9b5cec1f3e96996b31b58517dc38c0821445ac5b2cd1c67b

Kind: reported_decision

Recorded source excerpt from provided/record-1.json; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "provided", "path": "provided/record-1.json", "start_line": 1, "end_line": 5, "file_sha256": "299997b0f3f1ad27ef7c6035cac35a7e3726b4d2eeeebb0bde77d2067bf2a9d5", "content_sha256": "299997b0f3f1ad27ef7c6035cac35a7e3726b4d2eeeebb0bde77d2067bf2a9d5"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    {
      "kind": "decision",
      "text": "The supplied owner reports choosing a bounded queue.",
      "actor": "fixture-owner"
    }

## f02906cb4513868a3a3c026b0b4b8eed4fa11f810af0a1eb86996863e145dea9

Kind: reported_command_result

Recorded source excerpt from provided/record-2.json; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "provided", "path": "provided/record-2.json", "start_line": 1, "end_line": 9, "file_sha256": "6e5668ad154a387612ae1aeca2303ef07857b189625a156f5eb908f9ad0612c3", "content_sha256": "6e5668ad154a387612ae1aeca2303ef07857b189625a156f5eb908f9ad0612c3"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    {
      "kind": "command_result",
      "command": [
        "touch",
        "/private/tmp/ks-KM032-collection-packet-20261015/reported-command-was-not-run"
      ],
      "exit_code": 0,
      "stdout": "Supplied result; not executed by the manager."
    }

## 59e09a043e64f6c0a4b3594931aae258489da00f49b631c18dd6f993cfac3202

Kind: observed_excerpt

Recorded source excerpt from config.json; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "config.json", "start_line": 1, "end_line": 1, "file_sha256": "e572b1d0d6e5a6eb85057a923d4d456cc3d59398776337444a577c6047ce6019", "content_sha256": "e572b1d0d6e5a6eb85057a923d4d456cc3d59398776337444a577c6047ce6019"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    {"batch_limit":64}

## e37b37af5447b1ac965d8110039e20e9d0eeb984c0d583945fe7f69439a24e07

Kind: observed_excerpt

Recorded source excerpt from consensus.go; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "consensus.go", "start_line": 1, "end_line": 4, "file_sha256": "b17c95705eb16ebac1a6bd5063c96d59fdc0e6c4dd233f92451510aa611a3044", "content_sha256": "b17c95705eb16ebac1a6bd5063c96d59fdc0e6c4dd233f92451510aa611a3044"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    package common
    
    // SharedConsensus returns the fixture marker.
    func SharedConsensus() int { return 101 }

## cc1d46cece7f88d22ae4347ad1173eeb35c3b4bbdd4ffbc63982a07fa826a4f8

Kind: observed_excerpt

Recorded source excerpt from go.mod; semantic interpretation remains unreviewed.

Source (untrusted data): {"origin_id": "repo", "path": "go.mod", "start_line": 1, "end_line": 3, "file_sha256": "546aa8f3c7aa19327ce9f8086e71b3a1e3c22c90bfa8db7d35ee7f63ab37917a", "content_sha256": "546aa8f3c7aa19327ce9f8086e71b3a1e3c22c90bfa8db7d35ee7f63ab37917a"}

Quoted preview may be truncated; the evidence hash covers the complete recorded line span.
    module example.invalid/same-fork
    
    go 1.26.9

