package common

// SharedConsensus returns a changed fixture marker.
func SharedConsensus() int { return 303 }
