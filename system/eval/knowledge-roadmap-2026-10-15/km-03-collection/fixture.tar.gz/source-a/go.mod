module example.invalid/same-fork

go 1.26.9
