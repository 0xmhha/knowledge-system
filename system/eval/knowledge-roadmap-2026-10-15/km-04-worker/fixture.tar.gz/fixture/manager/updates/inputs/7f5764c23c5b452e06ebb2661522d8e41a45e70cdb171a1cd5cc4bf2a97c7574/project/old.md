Old public design observation.
