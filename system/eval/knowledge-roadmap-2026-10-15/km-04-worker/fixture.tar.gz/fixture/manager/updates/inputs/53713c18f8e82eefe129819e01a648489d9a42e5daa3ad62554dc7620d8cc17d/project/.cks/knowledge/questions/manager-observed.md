# Machine-observed manager input

Project: project-b486315fcf7a4899863a3cf4b1024297
Input: 53713c18f8e82eefe129819e01a648489d9a42e5daa3ad62554dc7620d8cc17d
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"fce6ed7c555c7efb9846fef7402757dd92ad184ba9114e8dac3e5cb8c3cfa4b0"}
    {"bytes":43,"kind":"code","origin_id":"repo","path":"value.go","sha256":"d91920a7ec49b2ff25569939b9de5a97253a1e5acf6201abfe70262eb9f3ea3f"}
