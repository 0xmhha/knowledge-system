# Machine-observed manager input

Project: project-b486315fcf7a4899863a3cf4b1024297
Input: 7f5764c23c5b452e06ebb2661522d8e41a45e70cdb171a1cd5cc4bf2a97c7574
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"fce6ed7c555c7efb9846fef7402757dd92ad184ba9114e8dac3e5cb8c3cfa4b0"}
    {"bytes":31,"kind":"documentation","origin_id":"repo","path":"old.md","sha256":"39d183d7eb4fa81053b5cb422735a0dbbf3bf9936934a683e28ef4f16ea51d83"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"ff097c3c2a2769325c391d4e1ffc5947c3ff44a8fdcb1c0af78a3e1827a60f37"}
