# Machine-observed manager input

Project: project-b486315fcf7a4899863a3cf4b1024297
Input: 6486f5796e1de981af3175e9df7cb8fb64887aedb4535d94b9bd80b54bf5a344
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"fce6ed7c555c7efb9846fef7402757dd92ad184ba9114e8dac3e5cb8c3cfa4b0"}
    {"bytes":43,"kind":"code","origin_id":"repo","path":"value.go","sha256":"c8499017091b40a413f6e72d892cdc940475ab4fb944b48105103a3f3281c467"}
