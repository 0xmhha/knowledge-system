# Machine-observed manager input

Project: project-b486315fcf7a4899863a3cf4b1024297
Input: 1f7f2fc47b9ddc86a62ca274298f962530419aeb0068fc09ce697f8cf7178860
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"fce6ed7c555c7efb9846fef7402757dd92ad184ba9114e8dac3e5cb8c3cfa4b0"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"6226b712c49b7a9e5047df3dc2fddaaefe314b3c74c353a426393b9a28e5c265"}
