package fixture
func Value()int{return 11}
