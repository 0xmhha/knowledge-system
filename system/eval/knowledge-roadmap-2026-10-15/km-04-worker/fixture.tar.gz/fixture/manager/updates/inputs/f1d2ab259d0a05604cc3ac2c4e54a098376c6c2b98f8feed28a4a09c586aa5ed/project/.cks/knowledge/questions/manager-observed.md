# Machine-observed manager input

Project: project-b486315fcf7a4899863a3cf4b1024297
Input: f1d2ab259d0a05604cc3ac2c4e54a098376c6c2b98f8feed28a4a09c586aa5ed
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":48,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"fce6ed7c555c7efb9846fef7402757dd92ad184ba9114e8dac3e5cb8c3cfa4b0"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"29df1476c945c64a202e95893ad13c1966641e704a1fc0708480ca5852f588e4"}
