module example.invalid/update-worker

go 1.26.9
