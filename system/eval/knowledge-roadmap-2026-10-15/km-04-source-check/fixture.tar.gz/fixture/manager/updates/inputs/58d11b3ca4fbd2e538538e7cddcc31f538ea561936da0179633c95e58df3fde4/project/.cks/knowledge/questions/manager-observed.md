# Machine-observed manager input

Project: project-c1a7bd625d244e33949c293d88675dfc
Input: 58d11b3ca4fbd2e538538e7cddcc31f538ea561936da0179633c95e58df3fde4
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":47,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"a1aeabf4c0132b0c8d229f558b728ace3b393e14e38843768ff7346dd856b0b8"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"29df1476c945c64a202e95893ad13c1966641e704a1fc0708480ca5852f588e4"}
