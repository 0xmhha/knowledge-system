# Machine-observed manager input

Project: project-c1a7bd625d244e33949c293d88675dfc
Input: 608a495257687dc5a92e4908dce3b1eb8b23e37eb5d9256a2cdf05aa95a4ba4f
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":47,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"a1aeabf4c0132b0c8d229f558b728ace3b393e14e38843768ff7346dd856b0b8"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"6226b712c49b7a9e5047df3dc2fddaaefe314b3c74c353a426393b9a28e5c265"}
