module example.invalid/source-check

go 1.26.9
