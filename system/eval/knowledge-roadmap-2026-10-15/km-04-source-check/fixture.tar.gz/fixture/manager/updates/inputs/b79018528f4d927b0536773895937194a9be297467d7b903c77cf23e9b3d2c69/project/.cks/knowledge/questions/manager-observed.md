# Machine-observed manager input

Project: project-c1a7bd625d244e33949c293d88675dfc
Input: b79018528f4d927b0536773895937194a9be297467d7b903c77cf23e9b3d2c69
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":47,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"a1aeabf4c0132b0c8d229f558b728ace3b393e14e38843768ff7346dd856b0b8"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"ff097c3c2a2769325c391d4e1ffc5947c3ff44a8fdcb1c0af78a3e1827a60f37"}
