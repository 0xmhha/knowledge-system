package common
// SharedConsensus is the recovery marker.
func SharedConsensus() int { return 3003 }
