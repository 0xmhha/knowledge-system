# Machine-observed manager input

Project: project-e5f94a1f221f4739a3aa3cdcd26757ca
Input: 03698a552dded0f9adb97287bce0929f5fb71f2d2a9c4029babf9989af84be3e
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":78,"kind":"documentation","origin_id":"material:terms","path":"terms.md","sha256":"956c1b691bc087e5e2491320adcd8d58d21880a4fdc9c9ed6c68fdcbce50000b"}
    {"bytes":43,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"897c8e7cd3cf8b2ac828eb595bd04a1a3a084c9aaec8a554f6adfff0ad600c99"}
    {"bytes":48,"kind":"code","origin_id":"repo","path":"value.go","sha256":"d948fc4d699bf99f9b0d9be705256e2b8198b8291a0f6664f771061243c49b33"}
