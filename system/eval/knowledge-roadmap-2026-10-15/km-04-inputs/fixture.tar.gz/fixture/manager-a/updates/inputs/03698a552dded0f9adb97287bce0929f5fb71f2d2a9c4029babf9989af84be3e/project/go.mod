module example.invalid/observed

go 1.26.9
