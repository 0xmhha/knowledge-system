# Machine-observed manager input

Project: project-e5f94a1f221f4739a3aa3cdcd26757ca
Input: 2a4cb9b5d484753a7fbcf9a872618997667294e00bb8f169e7c9327b4a779c31
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":43,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"897c8e7cd3cf8b2ac828eb595bd04a1a3a084c9aaec8a554f6adfff0ad600c99"}
    {"bytes":48,"kind":"code","origin_id":"repo","path":"renamed.go","sha256":"f1f83634651b7eebbf7e47fcb5cc8641996a3c4fe965d2af4aa99fe29e10c6ac"}
