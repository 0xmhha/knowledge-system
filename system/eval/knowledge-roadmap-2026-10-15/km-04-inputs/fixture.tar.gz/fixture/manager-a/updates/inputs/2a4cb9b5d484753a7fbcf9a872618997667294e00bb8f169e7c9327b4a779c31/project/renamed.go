package observed

func Value() int { return 8 }
