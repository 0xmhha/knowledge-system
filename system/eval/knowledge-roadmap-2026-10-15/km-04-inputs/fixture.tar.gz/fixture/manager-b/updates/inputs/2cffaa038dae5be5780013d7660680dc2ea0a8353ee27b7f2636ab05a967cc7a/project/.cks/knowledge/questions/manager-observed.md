# Machine-observed manager input

Project: project-0b4d34c30d544412951865a9e90609f5
Input: 2cffaa038dae5be5780013d7660680dc2ea0a8353ee27b7f2636ab05a967cc7a
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":43,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"897c8e7cd3cf8b2ac828eb595bd04a1a3a084c9aaec8a554f6adfff0ad600c99"}
    {"bytes":48,"kind":"code","origin_id":"repo","path":"value.go","sha256":"d948fc4d699bf99f9b0d9be705256e2b8198b8291a0f6664f771061243c49b33"}
