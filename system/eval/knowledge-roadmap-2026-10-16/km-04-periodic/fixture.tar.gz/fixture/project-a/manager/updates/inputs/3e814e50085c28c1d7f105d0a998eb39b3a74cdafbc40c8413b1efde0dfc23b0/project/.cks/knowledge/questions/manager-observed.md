# Machine-observed manager input

Project: project-3fd243d33cbc45c0a893e83936122c50
Input: 3e814e50085c28c1d7f105d0a998eb39b3a74cdafbc40c8413b1efde0dfc23b0
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":99,"kind":"provided_note","origin_id":"provided","path":"provided/record-1.json","sha256":"d8e236c960d3762c94b6860f052c228fbc5707663c42b03df2903675c383d694"}
    {"bytes":50,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"d4b36a2554ad52b8278c7dab5fdca6f8b3d74bfbc3cd86059b4335b01f201e57"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"6226b712c49b7a9e5047df3dc2fddaaefe314b3c74c353a426393b9a28e5c265"}
