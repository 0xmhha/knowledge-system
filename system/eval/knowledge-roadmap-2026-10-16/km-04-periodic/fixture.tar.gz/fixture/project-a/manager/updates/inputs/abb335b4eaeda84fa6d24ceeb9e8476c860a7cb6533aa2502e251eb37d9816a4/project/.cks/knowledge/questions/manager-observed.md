# Machine-observed manager input

Project: project-3fd243d33cbc45c0a893e83936122c50
Input: abb335b4eaeda84fa6d24ceeb9e8476c860a7cb6533aa2502e251eb37d9816a4
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":49,"kind":"configuration","origin_id":"material:terms","path":"terms.yaml","sha256":"d3d9f4b6b0280280fc8fa451145cb3cb113a90c85174f6543e3418eb56cebc31"}
    {"bytes":99,"kind":"provided_note","origin_id":"provided","path":"provided/record-1.json","sha256":"b971eba6860faaae619f4e89b257c52465c09a68c4976060e4aeec012666cd23"}
    {"bytes":50,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"d4b36a2554ad52b8278c7dab5fdca6f8b3d74bfbc3cd86059b4335b01f201e57"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"29df1476c945c64a202e95893ad13c1966641e704a1fc0708480ca5852f588e4"}
