# Machine-observed manager input

Project: project-3fd243d33cbc45c0a893e83936122c50
Input: 9fcba379254afaff1bfccb640e83c0a2b350bcc2f5e8bdeb57472d6f60b34e3f
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":99,"kind":"provided_note","origin_id":"provided","path":"provided/record-1.json","sha256":"d8e236c960d3762c94b6860f052c228fbc5707663c42b03df2903675c383d694"}
    {"bytes":50,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"d4b36a2554ad52b8278c7dab5fdca6f8b3d74bfbc3cd86059b4335b01f201e57"}
    {"bytes":43,"kind":"code","origin_id":"repo","path":"value.go","sha256":"c8499017091b40a413f6e72d892cdc940475ab4fb944b48105103a3f3281c467"}
