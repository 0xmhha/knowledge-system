module example.invalid/managed-project

go 1.26.9
