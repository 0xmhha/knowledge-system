# Machine-observed manager input

Project: project-ec7d30e743374ccca2847115debf37c8
Input: c22cd5eac6568bc3e26666a2c15c5311c6efd2f7ca35b0f076c38184208bdbfe
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":50,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"d4b36a2554ad52b8278c7dab5fdca6f8b3d74bfbc3cd86059b4335b01f201e57"}
    {"bytes":44,"kind":"code","origin_id":"repo","path":"value.go","sha256":"a5bfc777916c2e4e23ac25662fd19545214cae0e625eb719166b6297cbbbbdea"}
