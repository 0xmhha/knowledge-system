module example.invalid/updates-MCP

go 1.26.9
