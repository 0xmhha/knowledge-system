Original public source note
