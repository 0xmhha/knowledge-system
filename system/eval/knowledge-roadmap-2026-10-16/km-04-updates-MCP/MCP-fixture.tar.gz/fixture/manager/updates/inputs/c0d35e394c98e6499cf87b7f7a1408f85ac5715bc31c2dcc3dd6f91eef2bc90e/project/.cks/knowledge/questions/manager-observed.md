# Machine-observed manager input

Project: project-4b8e355768074fe6afc83f6715f07bb6
Input: c0d35e394c98e6499cf87b7f7a1408f85ac5715bc31c2dcc3dd6f91eef2bc90e
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"241560b8bcfcd9353e6fd7f1d632357644baf6da3560faf4c76bf2e59b1023d5"}
    {"bytes":28,"kind":"documentation","origin_id":"repo","path":"old.md","sha256":"2ce1d4a10a853c28045eb29d6c5195fd516c8b259aae6c44626cd7d1aada36e3"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"ff097c3c2a2769325c391d4e1ffc5947c3ff44a8fdcb1c0af78a3e1827a60f37"}
