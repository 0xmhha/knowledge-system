# Machine-observed manager input

Project: project-4b8e355768074fe6afc83f6715f07bb6
Input: 2c3fcaf6b014455cbc05a0a31deeda1991281392147cf41c0812b981dc99c94f
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"241560b8bcfcd9353e6fd7f1d632357644baf6da3560faf4c76bf2e59b1023d5"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"29df1476c945c64a202e95893ad13c1966641e704a1fc0708480ca5852f588e4"}
