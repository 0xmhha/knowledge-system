# Machine-observed manager input

Project: project-4b8e355768074fe6afc83f6715f07bb6
Input: ad63db266c6ed76cce4b42800b7856dd9cf3cf5e330f1ac7dbcebe07d1059eb7
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"241560b8bcfcd9353e6fd7f1d632357644baf6da3560faf4c76bf2e59b1023d5"}
    {"bytes":43,"kind":"code","origin_id":"repo","path":"value.go","sha256":"c8499017091b40a413f6e72d892cdc940475ab4fb944b48105103a3f3281c467"}
