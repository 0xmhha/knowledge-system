# Machine-observed manager input

Project: project-4b8e355768074fe6afc83f6715f07bb6
Input: 122da3aabbde2a387d9d9d9d4213bb839c1042ad6ceaa254be52bfbb8b5229c2
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"241560b8bcfcd9353e6fd7f1d632357644baf6da3560faf4c76bf2e59b1023d5"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"6226b712c49b7a9e5047df3dc2fddaaefe314b3c74c353a426393b9a28e5c265"}
