# Machine-observed manager input

Project: project-75b57a6a024e4483abc3851fc6e9f022
Input: 2b1eb87354527105e6441b5d3b25fa3c233eacdf8b10a5077efd8f38a8da545b
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"2713b9bf1b10414bb3c75e3654969064e04c4e27f786d2078d272c99444cb31d"}
    {"bytes":99,"kind":"code","origin_id":"repo","path":"value.go","sha256":"5ca1bd13fbc9f179ec31d153b69fccedb935200b6ee7c3b0d9653c3bac7c9f09"}
