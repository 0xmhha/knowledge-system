# Machine-observed manager input

Project: project-38af52d02aaf4052aea23428e0136827
Input: d6103b7fc09defad2e32eb86df2d0a9cf6ebfa294773e32a6eead83ee991e0e3
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"7df47aadc41fabf7ac9e294f1d53798fd5906fa001dbb41eded17f8b211944a6"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"6226b712c49b7a9e5047df3dc2fddaaefe314b3c74c353a426393b9a28e5c265"}
