# Machine-observed manager input

Project: project-38af52d02aaf4052aea23428e0136827
Input: 3a336576dfad689b9cda96e8e5ef63f08d91379434cb1c95095f7a88a2023ae0
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"7df47aadc41fabf7ac9e294f1d53798fd5906fa001dbb41eded17f8b211944a6"}
    {"bytes":43,"kind":"code","origin_id":"repo","path":"value.go","sha256":"c8499017091b40a413f6e72d892cdc940475ab4fb944b48105103a3f3281c467"}
