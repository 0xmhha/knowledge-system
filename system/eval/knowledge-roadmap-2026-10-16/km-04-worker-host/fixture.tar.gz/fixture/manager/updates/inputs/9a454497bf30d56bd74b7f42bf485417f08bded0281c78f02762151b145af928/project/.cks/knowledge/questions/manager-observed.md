# Machine-observed manager input

Project: project-38af52d02aaf4052aea23428e0136827
Input: 9a454497bf30d56bd74b7f42bf485417f08bded0281c78f02762151b145af928
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"7df47aadc41fabf7ac9e294f1d53798fd5906fa001dbb41eded17f8b211944a6"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"ff097c3c2a2769325c391d4e1ffc5947c3ff44a8fdcb1c0af78a3e1827a60f37"}
