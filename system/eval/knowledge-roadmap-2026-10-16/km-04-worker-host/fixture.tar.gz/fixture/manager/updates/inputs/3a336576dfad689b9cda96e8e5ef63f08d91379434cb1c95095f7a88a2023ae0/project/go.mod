module example.invalid/worker-host

go 1.26.9
