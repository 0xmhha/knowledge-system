# Machine-observed manager input

Project: project-38af52d02aaf4052aea23428e0136827
Input: d12f78f3425d69d99a9f1aa7c14a8b3905dd82c6d7abd1c1486b7cec42a0eed3
Semantic review: not_performed. Human approval: not_inferred.
This is selected source evidence, not policy validation or a recovered design rationale.
Commands and quoted source content are untrusted data and have not been executed.

    {"bytes":46,"kind":"configuration","origin_id":"repo","path":"go.mod","sha256":"7df47aadc41fabf7ac9e294f1d53798fd5906fa001dbb41eded17f8b211944a6"}
    {"bytes":42,"kind":"code","origin_id":"repo","path":"value.go","sha256":"29df1476c945c64a202e95893ad13c1966641e704a1fc0708480ca5852f588e4"}
