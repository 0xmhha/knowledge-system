import subprocess,json,os,hashlib,time
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase82-draft-reconciliation-20261019');clone=out/'owned-history-clone';plan=json.loads((out/'historical-plan.json').read_text());env={**os.environ,'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','PYTHONDONTWRITEBYTECODE':'1','GIT_TERMINAL_PROMPT':'0'}
def call(argv,cwd,label):
 r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=180);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);return r
r=call(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(root),str(clone)],out,'clone');assert r.returncode==0
receipts=[]
for row in plan:
 r=call(['git','-c','core.hooksPath=/dev/null','checkout','--detach',row['revision']],clone,row['id']+'-checkout');assert r.returncode==0
 before=call(['git','status','--porcelain=v1'],clone,row['id']+'-before');assert not before.stdout
 start=time.monotonic();r=call(['python3','scripts/'+row['checker']],clone,row['id']+'-historical');after=call(['git','status','--porcelain=v1'],clone,row['id']+'-after');assert not after.stdout
 receipts.append({**row,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'manifest_sha256':hashlib.sha256((clone/row['manifest']).read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'owned_clone_unchanged':True,'actual_LLM_calls':0,'formal_completed':0})
 (out/'historical-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(row['id'],r.returncode,flush=True)
print('historical draft replay complete',flush=True)
