import concurrent.futures,importlib.util,json,os,subprocess
from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-guardian-deadline-diagnosis-corrective1-20261020');out.mkdir()
s=importlib.util.spec_from_file_location('owned',ROOT/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
replace={};originals={}
def overlay(name,transform):
 src=ROOT/name;raw=src.read_text();new=transform(raw);assert new!=raw,name;p=out/'overlay'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);replace[str(src)]=str(p);originals[name]=m.sha(src.read_bytes())
def test(s):
 start=s.index('func TestGuardianAbsoluteDeadlineWorksWhileOwnerSocketStaysOpen');end=s.index('\nfunc TestGuardianPastAbsoluteDeadline',start);block=s[start:end]
 a='''\tif err := cmd.Run(); err == nil {
\t\tt.Fatal("expired deadline reported success")
\t}''';b=''' diag,err:=os.Create(filepath.Join(root,"guardian.stderr"));if err!=nil {t.Fatal(err)}
 defer func(){_ = diag.Close()}()
 cmd.Stdout,cmd.Stderr=diag,diag
 runErr:=cmd.Run();finished:=time.Now()
 returnInfo,returnStatErr:=os.Stat(late)
 t.Logf("GD return start=%d deadline=%d finish=%d error=%v marker_present=%t stat_error=%v",start.UnixNano(),payload.DeadlineUnixNano,finished.UnixNano(),runErr,returnInfo!=nil,returnStatErr)
 if runErr==nil {t.Fatal("expired deadline reported success")}''';assert a in block;block=block.replace(a,b)
 a='''\tif _, err := os.Stat(late); !os.IsNotExist(err) {
\t\tt.Fatal("deadline left a late writer")
\t}''';b=''' traceBytes,_:=os.ReadFile(filepath.Join(root,"guardian.stderr"));t.Logf("GD native trace: %s",traceBytes)
 info,statErr:=os.Stat(late)
 if !os.IsNotExist(statErr) {
  if statErr!=nil {t.Fatalf("GD stat failure without confirmed marker: %v",statErr)}
  data,readErr:=os.ReadFile(late)
  t.Fatalf("GD marker content=%q read_error=%v mtime=%d existed_at_return=%t mtime_after_return=%t",data,readErr,info.ModTime().UnixNano(),returnInfo!=nil,info.ModTime().After(finished))
 }''';assert a in block;return s[:start]+block.replace(a,b)+s[end:]
overlay('internal/setup/command_guard_test.go',test)
def runner(s):
 a='\t\terr := syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)';assert s.count(a)==1
 return s.replace(a,'\t\tfmt.Fprintf(os.Stderr,"GD kill_before pid=%d t=%d\\n",cmd.Process.Pid,time.Now().UnixNano())\n'+a+'\n\t\tfmt.Fprintf(os.Stderr,"GD kill_after pid=%d t=%d error=%v\\n",cmd.Process.Pid,time.Now().UnixNano(),err)')
overlay('internal/setup/runner.go',runner)
def guardian(s):
 a='\tif err := cmd.Start(); err != nil {\n\t\t_ = writer.Close()\n\t\treturn err\n\t}\n\t_ = writer.Close()';assert s.count(a)==1
 s=s.replace(a,'\tfmt.Fprintf(os.Stderr,"GD start_before t=%d\\n",time.Now().UnixNano())\n'+a+'\n\tfmt.Fprintf(os.Stderr,"GD started pid=%d t=%d\\n",cmd.Process.Pid,time.Now().UnixNano())')
 a='\terr = cmd.Wait()';assert s.count(a)==1
 return s.replace(a,a+'\n\tfmt.Fprintf(os.Stderr,"GD waited pid=%d t=%d error=%v\\n",cmd.Process.Pid,time.Now().UnixNano(),err)')
overlay('internal/setup/command_guard.go',guardian)
overlay('internal/setup/guardian_testmain_test.go',lambda s:s.replace('"os"','"os"\n "fmt"').replace('if RunGuardedDatasetStep(os.Args[2]) != nil {','if err:=RunGuardedDatasetStep(os.Args[2]); err != nil {\n fmt.Fprintf(os.Stderr,"GD guardian_result t=%d error=%v\\n",time.Now().UnixNano(),err)').replace('"testing"','"testing"\n "time"'))
m.write(out/'overlay.json',dict(Replace=replace));m.write(out/'SCOPE.json',dict(base_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),original_sha256=originals,overlay_sha256={str(p.relative_to(out)):m.sha(p.read_bytes())for p in(out/'overlay').rglob('*')if p.is_file()},planned_groups=8,repetitions=50,total=400,deadline_ms=200,worker_sleep_seconds=1,post_wait_seconds=1.1,owner_socket_open=True,production_sources_modified=False,CoreML_excluded=True))
r=m.command(['go','test','-race','-overlay',str(out/'overlay.json'),'-c','-o',str(out/'setup.test'),'./internal/setup'],ROOT,out/'build',env,300);assert r['exit_code']==0 and not r['remaining_live_group_members'];m.write(out/'binary.json',dict(sha256=m.sha((out/'setup.test').read_bytes())));print('instrumented race binary built',flush=True)
def run(i):
 argv=['go','tool','test2json','-t','-p','github.com/0xmhha/knowledge-system/internal/setup',str(out/'setup.test'),'-test.v','-test.run=^TestGuardianAbsoluteDeadlineWorksWhileOwnerSocketStaysOpen$','-test.count=50','-test.timeout=180s']
 r=m.command(argv,ROOT,out/'groups'/str(i),env,200);rows=[json.loads(x)for x in(out/'groups'/str(i)/'stdout').read_text().splitlines()];r['tests']={a:sum(x.get('Action')==a and bool(x.get('Test'))for x in rows)for a in('pass','fail','skip')};m.write(out/'groups'/str(i)/'result.json',r);assert r['reaped']and not r['timeout']and not r['remaining_live_group_members'];print('group',i,'exit',r['exit_code'],'tests',r['tests'],flush=True);return dict(group=i,**r)
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:results=list(pool.map(run,range(8)))
assert all(m.sha((ROOT/n).read_bytes())==h for n,h in originals.items());m.write(out/'RESULT.json',dict(groups=results,source_preserved=True,CoreML_excluded=True));print('all diagnostic attempts retained',flush=True)
