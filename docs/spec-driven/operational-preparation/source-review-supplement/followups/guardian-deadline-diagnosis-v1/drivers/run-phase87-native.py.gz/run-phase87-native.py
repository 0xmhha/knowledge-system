import importlib.util,json,os,subprocess
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');candidate=Path('/private/tmp/ks-phase87-candidate-20261020');out=Path('/private/tmp/ks-phase87-native-20261020');binding=json.loads((candidate/'source-binding.json').read_text())
s=importlib.util.spec_from_file_location('native',root/'scripts/verify-wi3-reasons-native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
original=m.check_sources
def check(root,b):
 original(root,b)
 actual={str(p.relative_to(root)):m.sha(p.read_bytes())for p in(root/'internal/system/viewer/web_assets/app').rglob('*')if p.is_file()};assert actual==b['generated_input_sha256'],'generated payload changed'
 if out.exists()and not(out/'TOOLS-BEFORE-LINT.json').exists():
  m.write(out/'TOOLS-BEFORE-LINT.json',tools)
  previous={json.loads(line)['Package']for line in Path('/private/tmp/ks-phase86-native-20261020/test.stdout').read_text().splitlines()if line.strip()and'Package'in json.loads(line)}
  current=set(subprocess.check_output(['go','list','./...'],cwd=root,text=True).splitlines());assert previous==current;m.write(out/'package-boundary-proof.json',dict(previous=sorted(previous),current=sorted(current),removed_external_only=[],maintained_packages_preserved=True,lint_rule_or_config_changed=False))
m.check_sources=check
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','CGO_ENABLED','CC','CXX','PKG_CONFIG_PATH')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1');os.environ.clear();os.environ.update(env)
tools=dict(capture_before_lint=True,go=subprocess.check_output(['go','version'],text=True).strip(),lint=subprocess.check_output(['/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint','version'],text=True).strip(),lint_configuration_sha256=m.sha((root/'.golangci.yml').read_bytes()),executable_sha256={n:m.sha(Path(p).read_bytes())for n,p in{'go':go+'/bin/go','lint':'/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint'}.items()})
m.run(root,out,binding,Path('/private/tmp/ks-go-cache'))
d=json.loads((out/'binary.json').read_text());d['source_mode']=binding['source_mode'];m.write(out/'binary.json',d);assert d['sha256']==m.sha((candidate/'cks').read_bytes())
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
for name,path in [('graph','./cmd/graph'),('vector','./cmd/vector')]:
 for label,argv in [('build-'+name+'-runtime',['go','build','-o',str(out/('read-'+name)),path]),(name+'-build-info',['go','version','-m',str(out/('read-'+name))])]:
  check(root,binding);r=owned.command(argv,root,out/label,env,900);r.update(label=label,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()));m.write(out/(label+'-receipt.json'),r);assert r['exit_code']==0 and not r['remaining_live_group_members'];check(root,binding)
 file='ckg'if name=='graph'else'ckv';assert m.sha((out/('read-'+name)).read_bytes())==m.sha((candidate/file).read_bytes());m.write(out/(name+'-binary.json'),dict(sha256=m.sha((out/('read-'+name)).read_bytes()),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
groups=[]
for r in json.loads((out/'receipts.json').read_text()):
 rows=[line for line in subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines()if len(x:=line.split())==3 and int(x[1])==r['pid']];assert not rows;groups.append(dict(label=r['label'],pgid=r['pid'],remaining_live_group_members=0))
m.write(out/'process-groups.json',groups);m.write(out/'installed-tools.json',dict(go=subprocess.check_output(['go','version'],text=True).strip(),lint=subprocess.check_output(['/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint','version'],text=True).strip()));print('native CKS/CKG/CKV match frozen candidates',flush=True)
