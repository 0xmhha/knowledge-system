import os,json,importlib.util
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase86-final-guards-20261020');out.mkdir()
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};go='/Users/kevin/.gvm/gos/go1.26.8';env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',PYTHONPATH=str(root/'scripts'),PYTHONDONTWRITEBYTECODE='1')
receipts=[]
for label,argv in [('coreml',['python3','-m','unittest','test_coreml_readiness']),('operational',['python3','-m','unittest','test_operational_acceptance']),('remaining',['python3','-m','unittest','test_remaining_13']),('primary',['python3','scripts/check-operational-acceptance.py']),('remaining-primary',['python3','scripts/check-remaining-13.py']),('docs',['make','docs-check'])]:
 r=m.command(argv,root,out/label,env,600);receipts.append(dict(label=label,**r));m.write(out/'receipts.json',receipts);print(label,'exit',r['exit_code'],'reaped',r['reaped'],'remaining',r['remaining_live_group_members'],flush=True);assert r['exit_code']==0 and not r['remaining_live_group_members'],label
print('final CoreML evidence, unchanged approval boundaries, completion ledger and documentation verified',flush=True)
