"""Owned actual two-role typed review transport, scripted local gateway only."""
import copy,importlib.util,json,os,shlex,shutil,subprocess,sys
from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');sys.path.insert(0,str(ROOT/'scripts'))
import wi6_pair_contract as contract
spec=importlib.util.spec_from_file_location('roles',ROOT/'scripts/run-four-role-current.py');roles=importlib.util.module_from_spec(spec);spec.loader.exec_module(roles)
host=roles.host;pilot=roles.pilot
CONSUMER=Path('/private/tmp/ks-adopted-consumer-20261017');BINARY=Path('/private/tmp/ks-phase77-candidate-final-20261019/cks');WORK=Path('/private/tmp/ks-phase79-review-delivery-20261019');TICKET='KS-P06-REVIEW'

def wire(out):
 frames=[json.loads(x)for x in(out/'mcp-frames.jsonl').read_text().splitlines()];requests={};result={}
 for row in frames:
  if row['kind']=='request':
   v=json.loads(row['raw'])
   if v.get('method')=='tools/call':requests[v['id']]=v
  elif row['kind']=='response':
   v=json.loads(row['raw'])
   if v.get('id')in requests:result[requests[v['id']]['params']['name']]=dict(tool=requests[v['id']]['params']['name'],arguments=requests[v['id']]['params']['arguments'],result=host.payload(v))
 return result
class Actions(list):
 def __init__(self,rows,out,workspace):super().__init__(rows);self.out=out;self.workspace=workspace
 def __getitem__(self,index):
  row=super().__getitem__(index);operation=row.get('derived')
  if not operation:return row
  if operation=='bundle':
   received=wire(self.out);bundle=dict(schema_version=1,ticket_id=TICKET,rules=received['cks.context.rule_candidates'],function_review=received['cks.context.review_function']);host.dump(self.out/'actual-bundle.json',bundle)
   return dict(name='Write',input=dict(file_path=str(self.workspace/'bundle-input.json'),content=json.dumps(bundle,ensure_ascii=False)))
  if operation=='judgments':
   source=wire(self.out)['cks.context.rule_candidates']['result']['analysis'];nodes=source['nodes'];node=next(n for n in nodes if not n.get('synthetic')and'once.Do'in n['text'])
   sections={name:dict(status='unknown',claim='No measured or whole-program '+name+' conclusion is supplied',evidence_nodes=[],assumptions=[],unknowns=['Bounded retained source does not establish this property'],origin='agent_reasoning')for name in ['data_state','guards_exceptions','complexity','resources','io','priority_tradeoffs']}
   sections['data_state']=dict(status='inferred',claim='The retained outer statement invokes once.Do with a callback; callback execution and system effects remain outside this bounded outer CFG',evidence_nodes=[node['id']],assumptions=['Source text is interpreted as Go syntax; imported target identity is not independently resolved'],unknowns=['Whole-program effects and callback progress are not established by this outer CFG'],origin='agent_reasoning')
   judgments=dict(sections=sections,findings=[dict(id='DEV-REVIEW-001',category='resource',claim='Callback progress needs the actual owner and acknowledgement path; this partial local view cannot decide termination',suggestion='Review actual owner receipt and acknowledgement under stated schedules before accepting termination',priority='medium',evidence_nodes=[node['id']],rule_candidates=[],assumptions=['The callback shown in the retained text is the path under review'],unknowns=['Independent priority/required-item gold is not approved'],origin='agent_reasoning',state='review_candidate')],criteria=[dict(id='DEV-SCOPE-01',requirement='Keep callback/whole-program progress unknown rather than inventing a CFG proof',section='data_state',status='covered',reason='Outer source node is cited; whole-program and callback effects stay explicit unknown')])
   host.dump(self.out/'AI-judgments.json',judgments)
   return dict(name='Write',input=dict(file_path=str(self.workspace/'judgments-input.json'),content=json.dumps(judgments,ensure_ascii=False)))
  state=json.loads((self.workspace/'state.json').read_text())
  if operation=='analysis_handoff':
   state['current_state']='PLANNING';state['states']['ANALYSIS']=dict(status='completed',deep_review_sha256=host.sha(self.workspace/'deep-review.json'));state['states']['PLANNING']=dict(status='pending')
  elif operation=='planning_bound':state['states']['PLANNING']=dict(status='completed',review_report_sha256=host.sha(self.workspace/'review-report.md'))
  elif operation=='bad_terminal':state['current_state']='COMPLETED';state['states']['PLANNING']['review_report_sha256']='0'*64
  else:raise ValueError(operation)
  host.dump(self.out/('proposed-'+operation+'.json'),state)
  return dict(name='Write',input=dict(file_path=str(self.workspace/'state.json'),content=json.dumps(state,ensure_ascii=False,indent=2)))

def run():
 WORK.mkdir();out=WORK/'evidence';out.mkdir()
 consumer_before=roles.source_inventory(CONSUMER);host.dump(out/'consumer-before.json',consumer_before)
 before=pilot.inventory(pilot.DATA);host.dump(out/'original-before.json',before);shutil.copytree(pilot.DATA,WORK/'data',ignore=lambda d,names:[n for n in names if n.endswith(('.lock','.lease'))]);contract.restore_reader_coordination(WORK/'data');assert pilot.inventory(WORK/'data')==before
 (WORK/'empty-live-source').mkdir();repo=WORK/'source';env={k:os.environ[k]for k in ('PATH','HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',PYTHONDONTWRITEBYTECODE='1')
 subprocess.run(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout','/private/tmp/ks-wi4-target-20261019/source',str(repo)],check=True,capture_output=True,env=env);subprocess.run(['git','-c','core.hooksPath=/dev/null','checkout','--detach',roles.SOURCE_REV],cwd=repo,check=True,capture_output=True,env=env)
 source_before=roles.source_inventory(repo);host.dump(out/'source-before.json',source_before)
 node=json.loads(Path('/private/tmp/ks-phase77-startup-retained-runtime-20261019/selected-source.json').read_text());q=dict(node_id=node['node_id'],expected_commit=roles.SOURCE_REV,expected_source_sha256=node['function_sha256']);workspace=repo/'.coding-agent/tickets'/TICKET;workspace.mkdir(parents=True)
 state=dict(schema_version=1,ticket_id=TICKET,ticket_type='code_review',project_id='go-stablenet',pipeline_variant='review_only',requirement_source='local',current_state='ANALYSIS',states={'ANALYSIS':{'status':'in_progress'},'PLANNING':{'status':'pending'}},config=dict(publication_policy='evaluation_only',autonomy=dict(mode='auto',auto_merge=False)))
 host.dump(workspace/'state.json',state);host.dump(out/'initial-state.json',state)
 config=WORK/'cks.yaml';template=Path('/private/tmp/ks-phase77-startup-retained-runtime-20261019/batch_measured/config.yaml').read_text();import re
 template=template.replace('/private/tmp/ks-phase77-startup-retained-runtime-20261019',str(WORK));template=re.sub(r'(?m)^(\s*)ollama_url:.*$',r'\1ollama_url: http://127.0.0.1:11434',template);config.write_text(template)
 host.P05=WORK/'current-binary-binding';host.P05.mkdir();host.dump(host.P05/'execution.json',dict(binary_sha256={'cks':host.sha(BINARY)}));host.BINARY=BINARY;host.CANDIDATE=CONSUMER;host.ActionPlan=lambda rows,out,workspace:rows
 scope=dict(kind='WIC_actual_two_role_typed_delivery_not_model_quality',binary_sha256=host.sha(BINARY),binary_source_binding=json.loads(BINARY.with_name('source-binding.json').read_text()),consumer_revision=roles.CONSUMER_REV,roles=['analyzer','planner'],actual_LLM_calls=0,paid_external_calls=0,global_install=False,formal_completed=0,independent_approved=0,rendering_verified=False,priority_correctness_approved=False,security_only_evaluations_executed=False,driver_sha256=contract.sha(Path(__file__).read_bytes()),node=node,required_artifacts=['deep-review-evidence.json','deep-review.json','review-report.md','sequence.mmd','modules.mmd'])
 host.dump(out/'SCOPE.json',scope)
 script=CONSUMER/'plugin/scripts/deep_review.py';build=shlex.join([sys.executable,str(script),'build','--workspace',str(workspace),'--bundle',str(workspace/'bundle-input.json'),'--judgments',str(workspace/'judgments-input.json')]);verify=shlex.join([sys.executable,str(script),'verify','--workspace',str(workspace)])
 alias=lambda n:'mcp__plugin_coding-agent_cks__cks_context_'+n
 analyzer=[dict(name='Read',input=dict(file_path=str(CONSUMER/'plugin/skills/structured-review/SKILL.md'))),dict(name=alias('rule_candidates'),input=dict(rule_pack='go-local-review@1.0.0',function=q)),dict(name=alias('review_function'),input=dict(symbol=node['canonical_id'],caller_depth=1,max_items=5)),dict(derived='bundle'),dict(derived='judgments'),dict(name='Bash',input=dict(command=build)),dict(derived='analysis_handoff'),dict(name='Bash',input=dict(command=verify))]
 host.run(WORK,'P79-analyzer','analyzer',Actions(analyzer,WORK/'P79-analyzer',workspace),config=config)
 host.dump(out/'analyzer-artifacts.json',{n:host.sha(workspace/n)for n in scope['required_artifacts'] if(workspace/n).exists()})
 planner=[dict(name='Read',input=dict(file_path=str(CONSUMER/'plugin/skills/structured-review/SKILL.md')))]+[dict(name='Read',input=dict(file_path=str(workspace/n)))for n in ['state.json',*scope['required_artifacts']]]+[dict(name='Bash',input=dict(command=verify)),dict(derived='planning_bound'),dict(name='Bash',input=dict(command=verify)),dict(derived='bad_terminal')]
 host.run(WORK,'P79-planner','planner',Actions(planner,WORK/'P79-planner',workspace),config=config)
 final=json.loads((workspace/'state.json').read_text());host.dump(out/'final-state.json',final);host.dump(out/'final-artifacts.json',{n:host.sha(workspace/n)for n in scope['required_artifacts']if(workspace/n).exists()})
 for label,value in [('original-after',pilot.inventory(pilot.DATA)),('owned-after',pilot.inventory(WORK/'data')),('source-after',roles.source_inventory(repo)),('consumer-after',roles.source_inventory(CONSUMER))]:host.dump(out/(label+'.json'),value)
 assert before==pilot.inventory(pilot.DATA)==pilot.inventory(WORK/'data')and source_before==roles.source_inventory(repo)and consumer_before==roles.source_inventory(CONSUMER)
 host.dump(out/'receipt.json',dict(actual_roles=2,actual_LLM_calls=0,formal_completed=0,independent_approved=0,original_owned_preserved=True,final_state=final['current_state'],artifact_files=len([n for n in scope['required_artifacts']if(workspace/n).exists()])))
 print('two-role probe finished; inspect actual CLI/hook/gateway outcomes before adoption',flush=True)
if __name__=='__main__':run()
