# Structured function review

Status: structured partial review; independent acceptance: not recorded.

Source pins:
```json
{
  "bytes": 347,
  "canonical_id": "github.com/ethereum/go-ethereum/eth/downloader.(*SyncStatusSubscription).Unsubscribe",
  "commit": "0bf2f4d1bfeb6605006d556957ef8c045d8f8ed8",
  "file": "eth/downloader/api.go",
  "function_name": "Unsubscribe",
  "language": "go",
  "node_id": "ae0cec70160b1579",
  "sha256": "79a09d0efaf704fe00e2ba8dff8ec7f75de026279e05a76d31425b3ae8c1c588",
  "snapshot_sha256": "b7391a71c38b51c896471754e81553590dfc773490f247be574d0b1637cb8cab",
  "start_byte": 5644,
  "start_line": 183
}
```

Computed CFG sequence (not an execution trace):
```json
{
  "edges": [],
  "kind": "bounded_cfg_not_execution_trace"
}
```

Module membership:
```json
{
  "file": "eth/downloader/api.go",
  "interprocedural_edges": "unknown",
  "kind": "retained_file_membership",
  "symbol": "ae0cec70160b1579"
}
```

## data_state

```json
{
  "assumptions": [
    "Source text is interpreted as Go syntax; imported target identity is not independently resolved"
  ],
  "claim": "The retained outer statement invokes s.unsubOnce.Do with a callback; callback execution and system effects remain outside this bounded outer CFG",
  "evidence_nodes": [
    "b0/n0"
  ],
  "origin": "agent_reasoning",
  "status": "inferred",
  "unknowns": [
    "Whole-program effects and callback progress are not established by this outer CFG"
  ]
}
```

## guards_exceptions

```json
{
  "assumptions": [],
  "claim": "No measured or whole-program guards_exceptions conclusion is supplied",
  "evidence_nodes": [],
  "origin": "agent_reasoning",
  "status": "unknown",
  "unknowns": [
    "Bounded retained source does not establish this property"
  ]
}
```

## complexity

```json
{
  "assumptions": [],
  "claim": "No measured or whole-program complexity conclusion is supplied",
  "evidence_nodes": [],
  "origin": "agent_reasoning",
  "status": "unknown",
  "unknowns": [
    "Bounded retained source does not establish this property"
  ]
}
```

## resources

```json
{
  "assumptions": [],
  "claim": "No measured or whole-program resources conclusion is supplied",
  "evidence_nodes": [],
  "origin": "agent_reasoning",
  "status": "unknown",
  "unknowns": [
    "Bounded retained source does not establish this property"
  ]
}
```

## io

```json
{
  "assumptions": [],
  "claim": "No measured or whole-program io conclusion is supplied",
  "evidence_nodes": [],
  "origin": "agent_reasoning",
  "status": "unknown",
  "unknowns": [
    "Bounded retained source does not establish this property"
  ]
}
```

## priority_tradeoffs

```json
{
  "assumptions": [],
  "claim": "No measured or whole-program priority_tradeoffs conclusion is supplied",
  "evidence_nodes": [],
  "origin": "agent_reasoning",
  "status": "unknown",
  "unknowns": [
    "Bounded retained source does not establish this property"
  ]
}
```

## Findings and review criteria

```json
{
  "criteria": [
    {
      "id": "DEV-SCOPE-01",
      "reason": "Outer source node is cited; whole-program and callback effects stay explicit unknown",
      "requirement": "Keep callback/whole-program progress unknown rather than inventing a CFG proof",
      "section": "data_state",
      "status": "covered"
    }
  ],
  "findings": [
    {
      "assumptions": [
        "The callback shown in the retained text is the path under review"
      ],
      "category": "resource",
      "claim": "Callback progress needs the actual owner and acknowledgement path; this partial local view cannot decide termination",
      "evidence_nodes": [
        "b0/n0"
      ],
      "id": "DEV-REVIEW-001",
      "origin": "agent_reasoning",
      "priority": "medium",
      "rule_candidates": [],
      "state": "review_candidate",
      "suggestion": "Review actual owner receipt and acknowledgement under stated schedules before accepting termination",
      "unknowns": [
        "Independent priority/required-item gold is not approved"
      ]
    }
  ]
}
```

## Limitations

- graph rule/value computation is bounded, not whole-program safety
- structural review lacks its own immutable snapshot/blob pin; no atomic cross-call proof
- source/CFG order is not a runtime call trace
- agent findings, complexity/resources/I/O and priorities are reasoning, not measured facts
- local receipt hashes do not authenticate MCP transport or grant reviewer acceptance

## Diagrams (computed local structure; no runtime trace)

```mermaid
flowchart TD
%% Computed bounded CFG; runtime feasibility, calls and exceptions remain unknown.
  empty["No CFG successors; no safety conclusion"]
```

```mermaid
flowchart LR
%% Computed retained-file membership; interprocedural edges are unknown.
  file["eth/downloader/api.go"] -->|computed membership| symbol["Selected retained function"]
  symbol -.->|unknown, not computed| external["Interprocedural relationships unavailable"]
```
