// Owned real two-node fixture for the in-progress (Syncing=true) generation
// boundary. The seeder holds a longer chain; the receiver's only peer is
// removed after the first imported block, so its real full sync stalls with
// CurrentBlock < HighestBlock before the original 60s timer.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math/big"
	"os"
	"time"

	"github.com/ethereum/go-ethereum/consensus/ethash"
	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/eth"
	"github.com/ethereum/go-ethereum/eth/downloader"
	"github.com/ethereum/go-ethereum/eth/ethconfig"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/node"
	"github.com/ethereum/go-ethereum/p2p"
	"github.com/ethereum/go-ethereum/params"
)

const (
	// fixtureBlocks is long enough that the receiver cannot import the whole
	// chain from what it fetched before the peer is removed.
	fixtureBlocks = 1024
	// cutHead is the receiver head at which the only peer is removed.
	cutHead       = 1
	syncStartWait = 60 * time.Second
	stallWait     = 60 * time.Second
	restoreWait   = 60 * time.Second
)

var start = time.Now()

func emit(event string, value interface{}) {
	_ = json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"event": event, "elapsed_ns": time.Since(start).Nanoseconds(), "value": value})
}

func main() {
	if err := run(); err != nil {
		emit("error", err.Error())
		os.Exit(1)
	}
	emit("complete", map[string]interface{}{"formal_completed": 0, "independent_approved": 0, "actual_source_sync": true, "schedule": os.Getenv("KS_NATIVE_SCHEDULE")})
}

func run() error {
	if e := downloader.OwnedNativeInit(os.Getenv("KS_NATIVE_TRACE"), os.Getenv("KS_NATIVE_SCHEDULE")); e != nil {
		return e
	}
	defer func() {
		if e := downloader.OwnedNativeFinish(); e != nil {
			emit("trace_close_error", e.Error())
		}
	}()
	dir, err := os.MkdirTemp("", "ks-real-peer-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	chain := *params.AllEthashProtocolChanges
	chain.TerminalTotalDifficulty = nil
	chain.TerminalTotalDifficultyPassed = false
	genesis := &core.Genesis{Config: &chain, GasLimit: 30000000, BaseFee: big.NewInt(params.InitialBaseFee), Difficulty: new(big.Int).Set(params.MinimumDifficulty)}
	// The chain is generated before any node exists, so the receiver API's
	// 60s timer is not consumed by fixture generation.
	engine := ethash.NewFaker()
	defer engine.Close()
	generated, blocks, _ := core.GenerateChainWithGenesis(genesis, engine, fixtureBlocks, nil)
	defer generated.Close()
	makeNode := func(name string, maxPeers int) (*node.Node, *eth.Ethereum, error) {
		stack, e := node.New(&node.Config{Name: "ks-owned-" + name, DataDir: dir + "/" + name, P2P: p2p.Config{ListenAddr: "127.0.0.1:0", NoDiscovery: true, NoDial: false, MaxPeers: maxPeers}})
		if e != nil {
			return nil, nil, e
		}
		cfg := ethconfig.Defaults
		cfg.Genesis = genesis
		cfg.NetworkId = 71377
		cfg.SyncMode = downloader.FullSync
		cfg.TxLookupLimit = 128
		cfg.EthDiscoveryURLs = nil
		cfg.SnapDiscoveryURLs = nil
		service, e := eth.New(stack, &cfg)
		if e != nil {
			stack.Close()
			return nil, nil, e
		}
		if e = stack.Start(); e != nil {
			stack.Close()
			return nil, nil, e
		}
		if !stack.Server().Self().IP().IsLoopback() {
			stack.Close()
			return nil, nil, fmt.Errorf("non-loopback listener")
		}
		emit("factory_started", map[string]interface{}{"name": name, "listen_addr": stack.Server().ListenAddr, "node_ip": stack.Server().Self().IP().String(), "discovery": !stack.Server().NoDiscovery, "network_id": cfg.NetworkId, "real_downloader": service.Downloader() != nil})
		return stack, service, nil
	}
	seed, seedService, err := makeNode("seeder", 2)
	if err != nil {
		return fmt.Errorf("seeder factory: %w", err)
	}
	defer seed.Close()
	receiver, receiverService, err := makeNode("receiver", 1)
	if err != nil {
		return fmt.Errorf("receiver factory: %w", err)
	}
	defer receiver.Close()
	if _, err = seedService.BlockChain().InsertChain(blocks); err != nil {
		return fmt.Errorf("seed block import: %w", err)
	}
	seedHead := seedService.BlockChain().CurrentBlock()
	emit("seeder_imported", map[string]interface{}{"blocks": len(blocks), "head": seedHead.Hash().Hex()})
	observer := receiverService.EventMux().Subscribe(downloader.StartEvent{}, downloader.DoneEvent{}, downloader.FailedEvent{})
	defer observer.Unsubscribe()
	client := receiver.Attach()
	defer client.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	var sid string
	if err = client.CallContext(ctx, &sid, "eth_subscribe", "syncing"); err != nil || sid == "" {
		return fmt.Errorf("real RPC subscribe: %v", err)
	}
	if err = downloader.OwnedNativePrepare(receiverService.Downloader(), receiverService.BlockChain(), receiverService.EventMux(), sid); err != nil {
		return err
	}
	emit("rpc_subscription_response", true)
	// The original API timer is unchanged. Subscription installation is deliberately
	// allowed to settle before connecting the only explicitly configured peer.
	time.Sleep(time.Second)
	receiver.Server().AddPeer(seed.Server().Self())
	emit("loopback_peer_added", seed.Server().Self().IP().String())
	if err = stallSync(observer, receiver, receiverService, seed); err != nil {
		return err
	}
	role := os.Getenv("KS_NATIVE_ROLE")
	if err = downloader.OwnedProgressFirst(client, sid, role); err != nil {
		downloader.OwnedSummary()
		return err
	}
	emit("old_generation_real_owner_ack_observed", true)
	restore := func() error { return restoreSync(observer, receiver, receiverService, seed, seedHead.Hash().Hex()) }
	err = downloader.OwnedProgressRegenerate(client, role, restore)
	downloader.OwnedSummary()
	if err != nil {
		return err
	}
	emit("generation_boundary_completed", true)
	client.Close()
	if err = receiver.Close(); err != nil {
		return fmt.Errorf("receiver close: %w", err)
	}
	emit("receiver_close_returned", true)
	if err = seed.Close(); err != nil {
		return fmt.Errorf("seeder close: %w", err)
	}
	emit("seeder_close_returned", true)
	return nil
}

// stallSync removes the only peer once the real sync has imported cutHead and
// waits for the downloader to fail with the chain head still below the seeder.
func stallSync(observer *event.TypeMuxSubscription, receiver *node.Node, service *eth.Ethereum, seed *node.Node) error {
	start := time.NewTimer(syncStartWait)
	defer start.Stop()
	for started := false; !started; {
		select {
		case ev := <-observer.Chan():
			if ev == nil {
				return fmt.Errorf("source event mux closed")
			}
			if _, ok := ev.Data.(downloader.StartEvent); ok {
				started = true
				emit("actual_sync_start", true)
			} else {
				return fmt.Errorf("sync ended before the peer was removed: %T", ev.Data)
			}
		case <-start.C:
			return fmt.Errorf("actual sync did not start within declared %s", syncStartWait)
		}
	}
	for service.BlockChain().CurrentBlock().Number.Uint64() < cutHead {
		time.Sleep(time.Millisecond)
	}
	receiver.Server().RemovePeer(seed.Server().Self())
	emit("actual_peer_removed", map[string]interface{}{"head": service.BlockChain().CurrentBlock().Number.Uint64(), "progress": service.Downloader().Progress()})
	stall := time.NewTimer(stallWait)
	defer stall.Stop()
	for {
		select {
		case ev := <-observer.Chan():
			if ev == nil {
				return fmt.Errorf("source event mux closed")
			}
			switch v := ev.Data.(type) {
			case downloader.FailedEvent:
				progress := service.Downloader().Progress()
				emit("actual_sync_failed", fmt.Sprint(v.Err))
				if progress.CurrentBlock >= progress.HighestBlock || receiver.Server().PeerCount() != 0 {
					return fmt.Errorf("sync not stalled below the seeder: %+v peers %d", progress, receiver.Server().PeerCount())
				}
				emit("actual_sync_stalled", map[string]interface{}{"current_block": progress.CurrentBlock, "highest_block": progress.HighestBlock, "peers": 0})
				return nil
			case downloader.DoneEvent:
				return fmt.Errorf("sync completed although the peer was removed")
			}
		case <-stall.C:
			return fmt.Errorf("sync did not stall within declared %s", stallWait)
		}
	}
}

// restoreSync reconnects the seeder and waits until the real sync has reached
// its head and the transaction indexer is complete.
func restoreSync(observer *event.TypeMuxSubscription, receiver *node.Node, service *eth.Ethereum, seed *node.Node, seedHead string) error {
	receiver.Server().AddPeer(seed.Server().Self())
	emit("loopback_peer_restored", true)
	deadline := time.NewTimer(restoreWait)
	defer deadline.Stop()
	for done := false; !done; {
		select {
		case ev := <-observer.Chan():
			if ev == nil {
				return fmt.Errorf("source event mux closed")
			}
			switch v := ev.Data.(type) {
			case downloader.StartEvent:
				emit("actual_sync_restart", true)
			case downloader.DoneEvent:
				done = true
				emit("actual_sync_done", v)
			case downloader.FailedEvent:
				return fmt.Errorf("restored sync failed: %v", v.Err)
			}
		case <-deadline.C:
			return fmt.Errorf("restored sync did not complete within declared %s", restoreWait)
		}
	}
	head := service.BlockChain().CurrentBlock()
	if head.Number.Uint64() != fixtureBlocks || head.Hash().Hex() != seedHead {
		return fmt.Errorf("restored receiver head differs")
	}
	emit("actual_receiver_head", map[string]interface{}{"number": head.Number.Uint64(), "hash": head.Hash().Hex(), "matches_seeder": true})
	limit := time.Now().Add(5 * time.Second)
	for {
		progress, e := service.BlockChain().TxIndexProgress()
		if e != nil {
			return e
		}
		if progress.Done() {
			emit("actual_indexer_complete", progress)
			break
		}
		if time.Now().After(limit) {
			return fmt.Errorf("indexer incomplete: %+v", progress)
		}
		time.Sleep(20 * time.Millisecond)
	}
	emit("actual_downloader_progress", service.Downloader().Progress())
	return nil
}
