// Owned source-observation bridge for the in-progress (Syncing=true)
// generation boundary.
//
// Each (API, status channel) key carries a generation that the real owner's
// install increments. Every source channel use is recorded with the generation
// current at that moment, so a use after the real owner ack of the same
// generation is distinguished from a use by an explicit new registration.
// The receiver's only peer is removed part-way through a real full sync, so
// the original 60s timer finds CurrentBlock < HighestBlock and broadcasts a
// progress notification. The old generation ends by a real client
// eth_unsubscribe after it received that notification. Both schedules then
// re-register the acknowledged channel and add a new RPC subscription; the
// "progress-retained" schedule keeps the sync stalled so the next timer
// broadcasts progress again, and "progress-to-done" restores the peer so the
// next done broadcast follows the progress one.
package downloader

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"sort"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/rpc"
)

const (
	genScheduleRetained = "progress-retained"
	genScheduleDone     = "progress-to-done"
	genBoundedWait      = 3 * time.Second
	// genTimerWait covers one full native interval plus the case where the
	// first timer found no StartEvent yet and was reset.
	genTimerWait   = 150 * time.Second
	genQuietWindow = 500 * time.Millisecond
)

// genUseEvents are source operations that read from or write to a status channel.
var genUseEvents = map[string]bool{
	"install_send_begin":         true,
	"native_send_begin_progress": true,
	"native_send_begin_done":     true,
	"method_status_received":     true,
	"callback_status_received":   true,
	"probe_status_received":      true,
}

type genKey struct {
	api *DownloaderAPI
	c   chan interface{}
}

type genRecorder struct {
	mu         sync.Mutex
	file       *os.File
	path       string
	schedule   string
	start      time.Time
	seq        int
	apis       map[*DownloaderAPI]int
	created    map[*DownloaderAPI]time.Time
	channels   map[genKey]int
	rpcids     map[genKey]string
	gen        map[genKey]int
	acked      map[genKey]int
	members    map[genKey]bool
	counts     map[genKey]map[int]map[string]int
	violations map[genKey]int
	firstSeq   map[genKey]map[string]int
	global     map[string]int
	selected   genKey
}

var gr *genRecorder

// OwnedNativeInit opens the trace exclusively and selects the schedule.
func OwnedNativeInit(path, schedule string) error {
	if schedule != genScheduleRetained && schedule != genScheduleDone {
		return fmt.Errorf("unknown schedule %q", schedule)
	}
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	gr = &genRecorder{file: f, path: path, schedule: schedule, start: time.Now(), apis: map[*DownloaderAPI]int{}, created: map[*DownloaderAPI]time.Time{},
		channels: map[genKey]int{}, rpcids: map[genKey]string{}, gen: map[genKey]int{}, acked: map[genKey]int{}, members: map[genKey]bool{},
		counts: map[genKey]map[int]map[string]int{}, violations: map[genKey]int{}, firstSeq: map[genKey]map[string]int{}, global: map[string]int{}}
	return nil
}

// OwnedNativeFinish closes the trace.
func OwnedNativeFinish() error {
	if gr == nil {
		return nil
	}
	return gr.file.Close()
}

func genEmitLocked(api *DownloaderAPI, name string, c chan interface{}, owner, member bool, value interface{}) {
	r := gr
	k := genKey{api, c}
	if api != nil && r.apis[api] == 0 {
		r.apis[api] = len(r.apis) + 1
		r.created[api] = time.Now()
	}
	r.seq++
	r.global[name]++
	id, g, postAck := 0, 0, false
	if c != nil {
		if r.channels[k] == 0 {
			r.channels[k] = len(r.channels) + 1
		}
		id = r.channels[k]
		if name == "install" {
			r.gen[k]++
		}
		g = r.gen[k]
		if r.counts[k] == nil {
			r.counts[k] = map[int]map[string]int{}
			r.firstSeq[k] = map[string]int{}
		}
		if r.counts[k][g] == nil {
			r.counts[k][g] = map[string]int{}
		}
		r.counts[k][g][name]++
		if r.firstSeq[k][name] == 0 {
			r.firstSeq[k][name] = r.seq
		}
		if owner {
			r.members[k] = member
		}
		if name == "ack_close_end" {
			r.acked[k] = g
		}
		postAck = genUseEvents[name] && r.acked[k] > 0 && r.acked[k] == g
		if postAck {
			r.violations[k]++
		}
	}
	age := int64(0)
	if api != nil {
		age = time.Since(r.created[api]).Nanoseconds()
	}
	row := map[string]interface{}{"sequence": r.seq, "event": name, "elapsed_ns": time.Since(r.start).Nanoseconds(), "api_id": r.apis[api], "api_age_ns": age,
		"channel_id": id, "subscription_id": r.rpcids[k], "generation": g, "acked_generation": r.acked[k], "channel_use": genUseEvents[name],
		"post_ack_same_generation_use": postAck, "owner_map_observed": owner, "member": member, "value": value}
	if e := json.NewEncoder(r.file).Encode(row); e != nil {
		panic(e)
	}
}

func ksNativeCapture(api *DownloaderAPI) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	genEmitLocked(api, "factory_API_created", nil, false, false, nil)
}

func ksNativeCallback(api *DownloaderAPI, name string, c chan interface{}, sid rpc.ID) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	gr.rpcids[genKey{api, c}] = string(sid)
	genEmitLocked(api, name, c, false, false, nil)
}

func ksNativeLifecycle(api *DownloaderAPI, name string, c chan interface{}, members map[chan interface{}]struct{}) {
	// The progress the owner is about to send, read from the same downloader;
	// observation only, the notification itself is built by the source.
	var value interface{}
	if name == "native_send_begin_progress" {
		p := api.d.Progress()
		value = map[string]interface{}{"current_block": p.CurrentBlock, "highest_block": p.HighestBlock, "starting_block": p.StartingBlock}
	}
	r := gr
	r.mu.Lock()
	_, member := members[c]
	genEmitLocked(api, name, c, members != nil, member, value)
	r.mu.Unlock()
}

func genEmitFor(k genKey, name string, value interface{}) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	genEmitLocked(k.api, name, k.c, false, false, value)
}

func genCount(k genKey, g int, name string) int {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	return gr.counts[k][g][name]
}

func genGeneration(k genKey) int { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.gen[k] }
func genMember(k genKey) bool    { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.members[k] }
func genAcked(k genKey) int      { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.acked[k] }

func genUntil(p func() bool, limit time.Duration) error {
	end := time.Now().Add(limit)
	for time.Now().Before(end) {
		if p() {
			return nil
		}
		time.Sleep(time.Millisecond)
	}
	return fmt.Errorf("bounded generation observation did not complete")
}

func genSnapshot(name string) error {
	b := make([]byte, 4<<20)
	n := runtime.Stack(b, true)
	if n == len(b) {
		return fmt.Errorf("truncated stack")
	}
	return os.WriteFile(gr.path+"."+name+".stack", b[:n], 0600)
}

// genNewCallbackKey returns the single callback key on the selected API created after seq.
func genNewCallbackKey(after int) (genKey, error) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	var found []genKey
	for k, first := range gr.firstSeq {
		if k.api == gr.selected.api && first["callback_status_created"] > after {
			found = append(found, k)
		}
	}
	if len(found) != 1 {
		return genKey{}, fmt.Errorf("expected one new RPC callback channel, found %d", len(found))
	}
	return found[0], nil
}

func genCurrentSeq() int { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.seq }

// OwnedNativePrepare selects the factory subscription whose API wraps the given real objects.
func OwnedNativePrepare(d *Downloader, chain *core.BlockChain, mux *event.TypeMux, sid string) error {
	return genUntil(func() bool {
		r := gr
		r.mu.Lock()
		defer r.mu.Unlock()
		for api := range r.apis {
			if api.d != d || api.chain != chain || api.mux != mux {
				continue
			}
			for k, id := range r.rpcids {
				if k.api == api && id == sid && r.counts[k][1]["install"] == 1 {
					r.selected = k
					genEmitLocked(api, "selected_factory_subscription", k.c, false, false, map[string]interface{}{"same_downloader": true, "same_blockchain": true,
						"same_mux": true, "unbuffered_status_channel": cap(k.c) == 0, "subscription_id": sid, "generation": 1})
					return true
				}
			}
		}
		return false
	}, genBoundedWait)
}

// genOwnedManualUninstall asks the real owner loop to delete and acknowledge k.
func genOwnedManualUninstall(k genKey) error {
	genEmitFor(k, "owned_rescue_manual_uninstall_begin", map[string]interface{}{"generation": genGeneration(k)})
	req := uninstallSyncSubscriptionRequest{c: k.c, uninstalled: make(chan interface{})}
	select {
	case k.api.uninstallSyncSubscription <- &req:
	case <-time.After(genBoundedWait):
		return fmt.Errorf("owned cleanup uninstall not accepted")
	}
	select {
	case <-req.uninstalled:
	case <-time.After(genBoundedWait):
		return fmt.Errorf("owned cleanup real acknowledgement missing")
	}
	genEmitFor(k, "owned_rescue_manual_uninstall_end", nil)
	return nil
}

// genAwaitAck waits for the real owner ack of the current generation of k, rescuing
// only when the source cannot reach it by itself (counted, never a fake ack).
func genAwaitAck(k genKey, allowManual bool) error {
	g := genGeneration(k)
	if genUntil(func() bool { return genCount(k, g, "ack_close_end") >= 1 }, genBoundedWait) == nil {
		return nil
	}
	if !allowManual {
		return fmt.Errorf("real owner ack for generation %d missing", g)
	}
	if e := genOwnedManualUninstall(k); e != nil {
		return e
	}
	return genUntil(func() bool { return genCount(k, g, "ack_close_end") >= 1 }, genBoundedWait)
}

func genFrozen(k genKey, g int) map[string]interface{} {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	counts := map[string]int{}
	for name, n := range gr.counts[k][g] {
		counts[name] = n
	}
	return map[string]interface{}{"channel_id": gr.channels[k], "generation": g, "counts": counts, "member": gr.members[k], "acked_generation": gr.acked[k]}
}

// OwnedProgressFirst waits until the original timer has forwarded a progress
// notification to the selected subscription, then ends that generation with a
// real client eth_unsubscribe and waits for its real owner ack.
func OwnedProgressFirst(client *rpc.Client, sid, role string) error {
	k := gr.selected
	if e := genUntil(func() bool {
		return genCount(k, 1, "native_send_end_progress") == 1 && genCount(k, 1, "callback_notify_end") == 1
	}, genTimerWait); e != nil {
		return fmt.Errorf("original progress notification never reached the selected callback: %w", e)
	}
	genEmitFor(k, "old_progress_forwarded", map[string]interface{}{"native_timer_seconds": 60})
	ctx, cancel := context.WithTimeout(context.Background(), genBoundedWait)
	defer cancel()
	var ok bool
	// The call returns after the server has ended the subscription, so the
	// begin event is what orders the unsubscribe before the callback exit.
	genEmitFor(k, "actual_RPC_unsubscribe_begin", nil)
	if e := client.CallContext(ctx, &ok, "eth_unsubscribe", sid); e != nil || !ok {
		return fmt.Errorf("real RPC unsubscribe: ok=%v err=%v", ok, e)
	}
	genEmitFor(k, "actual_RPC_unsubscribe_true", nil)
	if e := genUntil(func() bool {
		return genCount(k, 1, "callback_exit_rpc_error") == 1 && genCount(k, 1, "callback_returned") == 1
	}, genBoundedWait); e != nil {
		return e
	}
	genEmitFor(k, "progress_observation_frozen", genFrozen(k, 1))
	return genAwaitAck(k, role == "MUT-EARLY")
}

// OwnedProgressRegenerate performs explicit new registrations after the old
// generation's real owner ack: a same-channel re-registration through the
// factory API and a new RPC subscription. Both stay registered across the next
// native broadcast; restore, called for "progress-to-done", reconnects the peer
// and returns once the real sync has completed.
func OwnedProgressRegenerate(client *rpc.Client, role string, restore func() error) error {
	old := gr.selected
	manual := role == "MUT-EARLY"
	if genAcked(old) != 1 || genMember(old) && role != "MUT-STALE-ACK" {
		return fmt.Errorf("old generation not acknowledged before regeneration")
	}
	genEmitFor(old, "regeneration_begin", map[string]interface{}{"schedule": gr.schedule, "old_acked_generation": genAcked(old), "old_member": genMember(old)})
	probe := genStartSameChannel(old)
	defer probe.stop()
	if e := genUntil(func() bool { return genCount(old, 2, "install") == 1 }, genBoundedWait); e != nil {
		return e
	}
	mark := genCurrentSeq()
	ch := make(chan json.RawMessage, 8)
	ctx, cancel := context.WithTimeout(context.Background(), genBoundedWait)
	defer cancel()
	sub, e := client.EthSubscribe(ctx, ch, "syncing")
	if e != nil {
		return fmt.Errorf("new RPC subscribe: %w", e)
	}
	defer sub.Unsubscribe()
	var fresh genKey
	if e = genUntil(func() bool {
		k, err := genNewCallbackKey(mark)
		if err != nil {
			return false
		}
		fresh = k
		return genCount(k, 1, "install") == 1
	}, genBoundedWait); e != nil {
		return e
	}
	genEmitFor(fresh, "new_rpc_registration_installed", map[string]interface{}{"generation": 1, "distinct_channel": fresh.c != old.c})
	final := "native_send_end_progress"
	if gr.schedule == genScheduleDone {
		final = "native_send_end_done"
		genEmitFor(old, "peer_restore_begin", nil)
		if e = restore(); e != nil {
			return fmt.Errorf("peer restore: %w", e)
		}
		genEmitFor(old, "peer_restore_sync_completed", nil)
	}
	if e = genUntil(func() bool {
		return genCount(fresh, 1, final) == 1 && genCount(old, 2, final) == 1 && genCount(old, 2, "probe_status_received") == genCount(old, 2, "native_send_end_progress")+genCount(old, 2, "native_send_end_done")
	}, genTimerWait); e != nil {
		return fmt.Errorf("native %s broadcast to both registrations not observed: %w", final, e)
	}
	time.Sleep(300 * time.Millisecond)
	if e = genSnapshot("timer-broadcast"); e != nil {
		return e
	}
	genEmitFor(old, "timer_observation_frozen", map[string]interface{}{"old_generation1": genFrozen(old, 1), "old_generation2": genFrozen(old, 2), "new": genFrozen(fresh, 1)})
	want := map[string]bool{genScheduleRetained: true, genScheduleDone: false}[gr.schedule]
receive:
	for {
		select {
		case raw := <-ch:
			var body struct {
				Syncing bool `json:"syncing"`
			}
			if string(raw) != "false" {
				if e = json.Unmarshal(raw, &body); e != nil || !body.Syncing {
					return fmt.Errorf("new registration notification not a progress result: %s", raw)
				}
			}
			genEmitFor(fresh, "client_notification_received", string(raw))
			if body.Syncing == want {
				break receive
			}
		case <-time.After(genBoundedWait):
			return fmt.Errorf("new RPC registration did not receive its notification")
		}
	}
	if e = probe.finish(manual); e != nil {
		return e
	}
	sub.Unsubscribe()
	genEmitFor(fresh, "client_unsubscribe_returned", nil)
	if e = genUntil(func() bool { return genCount(fresh, 1, "callback_exit_rpc_error") == 1 }, genBoundedWait); e != nil {
		return e
	}
	if e = genAwaitAck(fresh, manual); e != nil {
		return e
	}
	time.Sleep(genQuietWindow)
	return nil
}

type genProbe struct {
	k        genKey
	sub      *SyncStatusSubscription
	quit     chan struct{}
	done     chan struct{}
	stopOnce sync.Once
}

// genStartSameChannel re-registers the acknowledged channel itself (generation 2)
// with an owned probe consuming it.
func genStartSameChannel(old genKey) *genProbe {
	p := &genProbe{k: old, quit: make(chan struct{}), done: make(chan struct{})}
	go func() {
		defer close(p.done)
		for {
			select {
			case v := <-old.c:
				ksNativeLifecycle(old.api, "probe_status_received", old.c, nil)
				genEmitFor(old, "probe_payload", fmt.Sprint(v))
			case <-p.quit:
				return
			}
		}
	}()
	p.sub = old.api.SubscribeSyncStatus(old.c)
	return p
}

// finish unsubscribes generation 2 and waits for its real owner ack.
func (p *genProbe) finish(manual bool) error {
	p.sub.Unsubscribe()
	return genAwaitAck(p.k, manual)
}

func (p *genProbe) stop() {
	p.stopOnce.Do(func() { close(p.quit); <-p.done })
}

// OwnedSummary emits the final per-key generation table.
func OwnedSummary() {
	gr.mu.Lock()
	rows := []map[string]interface{}{}
	for k, id := range gr.channels {
		if k.api != gr.selected.api {
			continue
		}
		rows = append(rows, map[string]interface{}{"channel_id": id, "subscription_id": gr.rpcids[k], "generations": gr.gen[k], "acked_generation": gr.acked[k],
			"member": gr.members[k], "post_ack_same_generation_uses": gr.violations[k], "counts": gr.counts[k]})
	}
	gr.mu.Unlock()
	sort.Slice(rows, func(i, j int) bool { return rows[i]["channel_id"].(int) < rows[j]["channel_id"].(int) })
	genEmitFor(gr.selected, "generation_summary", rows)
}
