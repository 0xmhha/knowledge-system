"""Compile-only probe of the progress fixture for every role (no node is started)."""
import json, subprocess, sys
from pathlib import Path
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter, transport_instrument as gi
a = ks_adapter.Adapter(sys.argv[1]); out = Path(sys.argv[2]); out.mkdir(parents=True)
ks = a.path('KS_ROOT'); ov = ks / 'docs/spec-driven/operational-preparation/source-review-supplement/followups/ticket-dev-gold-v1/private/overlays'
env = a.go_env(a.path('WORK_ROOT') / 'go-build-cache')
src = a.path('WORK_ROOT') / 'probe/source'
subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--quiet', '--shared', str(a.path('UPSTREAM_SOURCE')), str(src)], env=env, check=True)
subprocess.run(['git', 'checkout', '--quiet', '--detach', ks_adapter.COMMIT], cwd=src, env=env, check=True)
rows = {}
for role in ['ORIGINAL', 'CAND-A', 'CAND-B', 'MUT-EARLY', 'MUT-STALE-ACK']:
    raw = gi.stale_ack_overlay((ov / 'CAND-A.go.txt').read_bytes()) if role == 'MUT-STALE-ACK' else (ov / f'{role}.go.txt').read_bytes()
    api, counts = gi.instrument(raw, role, a.gofmt)
    (src / 'eth/downloader/api.go').write_bytes(api)
    (src / 'eth/downloader/ks_progress_generation.go').write_bytes((TOOLS / 'progress-bridge.go').read_bytes())
    (src / 'cmd/ks-progress-generation').mkdir(exist_ok=True)
    (src / 'cmd/ks-progress-generation/main.go').write_bytes((TOOLS / 'progress-main.go').read_bytes())
    r = subprocess.run([a.go, 'vet', './eth/downloader', './cmd/ks-progress-generation'], cwd=src, env=env, capture_output=True, text=True)
    rows[role] = dict(vet_exit=r.returncode, output=a.redact(r.stdout + r.stderr)[-3000:], sites=len(gi.channel_sites(raw)))
    print(role, r.returncode, flush=True)
(out / 'compile-probe.json').write_text(json.dumps(rows, indent=2) + '\n')
