"""Archive the compile probe and smoke attempts into packet/checks with redaction."""
import gzip, hashlib, json, re, sys
from pathlib import Path
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter
a = ks_adapter.Adapter(sys.argv[1]); packet = Path(sys.argv[2])
TMP = re.compile(r'/(?:private/)?var/folders/[^\s"\':]+')
def red(data):
    return TMP.sub('${TMPDIR}', a.redact(data.decode('utf-8', 'surrogateescape'))).encode('utf-8', 'surrogateescape')
rows = []
def put(rel, src):
    data = src.read_bytes(); out = red(data); target = packet / 'checks' / (rel + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists(): raise SystemExit('refusing overwrite ' + rel)
    target.write_bytes(gzip.compress(out, mtime=0))
    rows.append(dict(path=rel, raw_sha256=hashlib.sha256(data).hexdigest(), archived_sha256=hashlib.sha256(out).hexdigest()))
w = a.path('WORK_ROOT') / 'probe'
for probe in ('out1', 'out2'):
    put('compile-probe/' + probe + '.json', w / probe / 'compile-probe.json')
for f in sorted((w / 'smoke1').rglob('*')) + sorted((w / 'smoke2').rglob('*')):
    if f.is_file() and f.suffix != '.program':
        put('smoke/' + str(f.relative_to(w)), f)
(packet / 'checks-REDACTION.json').write_text(json.dumps(dict(rule='adapter placeholders and ${TMPDIR}', files=rows), indent=2) + '\n')
print('archived checks', len(rows))
