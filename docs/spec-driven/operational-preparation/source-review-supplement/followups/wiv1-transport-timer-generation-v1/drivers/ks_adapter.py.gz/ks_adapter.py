"""Portable execution adapter for retained native go-stablenet drivers.

The retained drivers hard-code the previous machine's paths. This module maps
every machine-specific location to a named placeholder read from a local,
uncommitted config, and redacts those locations from any text that is archived.
"""
import json
import os
from pathlib import Path

COMMIT = '0bf2f4d1bfeb6605006d556957ef8c045d8f8ed8'
GO_VERSION = 'go1.23.12'
PLACEHOLDERS = ('WORK_ROOT', 'UPSTREAM_SOURCE', 'GOMODCACHE', 'GOROOT', 'KS_ROOT', 'HOME')
# Offline, read-only module resolution: go.sum stays the integrity authority and
# no module is fetched during the run.
GO_ENV = dict(GOTOOLCHAIN='local', GOFLAGS='-mod=readonly', GOWORK='off', GOPROXY='off', GOSUMDB='off',
              GOPRIVATE='', GONOPROXY='', GONOSUMDB='', GOVCS='*:off')
# Previous-machine locations found in the retained phase-90 drivers, mapped to the
# placeholder that replaces them. Only the role is recorded, not a live path.
PREVIOUS_LOCATIONS = [
    ('/Users/kevin/.gvm/gos/go1.23.12', 'GOROOT'),
    ('/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod', 'GOMODCACHE'),
    ('/private/tmp/ks-wi4-target-20261019/source', 'UPSTREAM_SOURCE'),
    ('/private/tmp/ks-wi4-target-20261019/dependency-plan.json', 'retained wi4 preflight/dependency-plan.json'),
    ('/private/tmp/ks-phase90-go-build-cache', 'WORK_ROOT/go-build-cache'),
    ('/private/tmp/ks-phase90-native-rpc-corrective1-20261020', 'WORK_ROOT/run-<name>'),
    ('/private/tmp/phase90-*.go|py', 'WORK_ROOT/tools (extracted from packet drivers/*.gz)'),
]


class Adapter:
    def __init__(self, config_path):
        raw = json.loads(Path(config_path).read_text())
        missing = [k for k in PLACEHOLDERS if not raw.get(k)]
        if missing:
            raise ValueError('adapter config missing ' + ','.join(missing))
        self.paths = {k: str(Path(raw[k]).resolve()) for k in PLACEHOLDERS}
        self.go = str(Path(self.paths['GOROOT']) / 'bin' / 'go')
        self.gofmt = str(Path(self.paths['GOROOT']) / 'bin' / 'gofmt')

    def path(self, name):
        return Path(self.paths[name])

    def go_env(self, build_cache):
        base = {k: os.environ[k] for k in ('USER', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ}
        base.update(GO_ENV, HOME=self.paths['HOME'], GOROOT=self.paths['GOROOT'], GOMODCACHE=self.paths['GOMODCACHE'],
                    GOCACHE=str(build_cache), PATH=str(Path(self.paths['GOROOT']) / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin',
                    GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1', PYTHONDONTWRITEBYTECODE='1')
        return base

    def redact(self, data):
        """Replace machine locations with ${NAME}; longest location first."""
        text = data.decode('utf-8', 'surrogateescape') if isinstance(data, bytes) else data
        # /private/tmp and /tmp alias on macOS; redact both spellings.
        pairs = []
        for name, value in self.paths.items():
            pairs.append((value, name))
            if value.startswith('/private/'):
                pairs.append((value[len('/private'):], name))
        for value, name in sorted(pairs, key=lambda p: -len(p[0])):
            text = text.replace(value, '${' + name + '}')
        return text.encode('utf-8', 'surrogateescape') if isinstance(data, bytes) else text

    def describe(self):
        return dict(placeholders=list(PLACEHOLDERS), go_env=GO_ENV, go_version=GO_VERSION, source_commit=COMMIT,
                    previous_locations=[dict(previous=p, replaced_by=r) for p, r in PREVIOUS_LOCATIONS],
                    live_paths_committed=False)
