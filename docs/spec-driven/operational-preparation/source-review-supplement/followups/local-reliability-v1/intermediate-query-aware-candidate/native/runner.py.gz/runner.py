import os,json,importlib.util
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system')
allowed={k:v for k,v in os.environ.items() if k in {'PATH','HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','GOPATH','GOMODCACHE','GOROOT','CGO_ENABLED','CC','CXX','PKG_CONFIG_PATH'}}
os.environ.clear();os.environ.update(allowed)
s=importlib.util.spec_from_file_location('runner',root/'scripts/verify-wi3-resolver-native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
# CLI-only main is not exposed; use its source-bound underlying runner directly.
s=importlib.util.spec_from_file_location('runner_base',root/'scripts/verify-wi3-reasons-native.py');n=importlib.util.module_from_spec(s);s.loader.exec_module(n)
binding=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/local-reliability-v1/source-binding.json').read_text())
out=Path('/private/tmp/ks-phase73-native-final-20261019')
n.run(root,out,binding,Path('/private/tmp/ks-go-cache'))
b=json.loads((out/'binary.json').read_text());b['source_mode']=binding['source_mode'];(out/'binary.json').write_text(json.dumps(b,indent=2)+'\n')
