// Package config loads and validates cks runtime configuration:
//
//   - Config:            top-level cks settings (backends, listen, logging,
//     sanitize). Loaded from a YAML file at startup.
//   - SanitizeRuleset:   the sanitize-rule catalog used by the composer's
//     final-stage redaction (see sanitize.go).
//
// The loader is permissive on optional fields and strict on dangerous ones:
// unknown logging levels, malformed regex patterns in sanitize rules, and
// unrecognized RedactionActions are rejected at load time so that bugs
// surface early rather than silently degrading the LLM-boundary defense.
package config

import (
	"errors"
	"fmt"
	"net"
	"os"
	"strings"

	"gopkg.in/yaml.v3"

	"github.com/0xmhha/knowledge-system/pkg/system/contract"
)

// DefaultSanitizeRulesPath is the baseline sanitize ruleset used when a config
// does not pin one — the ruleset shipped in-repo. It must be non-empty so a
// production instance never runs with LLM-boundary redaction silently disabled
// (see Config.Validate). It is repo-root relative; callers that write a config
// for use from another directory should resolve it to an absolute path (as the
// gen-config command does).
const DefaultSanitizeRulesPath = "system/policies/sanitization_rules.yaml"

// configVersion is the only supported top-level version. Bumping requires a
// migration path documented in the changelog.
const configVersion = 1

// Config is the top-level cks settings root.
type Config struct {
	Version int `yaml:"version"`
	// Name identifies this cks-mcp instance. It becomes the MCP server name in
	// the handshake and is echoed in cks.ops.health, so a caller connecting by
	// ip:port can tell WHICH instance it reached when several run side by side
	// (one per dataset/index) on different ports. Empty defaults to the
	// deployment namespace root (KNOWLEDGE_MCP_NAMESPACE / ldflag, "cks" upstream).
	Name string `yaml:"name"`
	// Description is optional human-facing metadata (e.g. "go-stablenet pr-77-2
	// flow index") surfaced in cks.ops.health alongside Name.
	Description string            `yaml:"description"`
	Backends    BackendsConfig    `yaml:"backends"`
	Listen      ListenConfig      `yaml:"listen"`
	Logging     LoggingConfig     `yaml:"logging"`
	Sanitize    SanitizeConfig    `yaml:"sanitize"`
	Vocab       VocabConfig       `yaml:"vocab"`
	Domain      DomainConfig      `yaml:"domain"`
	Semantic    SemanticConfig    `yaml:"semantic"`
	Service     ServiceConfig     `yaml:"service"`
	Retrieval   RetrievalConfig   `yaml:"retrieval,omitempty"`
	Collection  CollectionConfig  `yaml:"collection,omitempty"`
	Maintenance MaintenanceConfig `yaml:"maintenance,omitempty"`
}

// RetrievalConfig pins the shared top-K for raw recall and optional concept
// text searches. Zero preserves the historical top-K of 20. It does not
// change the Stage-2 union cap or the separate knowledge-pass budget.
type RetrievalConfig struct {
	RecallK int `yaml:"recall_k,omitempty"`
	// TypeNeighbors adds used type declarations after the top v2 Go bodies.
	// Off by default: an independent evaluation showed no recall gain and
	// a lower MRR because the declarations rank above the expected evidence.
	TypeNeighbors bool `yaml:"type_neighbors,omitempty"`
}

func (c RetrievalConfig) EffectiveRecallK() int {
	if c.RecallK == 0 {
		return 20
	}
	return c.RecallK
}

// SemanticConfig enables reviewed external trace paths for the optional v2
// knowledge response. Empty StorePath preserves the earlier v2 behavior.
type SemanticConfig struct {
	StorePath string `yaml:"store_path"`
	// OntologyMode is off by default. Explicit modes select baseline,
	// concept_text, relations or combined; unknown arms are rejected.
	OntologyMode     string `yaml:"ontology_mode,omitempty"`
	OntologyBudgetMS int    `yaml:"ontology_budget_ms,omitempty"`
}

// ServiceConfig carries the launchd deployment's host-level properties — the
// ones that belong to where this instance runs rather than to what it serves.
type ServiceConfig struct {
	// LabelPrefix overrides the launchd label prefix the agents are installed
	// under. Empty uses the engine's own name, which is right for almost
	// everyone: the label identifies the software, and which project an
	// instance serves is already carried by the instance name it ends with.
	//
	// It exists for two cases. A host running two distributions of this
	// software needs them apart. And a deployment whose agents are already
	// installed under another prefix can name it here instead of unloading
	// and reinstalling them — the label is how launchd finds a job, so
	// changing it silently orphans what is running.
	//
	// It lands in a filename as well as a label, so it must be
	// filesystem-safe.
	LabelPrefix string `yaml:"label_prefix"`
}

// DomainConfig configures channel ② (domain-knowledge embedding). Empty
// ProjectDir disables it: cks.ops.index then refreshes only code + ckg.
type DomainConfig struct {
	// ProjectDir is the cks domain-knowledge project directory exported
	// before a full ckv build (e.g. docs/domain-knowledge/projects/go-stablenet).
	ProjectDir string `yaml:"project_dir"`
	// CorpusDir is the export output and the ckv --docs root
	// (e.g. generated/domain-corpus/go-stablenet).
	CorpusDir string `yaml:"corpus_dir"`
}

// VocabConfig controls the optional vocabulary resolver wired into
// composer Stage 1. The resolver expands user prompts with code keywords
// drawn from a project's curated glossary, so retrieval can match
// Korean / domain-vague terms against the identifiers actually present
// in the source tree. An empty GlossaryPath disables vocab expansion —
// Stage 1 falls back to the verbatim prompt, which is identical to the
// pre-vocab behavior.
type VocabConfig struct {
	// GlossaryPath is the YAML glossary file the vocab.Resolver loads at
	// startup. Relative paths resolve against the cks binary's cwd.
	GlossaryPath string `yaml:"glossary_path"`
}

// BackendsConfig holds connection settings for ckg and ckv.
type BackendsConfig struct {
	CKG CKGConfig `yaml:"ckg"`
	CKV CKVConfig `yaml:"ckv"`
}

// CKGConfig is the ckg client connection profile.
//
// SourceRoot points at the working tree the ckg index was built
// against. Used by composer.Stage4's FilesystemFetcher to resolve
// Citation.File paths (which are stored as repo-relative strings).
// Optional: when empty, the server derives it from the graph manifest's
// src_root (the dataset is the single source of truth), so the config need
// not duplicate it. Set it only to override the manifest.
type CKGConfig struct {
	Path       string `yaml:"path"`
	SourceRoot string `yaml:"source_root"`
	TimeoutMS  int    `yaml:"timeout_ms"`
	// BinaryPath is the ckg binary used by the cks.ops.index maintenance tool
	// (it shells out to `ckg build`); empty disables the ckg leg of that tool. Not
	// used on the query path (ckg is opened in-process via ckgclient.NewReal).
	BinaryPath string `yaml:"binary_path"`
	// PolicyFile is the ckg governance policy (the `policies/policy.yaml`
	// emitted by cks-domain-sync). When set, cks.ops.index passes it to
	// `ckg build --policy-file` so governed_by edges are rebuilt with the
	// index; empty omits the flag (no governance enrichment).
	PolicyFile string `yaml:"policy_file"`
}

// CKVConfig is the ckv client connection profile.
//
// BinaryPath: ckv exposes its real Engine only through its own MCP binary
// (the Go-level constructors live in internal/), so the cks ckv adapter
// spawns `ckv mcp --out=<Path>` as a subprocess. BinaryPath gives the
// absolute path to that binary; empty means "look up `ckv` on $PATH".
type CKVConfig struct {
	Path string `yaml:"path"`
	// Provider selects the embedding backend (see internal/embedder).
	// Empty defaults to "ollama". The model must match what the index was
	// built with regardless of provider.
	Provider string `yaml:"provider"`
	// BinaryPath is retained for the agent-triggered index op (cks.ops.index,
	// which shells out to `ckv reindex`); it is NOT used on the query path
	// anymore — cks imports pkg/ckv in-process, so there is no `ckv mcp`
	// subprocess.
	BinaryPath string `yaml:"binary_path"`
	// TimeoutMS is unused by the in-process query path (kept for config
	// back-compat; the subprocess call timeout it bounded no longer exists).
	TimeoutMS int `yaml:"timeout_ms"`
	// EmbedModel is the Ollama model name (e.g. "bge-m3") used to construct
	// the in-process embedder. Must match the model the index was built with.
	EmbedModel        string `yaml:"embed_model"`
	EmbedDim          int    `yaml:"embed_dim,omitempty"`
	QueryPrefixPolicy string `yaml:"query_prefix_policy,omitempty"`
	// EmbeddingCacheEntries enables a shared process-local LRU. Zero disables it.
	EmbeddingCacheEntries int `yaml:"embedding_cache_entries,omitempty"`
	// OllamaURL is the Ollama daemon endpoint. Empty resolves to
	// http://localhost:11434 (and the CKV_OLLAMA_ENDPOINT env override).
	OllamaURL string `yaml:"ollama_url"`
}

// ListenConfig controls how cks exposes its surface to callers.
//
// Transport selects the MCP transport: "stdio" (default) wires one client to
// a subprocess over stdin/stdout; "http" serves Streamable HTTP on HTTPAddr,
// which lets one host run several cks instances (different DBs/models) on
// different ports, reachable by remote Claude Code clients. cks.ops.health
// advertises each instance's model + indexed commit so callers can tell them
// apart.
//
// HTTPAddr is loopback-only unless AllowRemote is set: exposing the retrieval
// surface to the network is an explicit opt-in, not the default.
type ListenConfig struct {
	HTTPAddr string `yaml:"http_addr"`
	MCPStdio bool   `yaml:"mcp_stdio"`
	// Transport is "stdio" | "http". Empty falls back to MCPStdio (stdio)
	// for config back-compat.
	Transport string `yaml:"transport"`
	// AllowRemote permits binding HTTPAddr to a non-loopback (routable)
	// address. Default false keeps the listener loopback-only. When true the
	// HTTP server additionally filters by client source IP (see AllowedCIDRs):
	// by default only loopback + private/LAN ranges may connect, matching a
	// trusted local network. This is network-scope filtering, NOT per-client
	// auth — any device on the allowed network can connect.
	AllowRemote bool `yaml:"allow_remote"`
	// AllowedCIDRs optionally restricts which client source networks may
	// connect when AllowRemote is true. Empty means the default LAN policy
	// (loopback + RFC1918/ULA private + link-local). When set, ONLY loopback
	// and the listed CIDRs are allowed — use it to tighten to a single subnet
	// (e.g. "192.168.1.0/24"). Ignored when AllowRemote is false.
	AllowedCIDRs []string `yaml:"allowed_cidrs"`
}

// ResolvedTransport returns the effective MCP transport, defaulting to stdio
// when unset (honoring the legacy MCPStdio flag).
func (l ListenConfig) ResolvedTransport() string {
	if l.Transport != "" {
		return strings.ToLower(l.Transport)
	}
	return "stdio"
}

// LoggingConfig matches the footprint package's Mode/Level vocabulary and
// adds output directories for footprint and audit logs.
type LoggingConfig struct {
	Level        string `yaml:"level"`
	Mode         string `yaml:"mode"`
	FootprintDir string `yaml:"footprint_dir"`
	AuditDir     string `yaml:"audit_dir"`
	// Opt-in experiment telemetry. Default response contracts stay unchanged.
	MeasureBackendCalls bool `yaml:"measure_backend_calls,omitempty"`
}

// SanitizeConfig points to the sanitize ruleset and sets composer-wide
// fallback behavior.
type SanitizeConfig struct {
	// RulesPath is the YAML file with the SanitizeRuleset. May be empty
	// during early development if the composer is wired with an in-memory
	// ruleset instead.
	RulesPath string `yaml:"rules_path"`
	// DefaultAction is the RedactionAction to apply when a sanitize rule
	// omits its own action. Empty means the rule must specify its action.
	DefaultAction contract.RedactionAction `yaml:"default_action"`
	// FailClosedOnUnknownRule, when true, causes the composer to fail
	// closed (refuse the pack) on any unrecognized rule action or hit
	// against a malformed rule — defense in depth against ruleset edits
	// that bypass redaction by typo.
	FailClosedOnUnknownRule bool `yaml:"fail_closed_on_unknown_rule"`
}

// Default returns the out-of-box cks configuration. Used by tests and as a
// fallback when no config file is supplied.
func Default() *Config {
	return &Config{
		Version: configVersion,
		Backends: BackendsConfig{
			CKG: CKGConfig{TimeoutMS: 5000},
			CKV: CKVConfig{TimeoutMS: 3000},
		},
		Listen: ListenConfig{
			HTTPAddr: "127.0.0.1:8080",
			MCPStdio: true,
		},
		Logging: LoggingConfig{
			Level:        "info",
			Mode:         "prod",
			FootprintDir: "./logs/footprint",
			AuditDir:     "./logs/audit",
		},
		Sanitize: SanitizeConfig{
			RulesPath:               DefaultSanitizeRulesPath,
			DefaultAction:           contract.RedactionDrop,
			FailClosedOnUnknownRule: true,
		},
	}
}

// Load reads path as YAML and returns a validated Config.
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("config: read %q: %w", path, err)
	}
	// Expand ${VAR}/$VAR so one config file is portable across machines
	// (e.g. source_root: "${GO_STABLENET_ROOT}"); the per-machine path then
	// comes from the environment, not a committed/copied absolute path.
	return LoadBytes([]byte(os.ExpandEnv(string(data))))
}

// LoadBytes parses raw YAML bytes into a validated Config. Useful for tests
// and for callers that source configuration from non-file media (embed,
// remote KV, etc.).
func LoadBytes(data []byte) (*Config, error) {
	var c Config
	dec := yaml.NewDecoder(strings.NewReader(string(data)))
	dec.KnownFields(true) // reject typos / unknown keys to surface bugs early
	if err := dec.Decode(&c); err != nil {
		if errors.Is(err, ErrEmptyDocument) {
			return nil, err
		}
		return nil, fmt.Errorf("config: decode: %w", err)
	}
	if err := c.Validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

// Validate reports the first structural problem found in c. Acts as the
// gate that lets a Config through to runtime use.
func (c *Config) Validate() error {
	if c == nil {
		return fmt.Errorf("config: nil")
	}
	if err := c.Collection.Validate(); err != nil {
		return err
	}
	if err := c.Maintenance.Validate(); err != nil {
		return err
	}
	if c.Retrieval.RecallK < 0 || c.Retrieval.RecallK > 1000 {
		return errors.New("config: retrieval.recall_k must be 0 (default 20) or 1..1000")
	}
	if c.Version != configVersion {
		return fmt.Errorf("config: version=%d, want %d", c.Version, configVersion)
	}
	if c.Backends.CKV.EmbedDim < 0 {
		return fmt.Errorf("config: backends.ckv.embed_dim must be nonnegative")
	}
	if c.Backends.CKV.EmbeddingCacheEntries < 0 || c.Backends.CKV.EmbeddingCacheEntries > 65536 {
		return fmt.Errorf("config: backends.ckv.embedding_cache_entries must be 0..65536")
	}
	switch c.Semantic.OntologyMode {
	case "", "off", "baseline", "relations", "concept_text", "combined":
	default:
		return fmt.Errorf("config: semantic.ontology_mode must be off, baseline, concept_text, relations or combined")
	}
	if c.Semantic.OntologyBudgetMS < 0 || c.Semantic.OntologyBudgetMS > 5000 {
		return fmt.Errorf("config: semantic.ontology_budget_ms must be 0..5000 (0 selects 1000ms)")
	}
	switch c.Backends.CKV.QueryPrefixPolicy {
	case "", "registry", "none":
	default:
		return fmt.Errorf("config: backends.ckv.query_prefix_policy must be registry or none")
	}

	switch strings.ToLower(c.Logging.Level) {
	case "", "debug", "info", "warn", "warning", "error":
	default:
		return fmt.Errorf("config: logging.level=%q invalid (debug|info|warn|error)", c.Logging.Level)
	}
	switch strings.ToLower(c.Logging.Mode) {
	case "", "prod", "dev":
	default:
		return fmt.Errorf("config: logging.mode=%q invalid (prod|dev)", c.Logging.Mode)
	}
	if c.Logging.MeasureBackendCalls {
		mode, level := strings.ToLower(c.Logging.Mode), strings.ToLower(c.Logging.Level)
		if c.Logging.FootprintDir == "" || mode == "dev" || (level != "" && level != "info" && level != "debug") {
			return fmt.Errorf("config: logging.measure_backend_calls requires footprint_dir, prod mode and info/debug level")
		}
	}

	switch strings.ToLower(c.Listen.Transport) {
	case "", "stdio", "http":
	default:
		return fmt.Errorf("config: listen.transport=%q invalid (stdio|http)", c.Listen.Transport)
	}
	if strings.ToLower(c.Listen.Transport) == "http" && c.Listen.HTTPAddr == "" {
		return fmt.Errorf("config: listen.transport=http requires listen.http_addr")
	}
	// Loopback is enforced by default; AllowRemote is the explicit opt-in to
	// bind a routable address for remote callers.
	if c.Listen.HTTPAddr != "" && !c.Listen.AllowRemote {
		if err := validateLoopback(c.Listen.HTTPAddr); err != nil {
			return fmt.Errorf("config: listen.http_addr: %w (set listen.allow_remote: true to bind a routable address)", err)
		}
	}
	for _, cidr := range c.Listen.AllowedCIDRs {
		if _, _, err := net.ParseCIDR(cidr); err != nil {
			return fmt.Errorf("config: listen.allowed_cidrs: %q is not a valid CIDR: %w", cidr, err)
		}
	}

	switch c.Sanitize.DefaultAction {
	case "", contract.RedactionMask, contract.RedactionDrop, contract.RedactionFailClosed:
	default:
		return fmt.Errorf("config: sanitize.default_action=%q invalid", c.Sanitize.DefaultAction)
	}
	// Fail closed on LLM-boundary redaction: an empty rules_path loads a NOOP
	// ruleset that redacts nothing, so it is only permitted in dev mode. A prod
	// (or unset-mode) instance must point at a real ruleset.
	if c.Sanitize.RulesPath == "" && strings.ToLower(c.Logging.Mode) != "dev" {
		return fmt.Errorf("config: sanitize.rules_path is required unless logging.mode=dev " +
			"(an empty path disables secret redaction at the LLM boundary)")
	}

	if (c.Domain.ProjectDir == "") != (c.Domain.CorpusDir == "") {
		return fmt.Errorf("config: domain.project_dir and domain.corpus_dir must both be set or both empty")
	}

	return nil
}

// validateLoopback returns nil only when addr is a host:port pointing at a
// loopback address (127.0.0.0/8, ::1). Non-loopback bindings are rejected
// because cks should not expose its surface to remote callers.
func validateLoopback(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("invalid host:port %q: %w", addr, err)
	}
	if host == "localhost" {
		return nil
	}
	ip := net.ParseIP(host)
	if ip == nil {
		return fmt.Errorf("host %q is not an IP and not 'localhost'; non-loopback bindings are rejected", host)
	}
	if !ip.IsLoopback() {
		return fmt.Errorf("host %q is not a loopback address", host)
	}
	return nil
}

// ErrEmptyDocument is returned by LoadBytes when the input contains no YAML
// document at all (distinct from a syntactically valid empty mapping).
var ErrEmptyDocument = errors.New("config: empty YAML document")
