import importlib.util,subprocess,os,json,hashlib
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase86-coreml-preflight-20261020');s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env['PATH']='/usr/bin:/bin:/usr/sbin:/sbin';clang=subprocess.check_output(['xcrun','--find','clang'],env=env,text=True).strip();before=m.sha((root/'internal/vector/embed/coreml/bridge_darwin.m').read_bytes());m.write(out/'SCOPE.json',dict(kind='CoreML_native_array_layout_reproduction_not_model_inference',bridge_sha256=before,harness_sha256=m.sha((out/'token-layout.m').read_bytes()),actual_LLM_calls=0,embedding_inference_calls=0,model_downloads=0,production_source_changed=False))
for label,args in [('compile',[clang,'-Werror','-fobjc-arc',str(out/'token-layout.m'),'-framework','CoreML','-framework','Foundation','-o',str(out/'token-layout')]),('run',[str(out/'token-layout')])]:
 r=m.command(args,out,out/label,env,120);assert r['exit_code']==0 and not r['remaining_live_group_members']
assert before==m.sha((root/'internal/vector/embed/coreml/bridge_darwin.m').read_bytes());print((out/'run/stdout').read_text(),end='')
