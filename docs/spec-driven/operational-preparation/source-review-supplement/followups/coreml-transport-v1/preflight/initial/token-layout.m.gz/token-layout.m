#import <Foundation/Foundation.h>
#import <CoreML/CoreML.h>
#include <stdint.h>
#include <stdio.h>
int main(void) {
 @autoreleasepool {
  int64_t ids[3]={101,102,103}; NSError* error=nil;
  MLMultiArray* array=[[MLMultiArray alloc] initWithDataPointer:ids shape:@[@1,@3] dataType:MLMultiArrayDataTypeInt32 strides:@[@3,@1] deallocator:nil error:&error];
  if(error||!array) return 2;
  printf("{\"input\":[101,102,103],\"observed\":[%lld,%lld,%lld],\"model_inference_calls\":0}\n",[array[0] longLongValue],[array[1] longLongValue],[array[2] longLongValue]);
  return [array[0] longLongValue]==101 && [array[1] longLongValue]==0 && [array[2] longLongValue]==102 ? 0 : 3;
 }
}
