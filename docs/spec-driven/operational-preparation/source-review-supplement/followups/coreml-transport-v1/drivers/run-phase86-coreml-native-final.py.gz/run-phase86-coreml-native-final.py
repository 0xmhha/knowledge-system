import os,subprocess,importlib.util,json
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase86-coreml-native-final-20261020');out.mkdir()
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env['PATH']='/usr/bin:/bin:/usr/sbin:/sbin';clang=subprocess.check_output(['xcrun','--find','clang'],env=env,text=True).strip();sdk=subprocess.check_output(['xcrun','--sdk','macosx','--show-sdk-path'],env=env,text=True).strip()
names=['internal/vector/embed/coreml/bridge.h','internal/vector/embed/coreml/bridge_darwin.m','internal/vector/embed/coreml/testdata/transport.m'];sources={n:m.sha((root/n).read_bytes())for n in names};m.write(out/'SCOPE.json',dict(source_sha256=sources,clang=clang,SDK=sdk,actual_model_inference_calls=0,actual_LLM_calls=0,model_downloads=0))
for mode,flag in [('MRC','-fno-objc-arc'),('ARC','-fobjc-arc')]:
 for label,argv in [('compile',[clang,'-isysroot',sdk,'-Werror',flag,str(root/names[-1]),'-framework','CoreML','-framework','Foundation','-o',str(out/mode)]),('run',[str(out/mode)])]:
  r=m.command(argv,out,out/(mode+'-'+label),env,120);assert r['exit_code']==0 and not r['remaining_live_group_members']
 assert json.loads((out/(mode+'-run')/'stdout').read_text())['models_released']==2
for n,h in sources.items():assert m.sha((root/n).read_bytes())==h
print('native MRC/ARC token, tensor and per-instance ownership fixtures passed; actual inference0',flush=True)
