import hashlib,importlib.util,json,os,subprocess,threading,urllib.request,urllib.error
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');DATA=Path('/private/tmp/ks-phase84-scale-long-functions-20261019/data');WORK=Path('/private/tmp/ks-phase86-bge-compat-20261020');WORK.mkdir()
s=importlib.util.spec_from_file_location('owned',ROOT/'scripts/run-wi4-target-subscription.py');owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
s=importlib.util.spec_from_file_location('pilot',ROOT/'scripts/run-wi6-pair-pilot.py');pilot=importlib.util.module_from_spec(s);s.loader.exec_module(pilot)
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
old=Path('/private/tmp/ks-phase86-old85-baseline-20261020/ckv');new=Path('/private/tmp/ks-phase86-candidate-20261020/ckv');before=pilot.inventory(DATA);write(WORK/'payload-before.json',before);manifest=json.loads((DATA/'vector/manifest.json').read_text());assert manifest['embedding_model']=='bge-m3:latest'and manifest['source_mode']=='committed'and Path(manifest['src_root']).is_dir()
http=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):self.forward()
 def do_POST(self):self.forward()
 def forward(self):
  length=int(self.headers.get('Content-Length','0'));body=self.rfile.read(length);row=dict(method=self.command,path=self.path,request_sha256=sha(body));status=502;response=b''
  try:
   assert self.path in ('/api/tags','/api/embed')
   if body:
    value=json.loads(body);raw=value.get('input',[]);row.update(model=value.get('model'),inputs=1 if isinstance(raw,str)else len(raw))
   req=urllib.request.Request('http://localhost:11434'+self.path,data=body if self.command=='POST'else None,headers={'Content-Type':'application/json'},method=self.command)
   with urllib.request.urlopen(req,timeout=60)as r:status=r.status;response=r.read()
  except urllib.error.HTTPError as e:status=e.code;response=e.read()
  except Exception as e:row['failure']=type(e).__name__
  row.update(status=status,response_sha256=sha(response));http.append(row);self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(response)));self.end_headers();self.wfile.write(response)
proxy=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=None;failure=None;responses=[]
try:
 thread=threading.Thread(target=proxy.serve_forever,daemon=True);thread.start()
 env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin',CKV_OLLAMA_ENDPOINT='http://127.0.0.1:'+str(proxy.server_port),GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
 write(WORK/'SCOPE.json',dict(old_binary_sha256=sha(old.read_bytes()),new_binary_sha256=sha(new.read_bytes()),new_source_binding_sha256=sha(Path('/private/tmp/ks-phase86-candidate-20261020/source-binding.json').read_bytes()),driver_sha256=sha(Path(__file__).read_bytes()),actual_LLM_calls=0,paid_external_calls=0,CoreML_model_inference_calls=0))
 for label,binary in [('old-first',old),('old-repeat',old),('new',new)]:
  argv=[str(binary),'--embedder','ollama','--model-name','bge-m3:latest','--no-footprint','query','SyncStatusSubscription Unsubscribe eth downloader','--out',str(DATA/'vector'),'--json','--trace-id','phase86-bge-compat']
  r=owned.command(argv,WORK,WORK/label,env,180);assert r['exit_code']==0 and not r['remaining_live_group_members'];responses.append(json.loads((WORK/label/'stdout').read_text()))
 def compare(a,b):
  for name in ('hits','examples'):
   x=a.get(name,[])or[];y=b.get(name,[])or[];assert len(x)==len(y)
   for left,right in zip(x,y):
    assert {k:v for k,v in left.items()if k!='score'}=={k:v for k,v in right.items()if k!='score'}
    assert abs(left.get('score',0)-right.get('score',0))<=1e-5
 compare(responses[0],responses[1]);compare(responses[0],responses[2]);assert len(responses[2].get('hits',[]))>0
 write(WORK/'RESULT.json',dict(old_repeat_same=True,new_same_order_citations_snippets=True,score_absolute_tolerance=1e-5,hits=len(responses[2].get('hits',[])),examples=len(responses[2].get('examples',[])or[]),source_mode=manifest['source_mode'],model=manifest['embedding_model'],embedding_dim=manifest['embedding_dim'],owned_process_groups_remaining=0,actual_LLM_calls=0,paid_external_calls=0,CoreML_model_inference_calls=0,independent_approved=0,formal_completed=0))
except Exception as e:failure=dict(type=type(e).__name__,message=str(e))
finally:
 proxy.shutdown();proxy.server_close()
 if thread is not None:thread.join(3)
 after=pilot.inventory(DATA);write(WORK/'payload-after.json',after);write(WORK/'HTTP.json',http);write(WORK/'cleanup.json',dict(failure=failure,proxy_thread_live=thread.is_alive()if thread else False,payload_preserved=before==after,actual_LLM_calls=0,paid_external_calls=0))
if failure:raise RuntimeError(failure)
assert before==after and not thread.is_alive()and all(x['status']==200 for x in http)
print('old-repeat and new default BGE queries preserve positive ordered hits/citations/snippets; data preserved',flush=True)
