import os,json,shutil,subprocess,importlib.util
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');first=Path('/private/tmp/ks-phase86-native-20261020');out=Path('/private/tmp/ks-phase86-native-corrective1-20261020');out.mkdir();candidate=Path('/private/tmp/ks-phase86-candidate-20261020')
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
binding=json.loads((first/'source-binding.json').read_text());(out/'source-binding.json').write_bytes((first/'source-binding.json').read_bytes())
def check():
 for n,h in{**binding['source_sha256'],**binding['approved_input_sha256'],**binding['generated_input_sha256']}.items():assert m.sha((root/n).read_bytes())==h,n
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==binding['base_revision']
check();initial=json.loads((first/'receipts.json').read_text());assert [(r['label'],r['exit_code'])for r in initial]==[('build',0),('test',0),('race',1)];receipts=initial[:2]
for r in receipts:
 for suffix in ('stdout','stderr'):shutil.copy2(first/(r['label']+'.'+suffix),out/(r['label']+'.'+suffix))
m.write(out/'receipts.json',receipts);m.write(out/'REUSED-PASSED-COMMANDS.json',dict(source_binding_unchanged=True,reused_labels=['build','test'],source_root=str(first),reason='only the failed whole race and remaining commands are repeated; first failed race remains preserved'))
for name in ('TOOLS-BEFORE-LINT.json','package-boundary-proof.json'):shutil.copy2(first/name,out/name)
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','CGO_ENABLED','CC','CXX','PKG_CONFIG_PATH')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GOCACHE='/private/tmp/ks-go-cache',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
main=[('race',['go','test','-race','-json','-count=1','-timeout=20m','./...'],1440),('lint',['make','lint','GOLANGCI_LINT=/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint'],1200),('build-bins',['make','build-bins'],900),('build-runtime',['go','build','-o',str(out/'read-cks'),'./cmd/cks'],900),('build-info',['go','version','-m',str(out/'read-cks')],30)]
for label,argv,limit in main:
 check();r=m.command(argv,root,out/label,env,limit);r.update(label=label,source_head=binding['base_revision'],source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()))
 for stream in ('stdout','stderr'):shutil.copy2(out/label/stream,out/(label+'.'+stream))
 if label=='race':
  rows=[json.loads(x)for x in(out/'race.stdout').read_text().splitlines()];r['tests']={a:sum(x.get('Action')==a and bool(x.get('Test'))for x in rows)for a in ('pass','fail','skip')};r['packages']={a:sum(x.get('Action')==a and not x.get('Test')for x in rows)for a in ('pass','fail','skip')}
 receipts.append(r);m.write(out/'receipts.json',receipts);print(label,'exit',r['exit_code'],flush=True);assert r['exit_code']==0 and not r['remaining_live_group_members'];check()
assert m.sha((out/'read-cks').read_bytes())==m.sha((candidate/'cks').read_bytes());m.write(out/'binary.json',dict(sha256=m.sha((out/'read-cks').read_bytes()),source_head=binding['base_revision'],source_mode=binding['source_mode'],native_source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
for name,exe,path in [('graph','ckg','./cmd/graph'),('vector','ckv','./cmd/vector')]:
 for label,argv in [('build-'+name+'-runtime',['go','build','-o',str(out/('read-'+name)),path]),(name+'-build-info',['go','version','-m',str(out/('read-'+name))])]:
  check();r=m.command(argv,root,out/label,env,900);r.update(label=label,source_head=binding['base_revision'],source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()));m.write(out/(label+'-receipt.json'),r);assert r['exit_code']==0 and not r['remaining_live_group_members'];check()
 assert m.sha((out/('read-'+name)).read_bytes())==m.sha((candidate/exe).read_bytes());m.write(out/(name+'-binary.json'),dict(sha256=m.sha((out/('read-'+name)).read_bytes()),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
groups=[]
for r in receipts:
 members=[x for x in subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines()if len(v:=x.split())==3 and int(v[1])==r['pid']];assert not members;groups.append(dict(label=r['label'],pgid=r['pid'],remaining_live_group_members=0))
m.write(out/'process-groups.json',groups);m.write(out/'installed-tools.json',dict(go=subprocess.check_output([go+'/bin/go','version'],text=True).strip(),lint=subprocess.check_output(['/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint','version'],text=True).strip()));print('unchanged-source corrective race and remaining native checks complete',flush=True)
