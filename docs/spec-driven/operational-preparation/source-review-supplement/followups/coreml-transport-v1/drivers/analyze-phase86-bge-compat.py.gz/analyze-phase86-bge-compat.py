import json,hashlib
from pathlib import Path
ROOT=Path('/private/tmp/ks-phase86-bge-compat-corrective1-20261020');OUT=Path('/private/tmp/ks-phase86-bge-compat-analysis-20261020');OUT.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
responses={n:json.loads((ROOT/n/'stdout').read_text())for n in ('old-first','old-repeat','new')}
for n in responses:
 r=json.loads((ROOT/n/'receipt.json').read_text());assert r['exit_code']==0 and r['reaped']and not r['timeout']and not r['remaining_live_group_members']
checks=[]
for label in ('old-repeat','new'):
 for group in ('hits','examples'):
  a=responses['old-first'].get(group,[])or[];b=responses[label].get(group,[])or[];assert len(a)==len(b)
  for i,(left,right)in enumerate(zip(a,b)):
   assert {k:v for k,v in left.items()if k!='score'}=={k:v for k,v in right.items()if k!='score'}
   s,t=left['score'],right['score'];assert set(s)==set(t)
   for key,value in s.items():
    if isinstance(value,float):assert abs(value-t[key])<=1e-5
    else:assert value==t[key]
   checks.append(dict(comparison=label,group=group,position=i,non_score_fields_equal=True,score_breakdown_exactly_equal=s==t))
assert len(responses['new']['hits'])==10
cleanup=json.loads((ROOT/'cleanup.json').read_text());assert cleanup['failure']['type']=='TypeError'and cleanup['failure']['message']=="unsupported operand type(s) for -: 'dict' and 'dict'"and cleanup['payload_preserved']and not cleanup['proxy_thread_live']
raw_hashes={str(f.relative_to(ROOT)):sha(f.read_bytes())for f in ROOT.rglob('*')if f.is_file()}
result=dict(old_repeat_same=True,new_same_order_citations_snippets=True,score_absolute_tolerance=1e-5,all_score_breakdowns_exact=True,hits=10,examples=len(responses['new'].get('examples',[])or[]),source_mode='committed',model='bge-m3:latest',embedding_dim=1024,owned_process_groups_remaining=0,actual_LLM_calls=0,paid_external_calls=0,CoreML_model_inference_calls=0,independent_approved=0,formal_completed=0,analysis_only_no_query_rerun=True,initial_analysis_failure_preserved=True)
(OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'CHECKS.json').write_text(json.dumps(checks,indent=2)+'\n');(OUT/'CLARIFICATION.json').write_text(json.dumps(dict(reason='score is a structured ScoreBreakdown, not a scalar; all three actual CLI queries already exited0',runtime_root=str(ROOT),original_runtime_artifact_sha256=raw_hashes,source_driver_sha256=sha(Path(__file__).read_bytes()),new_model_calls=0,raw_runtime_not_modified=True),indent=2)+'\n');print(json.dumps(result))
