import os,json,importlib.util
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase86-guardian-diagnostic-20261020');out.mkdir()
path=root/'internal/setup/command_guard_test.go';original=path.read_text();start=original.index('func TestGuardianAbsoluteDeadlineWorksWhileOwnerSocketStaysOpen');end=original.index('\nfunc TestGuardianPastAbsoluteDeadline',start);block=original[start:end]
old='''\tif err := cmd.Run(); err == nil {
\t\tt.Fatal("expired deadline reported success")
\t}''';new='''\tdiagnostic, err := os.Create(filepath.Join(root, "guardian.stderr"))
 if err != nil {t.Fatal(err)}
 defer func(){_ = diagnostic.Close()}()
 cmd.Stdout,cmd.Stderr=diagnostic,diagnostic
 runErr:=cmd.Run()
 finished:=time.Now()
 if runErr == nil {t.Fatal("expired deadline reported success")}
 t.Logf("guardian start=%d end=%d state=%v elapsed=%v",start.UnixNano(),finished.UnixNano(),cmd.ProcessState,time.Since(start))''';assert old in block;block=block.replace(old,new)
old='''\tif _, err := os.Stat(late); !os.IsNotExist(err) {
\t\tt.Fatal("deadline left a late writer")
\t}''';new=''' info,statErr:=os.Stat(late)
 if !os.IsNotExist(statErr) {
  data,readErr:=os.ReadFile(late);diagnosticBytes,_:=os.ReadFile(filepath.Join(root,"guardian.stderr"))
  if statErr != nil {t.Fatalf("late marker stat error: %v",statErr)}
  t.Fatalf("deadline marker content=%q read=%v mtime=%d after_guardian_end=%v guardian=%s",data,readErr,info.ModTime().UnixNano(),info.ModTime().After(finished),diagnosticBytes)
 }''';assert old in block;block=block.replace(old,new)
changed=original[:start]+block+original[end:];(out/'command_guard_test.go').write_text(changed)
main=root/'internal/setup/guardian_testmain_test.go';s=main.read_text().replace('"os"','"os"\n "fmt"').replace('if RunGuardedDatasetStep(os.Args[2]) != nil {','if err:=RunGuardedDatasetStep(os.Args[2]); err != nil {\n fmt.Fprintf(os.Stderr,"guardian result: %v\\n",err)');(out/'guardian_testmain_test.go').write_text(s)
(out/'overlay.json').write_text(json.dumps({'Replace':{str(path):str(out/'command_guard_test.go'),str(main):str(out/'guardian_testmain_test.go')}}))
spec=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
m.write(out/'SCOPE.json',dict(original_source_sha256={str(path.relative_to(root)):m.sha(path.read_bytes()),str(main.relative_to(root)):m.sha(main.read_bytes())},overlay_sha256=m.sha((out/'overlay.json').read_bytes()),purpose='diagnostics only: same deadline/worker; record marker time relative to guardian end; original assertion unchanged'))
r=m.command(['go','test','-race','-overlay',str(out/'overlay.json'),'-json','-count=80','-run','^TestGuardianAbsoluteDeadlineWorksWhileOwnerSocketStaysOpen$','./internal/setup'],root,out/'run',env,240);print('diagnostic exit',r['exit_code'],'remaining',r['remaining_live_group_members'])
