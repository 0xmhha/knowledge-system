import os,json,subprocess,importlib.util,hashlib
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase86-candidate-20261020');out.mkdir()
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
old=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/public-v2-surface-v1/source-binding.json').read_text());names=set(old['source_sha256']);names.update(n for n in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.go'],cwd=root,text=True).splitlines()if n.startswith(('cmd/','pkg/','internal/')));names.update(['internal/vector/embed/coreml/testdata/transport.m','internal/vector/embed/coreml/testdata/wordlevel-tokenizer.json'])
revision='75749926fdd5b1119881915fd6c7ff62015736c2';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==revision
format=subprocess.check_output(['git','rev-parse','--show-object-format'],cwd=root,text=True).strip();assert format=='sha1'
base={}
for row in subprocess.check_output(['git','ls-tree','-r','-z',revision],cwd=root).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);base[name.decode()]=meta.split()[2].decode()
current={};changes=[]
for n in sorted(names):
 raw=(root/n).read_bytes();current[n]=m.sha(raw);oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 if base.get(n)!=oid:changes.append(n)
generated={str(p.relative_to(root)):m.sha(p.read_bytes())for p in sorted((root/'internal/system/viewer/web_assets/app').rglob('*'))if p.is_file()};assert len(generated)==46
binding=dict(base_revision=revision,source_mode='working_tree_native_CoreML_transport_and_explicit_CKV_CLI',source_sha256=current,generated_input_sha256=generated,approved_input_sha256=old['approved_input_sha256'],changed_native_files=changes,profile_fixture_files=['internal/vector/embed/coreml/testdata/transport.m','internal/vector/embed/coreml/testdata/wordlevel-tokenizer.json'],actual_model_inference_calls=0)
assert sum(n.endswith('.go')for n in changes)==13
assert 'scripts/check-operational-acceptance.py'not in current
m.write(out/'source-binding.json',binding)
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
for name,path in [('cks','./cmd/cks'),('ckg','./cmd/graph'),('ckv','./cmd/vector')]:
 r=m.command(['go','build','-o',str(out/name),path],root,out/('build-'+name),env,900);assert r['exit_code']==0 and not r['remaining_live_group_members']
 for n,h in{**current,**generated,**binding['approved_input_sha256']}.items():assert m.sha((root/n).read_bytes())==h,n
 m.write(out/(name+'-binary.json'),dict(sha256=m.sha((out/name).read_bytes()),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()),source_revision=revision,source_mode=binding['source_mode']))
 (out/(name+'-build-info.txt')).write_bytes(subprocess.check_output(['go','version','-m',str(out/name)],env=env,cwd=root))
print('candidate built',len(current),'bound sources; Go',sum(n.endswith('.go')for n in current),'changed Go',sum(n.endswith('.go')for n in changes),flush=True)
