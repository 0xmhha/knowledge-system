package setup

import (
	"os"
 "fmt"
	"testing"
)

func TestMain(m *testing.M) {
	if len(os.Args) == 3 && os.Args[1] == "__dataset-step" {
		if err:=RunGuardedDatasetStep(os.Args[2]); err != nil {
 fmt.Fprintf(os.Stderr,"guardian result: %v\n",err)
			os.Exit(1)
		}
		os.Exit(0)
	}
	os.Exit(m.Run())
}
