package main

import (
	"errors"
	"fmt"
	"net"
	"os"
	"strings"

	"github.com/spf13/cobra"

	"github.com/0xmhha/knowledge-system/internal/vector/query"
	kmcp "github.com/0xmhha/knowledge-system/pkg/mcp"
	ckvmcp "github.com/0xmhha/knowledge-system/pkg/vector/mcp"
)

type mcpOpts struct {
	out       string
	httpAddr  string
	namespace string
}

func newMCPCmd() *cobra.Command {
	opts := &mcpOpts{}

	cmd := &cobra.Command{
		Use:   "mcp",
		Short: "Run the CKV MCP server (stdio JSON-RPC)",
		Long: `Speaks MCP JSON-RPC over stdio by default, or HTTP when --http is set.

Tools exposed (15):

  Search:
    cks.context.semantic_search    — full retrieval pipeline (embed → vector → rerank → boost → enrich)
    cks.context.keyword_search     — BM25 keyword search for exact symbol / domain vocabulary
    cks.context.vector_search      — ANN with a pre-computed vector

  Refinement:
    cks.context.narrow_candidates  — filter a hit set by category / language / path
    cks.context.expand_in_file     — return neighbouring chunks of a hit

  Meta:
    cks.context.find_invariants    — list CRITICAL / INVARIANT / panic-heuristic invariants
    cks.context.get_conventions    — per-package AST stats (errors, loggers, naming, concurrency)
    cks.context.explain_match      — explain why a chunk matched (vector + BM25 + matched tokens)

  Helpers:
    cks.context.embed              — text → vector
    cks.context.rerank             — BM25 + RRF rerank on candidate IDs
    cks.context.related_changes    — PR breadcrumbs by file

  Operations:
    cks.ops.health                 — index identity probe
    cks.ops.get_freshness          — git diff vs indexed_head
    cks.ops.warmup                 — pre-load embedder
    cks.ops.index                  — trigger full / incremental rebuild

Full schema reference: docs/vector/mcp-tools.md.

Register with Claude Code (stdio):
  claude mcp add cks --command "$(pwd)/bin/ckv mcp --out=$(pwd)/ckv-data"

Run as HTTP server (multi-client):
  ckv mcp --out=$(pwd)/ckv-data --http=:8080`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return runMCP(opts)
		},
	}

	f := cmd.Flags()
	f.StringVar(&opts.out, "out", "./ckv-data", "data directory")
	f.StringVar(&opts.httpAddr, "http", "", "HTTP listen address on loopback (e.g. :8080 = 127.0.0.1:8080); empty uses stdio")
	f.StringVar(&opts.namespace, "namespace", "", "tool-namespace root override (default: env/build-time, else \"cks\")")

	return cmd
}

func runMCP(opts *mcpOpts) error {
	fp := newFootprint(opts.out, "")
	defer func() { _ = fp.Close() }() // diagnostic log only; never fails the command

	emb, cleanup, err := resolveEmbedder(globalFlags.embedder, globalFlags.modelDir)
	if err != nil {
		return err
	}
	defer cleanup()

	eng, err := query.Open(opts.out, emb, query.WithFootprint(fp))
	if err != nil {
		if errors.Is(err, query.ErrIndexUnavailable) {
			fmt.Fprintln(os.Stderr, "ckv mcp:", err)
		}
		return err
	}
	defer func() { _ = eng.Close() }() // read-only query engine

	// Client-visible tool names follow the shared namespace rule (pkg/mcp):
	// "cks" root by default, overridden by --namespace, the
	// KNOWLEDGE_MCP_NAMESPACE env, or the build-time -ldflags root.
	ckvmcp.SetNamespaceRoot(kmcp.Root(opts.namespace, "cks"))
	srv := ckvmcp.NewServer(eng, ckvmcp.WithFootprint(fp))

	if opts.httpAddr != "" {
		addr, err := loopbackListenAddr(opts.httpAddr)
		if err != nil {
			return err
		}
		fmt.Fprintf(os.Stderr, "ckv mcp: HTTP listening on %s\n", addr)
		if err := srv.ServeHTTP(addr); err != nil {
			return fmt.Errorf("mcp serve http: %w", err)
		}
		return nil
	}

	// stdio default: reserves stdout for JSON-RPC frames, so logs only to stderr.
	if err := srv.ServeStdio(); err != nil {
		return fmt.Errorf("mcp serve stdio: %w", err)
	}
	return nil
}

// loopbackListenAddr binds the unauthenticated HTTP transport to loopback:
// an empty host becomes 127.0.0.1 and any other non-loopback host is
// refused.
func loopbackListenAddr(addr string) (string, error) {
	host, port, err := net.SplitHostPort(addr)
	if err != nil {
		return "", fmt.Errorf("ckv mcp: --http %q: %w", addr, err)
	}
	if host == "" {
		return net.JoinHostPort("127.0.0.1", port), nil
	}
	if strings.EqualFold(host, "localhost") {
		return addr, nil
	}
	if ip := net.ParseIP(host); ip != nil && ip.IsLoopback() {
		return addr, nil
	}
	return "", fmt.Errorf("ckv mcp: --http %q: the HTTP transport has no authentication and binds loopback only", addr)
}
