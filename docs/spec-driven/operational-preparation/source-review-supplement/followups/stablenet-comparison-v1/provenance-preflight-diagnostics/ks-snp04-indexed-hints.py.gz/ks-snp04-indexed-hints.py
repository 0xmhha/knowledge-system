from ks_snp04_common import *
import sqlite3,collections,gzip,shutil
fixtures=json.load(open(O/'fixtures.json'));projections=[];seen=set()
for f in fixtures:
 version=pathlib.Path(f['version']);db=sqlite3.connect('file:'+str(version/'vector/vector.db')+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
 paths=[O/('search-'+f['project'])/'messages.json']
 for path in(O/'diagnostics').rglob('messages.json'):
  if(f['project']=='go-wemix')==(path.parent.name=='search-go-wemix'):paths.append(path)
 for path in paths:
  for message in json.load(open(path)):
   if message['request']['method']!='tools/call'or failed(message['response']):continue
   result=payload(message['response'])
   for hit in(result.get('hits')or[]):
    if not hit.get('text')or hit.get('non_citable_metadata'):continue
    key=sha(json.dumps({'project':f['project'],'citation':hit['citation'],'kind':hit.get('chunk_kind'),'text':hit['text']},sort_keys=True).encode())
    if key in seen:continue
    seen.add(key);c=hit['citation'];rows=db.execute('select id,file,start_line,end_line,commit_hash,chunk_kind,text,content_sha256,flow_meta,provenance from chunks where file=? and start_line=? and end_line=? and chunk_kind=?',(c['file'],c['start_line'],c['end_line'],hit['chunk_kind'])).fetchall();matches=[dict(r)for r in rows if r['commit_hash']==c['commit_hash']and r['text'].strip().startswith(hit['text'].strip())];assert matches,(f['project'],c,hit['chunk_kind']);assert len(matches)==1;projections.append({'project':f['project'],'hit_key':key,'row':matches[0],'semantics':'indexed hint; not an assertion this Text is the literal cited code body'})
 db.close()
dump(O/'indexed-hints.json',projections);print('unique indexed hint projections verified',len(projections),collections.Counter(r['row']['chunk_kind']for r in projections),flush=True)
