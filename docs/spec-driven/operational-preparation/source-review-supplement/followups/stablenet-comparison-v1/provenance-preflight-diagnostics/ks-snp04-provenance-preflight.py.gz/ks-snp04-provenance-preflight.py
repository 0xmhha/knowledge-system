from ks_snp04_common import *
import gzip
fixtures=json.load(open(O/'fixtures.json'));count=0;blobs={}
def verify(f,c,text=None,structured=False):
 global count
 v=pathlib.Path(f['version']);origin,path=c.get('origin_id','repo'),c['file']
 if path.startswith('@cks/docs/'):
  index,path=path[len('@cks/docs/'):].split('/',1);origin='docs:corpus.'+index
 manifest=json.load(open(v/'sources/manifest.json'));r=next(r for r in manifest['files']if r['origin_id']==origin and r['path']==path);raw=(v/'sources/blobs'/r['sha256']).read_bytes();assert sha(raw)==r['sha256'];parts=raw.split(b'\n');lines=[x+b'\n'for x in parts[:-1]]+([parts[-1]]if parts[-1]else[]);body=b''.join(lines[c['start_line']-1:c['end_line']]);assert c['start_line']>0 and c['end_line']<=len(lines)
 if structured:assert all(c.get(k)==value for k,value in f['coordinates'].items())and c['file_sha256']==r['sha256']and c['content_sha256']==sha(body)
 if text is not None:assert text.strip()==body.decode().strip(),(f['project'],path,c['start_line'],repr(text[:80]),repr(body[:80]))
 count+=1;blobs[r['sha256']]=True
for f in fixtures:
 paths=[O/('search-'+f['project'])/'messages.json']
 for p in(O/'diagnostics').rglob('messages.json'):
  if(f['project']=='go-wemix')==(p.parent.name=='search-go-wemix'):paths.append(p)
 for p in paths:
  for row in json.load(open(p)):
   if row['request']['method']!='tools/call'or failed(row['response']):continue
   result=payload(row['response'])
   for hit in(result.get('hits')or[]):
    if not hit.get('non_citable_metadata'):verify(f,hit['citation'],hit.get('text'))
   for cite in result.get('citations',[]):verify(f,cite,structured=True)
   for body in result.get('bodies',[]):verify(f,body['citation'],body['text'],True)
 for concept in ['staking','staking-policy','consensus','finality','mempool-admission','transaction-ordering']:
  result=json.load(open(O/'comparison'/('matrix-'+concept+'.json')));group=next(g for g in result['groups']if g['participant']['scope']['coordinates']==f['coordinates'])
  for cell in group['cells']:
   for mapping in cell['mappings']:
    for e in mapping['binding']['evidence']:verify(f,e['reference']['citation'],e['body'],True)
dump(O/'provenance-preflight.json',{'source_checks':count,'unique_source_blob_hashes':len(blobs),'scope':'early original-response/archive comparison while full native race pending; not independent samples or quality acceptance'});print('actual response/source range/hash checks',count,'unique blobs',len(blobs),flush=True)
