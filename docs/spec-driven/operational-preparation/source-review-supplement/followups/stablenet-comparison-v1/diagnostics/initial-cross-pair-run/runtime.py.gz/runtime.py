from ks_snp04_common import *
import subprocess,sqlite3,copy,stat,os,urllib.request,collections
assert json.load(open(O/'build-exit.json'))['exit_code']==0
original=pathlib.Path('/Users/kevin/work/github/0xmhha/auto-coding/chain/go-stablenet');clone=O/'stablenet-source'
if not clone.exists():
 subprocess.run(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(original),str(clone)],check=True,capture_output=True);subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(clone),'checkout','--detach','0bf2f4d1bfeb6605006d556957ef8c045d8f8ed8'],check=True,capture_output=True)
assert not subprocess.check_output(['git','-C',str(clone),'status','--porcelain'])
fixtures=[]
for label,version,source in [('go-stablenet',O/'stablenet/retained-origins-v2',clone),('go-wemix',O/'wemix/bge-source-v1',O/'source')]:
 identity=json.load(open(version/'dataset-identity.json'));manifest=json.load(open(version/'sources/manifest.json'));coords={k:identity['source'][k]for k in ['project_id','snapshot_id','source_mode']};coords.update(dataset_id=identity['dataset_id'],base_commit=identity['source']['source_commit'])
 fixtures.append({'project':label,'original_root':str(original.parent/label),'source_commit':coords['base_commit'],'owned_clone':str(source),'version':str(version),'coordinates':coords,'origins':sorted(set(r['origin_id']for r in manifest['files'])),'source_files':len(manifest['files']),'source_manifest_sha256':sha((version/'sources/manifest.json').read_bytes()),'embedding':identity['embedding_identity'],'quality_acceptance':False,'prepared_git_status':subprocess.check_output(['git','-C',str(source),'status','--porcelain=v1'],text=True).strip()})
dump(O/'fixtures.json',fixtures);dump(O/'summary.json',{'actual_native_dataset_builds':2,'build_reuse':'go-stablenet retained BGE build; fresh go-wemix held BGE build','quality_acceptance':False})
assert fixtures[0]['embedding']==fixtures[1]['embedding']
def inventory(p):
 rows={}
 for x in sorted(p.rglob('*')):
  if x.is_file():
   h=__import__('hashlib').sha256()
   with x.open('rb')as stream:
    for b in iter(lambda:stream.read(4<<20),b''):h.update(b)
   rows[str(x.relative_to(p))]={'sha256':h.hexdigest(),'bytes':x.stat().st_size,'mode':x.stat().st_mode&0o777}
 return rows
dump(O/'owned-before.json',{f['project']:inventory(pathlib.Path(f['version']))for f in fixtures})
queries=[{'id':'C1','concept':'consensus','keyword':'verifySeal','prompt':'Explain consensus seal signer authorization and validator membership checks.'},{'id':'C2','concept':'consensus','keyword':'QuorumSize','prompt':'Explain validator quorum thresholds and commit message validation.'},{'id':'C3','concept':'mempool-admission','keyword':'nonce','prompt':'Explain transaction pool admission validation for nonce, gas and transaction fee.'},{'id':'C4','concept':'transaction-ordering','keyword':'Less','prompt':'Explain transaction ordering by price and time in block construction.'},{'id':'C5','concept':'staking-policy','keyword':'staking','prompt':'Where is validator staking eligibility or stake weighted voting policy defined?'},{'id':'C6','concept':'finality','keyword':'commit','prompt':'What source evidence defines finality, commit conditions and rollback assumptions?'}]
dump(O/'query-inputs.json',{'inputs':queries,'exposed_diagnostic_inputs':True,'independent_gold':False,'k':10,'comparison_limit':'same embedding but different source/corpus/policy coverage; technical source isolation only'})
results=[];boundaries=[];common=[]
for f in fixtures:
 label=f['project'];v=pathlib.Path(f['version']);cfg=config(label,v,pathlib.Path(f['owned_clone']));c=Client('search-'+label,[str(O/'read-cks'),'mcp','--config',str(cfg)])
 try:
  c.initialize();assert payload(c.call('health','cks.ops.health'))['serviceable'];c.call('ontology-status','cks.semantic.status')
  for q in queries:
   outcomes={}
   for kind,name,args in [('keyword','search_text',{'query':q['keyword'],'k':10,'exclude_tests':True}),('vector-go','semantic_search',{'query':q['prompt'],'k':10,'language':'go','exclude_tests':True}),('vector-all','semantic_search',{'query':q['prompt'],'k':10,'exclude_tests':True}),('v2','get_for_task_v2',{'prompt':q['prompt'],'intent':'arch_explain','explain_ontology':True})]:
    r=c.call(q['id']+'-'+kind,'cks.context.'+name,args);outcomes[kind]={'ok':not failed(r),'count':len(payload(r).get('citations'if kind=='v2'else'hits')or[]),'error':payload(r)if failed(r)else None}
   results.append({'project':label,'input_id':q['id'],'outcomes':outcomes});dump(O/'search-results.json',results);print(label,q['id'],outcomes,flush=True)
  db=sqlite3.connect('file:'+str(v/'graph/graph.db')+'?mode=ro&immutable=1',uri=True);node=db.execute("select id,canonical_id,file_path from nodes where qualified_name='types.Transaction.Size'").fetchone();db.close();assert node
  base=payload(c.call('shared-name-baseline','cks.context.value_dependencies',{'node_id':node[0]}));assert base.get('analysis');src=base['analysis']['source'];common.append({'project':label,'node':list(node),'source':src,'snapshot_sha256':base['snapshot_sha256'],'coordinates':f['coordinates']})
  other=fixtures[1]if label=='go-stablenet'else fixtures[0]
  for key,value in [('expected_commit',other['source_commit']),('expected_source_sha256','0'*64),('expected_snapshot_sha256',other['coordinates']['snapshot_id'])]:
   r=c.call('foreign-'+key,'cks.context.value_dependencies',{'node_id':node[0],key:value});p=payload(r);assert p['status']=='source_mismatch'and p['analysis']is None;boundaries.append({'project':label,'case':key,'status':p['status']})
  foreign=c.call('foreign-wbft-node','cks.context.value_dependencies',{'node_id':'90591deae205962f'})
  if label=='go-stablenet':assert payload(foreign).get('analysis')
  if label=='go-wemix':assert payload(foreign)['status']=='not_found';boundaries.append({'project':label,'case':'foreign-wbft-node','status':'not_found'})
  r=c.call('exact-pin-recovered','cks.context.value_dependencies',{'node_id':node[0],'expected_commit':src['commit'],'expected_source_sha256':src['sha256'],'expected_snapshot_sha256':base['snapshot_sha256']});assert payload(r)['analysis']['source']==src
  assert payload(c.call('health-after','cks.ops.health'))['serviceable']
 finally:c.close()
dump(O/'shared-symbols.json',common);dump(O/'boundary-results.json',boundaries)
# Deliberately cross-wire actual graph/vector projects in two owned configs.
for a,b in [(fixtures[0],fixtures[1]),(fixtures[1],fixtures[0])]:
 name='swapped-'+a['project'];cfg=config(name,pathlib.Path(a['version']),pathlib.Path(a['owned_clone']));cfg.write_text(cfg.read_text().replace('path: '+a['version']+'/vector','path: '+b['version']+'/vector'));c=Client(name,[str(O/'read-cks'),'mcp','--config',str(cfg)])
 try:
  try:c.initialize();raise AssertionError('cross-project graph/vector startup admitted')
  except ValueError:pass
 finally:c.close()
 life=json.load(open(c.path/'lifecycle.json'));assert life['exit_code']==1 and life['child_reaped']and not life['terminate_sent'];assert json.load(open(c.path/'stderr.txt'))['code']=='operation_failed'
 boundaries.append({'project':a['project'],'case':'actual-cross-project-graph-vector','startup_refused':True,'exit_code':1});dump(O/'boundary-results.json',boundaries)
# Execute the established real-project comparison checks using fresh BGE datasets,
# the same clean tested reader and a durable owned stdio client.
source=(R/'scripts/verify-real-project-comparison.py').read_text();source=source.replace("ROOT=Path(__file__).resolve().parents[1]","ROOT=Path("+repr(str(R))+")")
source=source.replace("spec.loader.exec_module(wire)","spec.loader.exec_module(wire)\n    from ks_snp04_common import ComparisonClient\n    wire.Client=ComparisonClient")
source=source.replace("str(ROOT/'bin/cks')","str(Path("+repr(str(O/'read-cks'))+"))")
source=source.replace("os.readlink(version.parent/'current')","(os.readlink(version.parent/'current') if (version.parent/'current').is_symlink() else '<absent-held>')")
source=source.replace("(out/'review.md')","(out/'review.txt')")
source=source.replace('source excerpts for an unexecuted study;', 'source excerpts for an exposed technical comparison; independent acceptance unexecuted;')
runner=O/'comparison-runner.py.txt';runner.write_text(source)
sys.argv=[str(runner),'--prepared',str(O),'--out',str(O/'comparison')];exec(compile(source,str(runner),'exec'),{'__name__':'__main__','__file__':str(runner)})
print('paired BGE retrieval and actual concept comparison PASS',flush=True)
