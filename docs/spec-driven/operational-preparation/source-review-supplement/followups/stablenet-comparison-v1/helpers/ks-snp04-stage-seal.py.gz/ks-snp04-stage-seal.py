from ks_snp04_common import *
import gzip
D=R/'docs/spec-driven';P=D/'operational-preparation/source-review-supplement/followups/stablenet-comparison-v1';proposal=D/'OPERATIONAL-ACCEPTANCE-DECISION-PROPOSAL.json';rule=D/'operational-preparation/source-review-supplement/followups/.gitattributes';refpath=str((P/'manifest.json').relative_to(R))
folder=P/'validation/staging';folder.mkdir(exist_ok=True)
for label in ['initial','final']:
 p=pathlib.Path('/private/tmp')/('ks-snp04-staged-whitespace-'+label+'.log');(folder/(label+'.log.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
summary=json.load(open(P/'validation-summary.json'));summary['staged_raw_log_whitespace']={'initial_exit_code':2,'cause':'the restored historical diagnostic intentionally contains the trailing whitespace that it reported as rejected','resolution':'one exact historical diagnostic path has whitespace checks disabled; its original bytes and prior manifest hash are unchanged','policy':str(rule.relative_to(R)),'policy_sha256':sha(rule.read_bytes()),'final_exit_code':0};dump(P/'validation-summary.json',summary)
p=P/'REPORT.txt';text=p.read_text();note='커밋 전 공백 검사: 복원한 과거 공백 거부 진단1파일에 의도된 trailing space가 있어 최초 exit2였다. 원문을 고치지 않고 followups/.gitattributes의 정확한 해당 경로1개에만 공백 검사 예외를 선언한 후 exit0을 확인했다. 실제 Go fmt/lint와 원문 SHA 검증은 그대로 유지한다.'
if note not in text:p.write_text(text+'\n'+note+'\n')
(P/'helpers/ks-snp04-stage-seal.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
manifest=json.load(open(P/'manifest.json'));manifest['artifacts']={str(p.relative_to(P)):sha(p.read_bytes())for p in sorted(P.rglob('*'))if p.is_file()and p!=P/'manifest.json'};dump(P/'manifest.json',manifest);digest=sha((P/'manifest.json').read_bytes())
def refresh(d):
 if isinstance(d,dict):
  if d.get('manifest')==refpath:d['sha256']=digest
  if d.get('path')==str(proposal.relative_to(R)):d['sha256']=sha(proposal.read_bytes())
  for v in d.values():refresh(v)
 elif isinstance(d,list):
  for v in d:refresh(v)
d=json.load(open(proposal));refresh(d);dump(proposal,d)
for name in ['OPERATIONAL-ACCEPTANCE-PROGRESS.json','OPERATIONAL-ACCEPTANCE-PROTOCOL.json','operational-preparation/source-review-supplement/GAPS.json']:
 p=D/name;d=json.load(open(p));refresh(d);dump(p,d)
print('raw diagnostic preserved; narrow staging policy and final evidence references sealed',flush=True)
