from ks_snp04_common import *
c=Client('cross-configuration-probe-v2',[str(O/'read-cks'),'mcp','--config',str(O/'swapped-go-stablenet.yaml')])
try:
 c.initialize()
 for label,name,args in [('health','cks.ops.health',{}),('v2','cks.context.get_for_task_v2',{'prompt':'Explain transaction pool admission','intent':'arch_explain'}),('legacy-pack','cks.context.get_for_task',{'prompt':'Explain transaction pool admission','intent':'arch_explain'}),('keyword','cks.context.search_text',{'query':'QuorumSize','k':3}),('semantic','cks.context.semantic_search',{'query':'Explain transaction pool admission','k':3})]:
  r=c.call(label,name,args);p=payload(r);print(label,'error',failed(r),'keys',list(p),'code',p.get('code'),'serviceable',p.get('serviceable'),'hits',len(p.get('hits')or[]),flush=True)
finally:c.close()
