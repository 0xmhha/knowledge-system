from ks_snp04_common import *
import shutil,gzip,subprocess,tarfile,hashlib,collections
P=R/'docs/spec-driven/operational-preparation/source-review-supplement/followups/stablenet-comparison-v1'
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
for p in O.glob('*.json'):copy(p,P/p.name)
for p in O.glob('*.yaml'):copy(p,P/p.name)
for p in O.glob('*build-info.txt'):copy(p,P/p.name)
(P/'validation').mkdir(exist_ok=True)
for path in(O/'validation').glob('targeted*'):copy(path,P/'validation'/path.name)
native=O/'validation/native-isolated';target=P/'validation/native';target.mkdir(exist_ok=True)
copy(native/'receipts.json',target/'receipts.json')
for row in json.load(open(native/'receipts.json')):
 for stream in ['stdout','stderr']:(target/(row['label']+'.'+stream+'.gz')).write_bytes(gzip.compress((native/(row['label']+'.'+stream)).read_bytes(),mtime=0))
for label in ['search-go-stablenet','search-go-wemix','swapped-go-stablenet','swapped-go-wemix']:
 shutil.copytree(O/label,P/label,dirs_exist_ok=True)
shutil.copytree(O/'comparison',P/'comparison',dirs_exist_ok=True)
shutil.copytree(O/'diagnostics',P/'diagnostics',dirs_exist_ok=True)
shutil.copytree(O/'provenance-preflight-diagnostics',P/'provenance-preflight-diagnostics',dirs_exist_ok=True)
# Store executable collector bytes as compressed inert evidence; no new live
# Markdown or Go sources are added to the evidence catalog.
H=P/'helpers';H.mkdir(exist_ok=True)
for p in [*pathlib.Path('/private/tmp').glob('ks-snp04-*.py'),pathlib.Path('/private/tmp/ks_snp04_common.py'),O/'comparison-runner.py.txt',O/'native-validation-runner.py.txt']:
 (H/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in ['build.stdout.jsonl','build.stderr.txt']:(P/(p+'.gz')).write_bytes(gzip.compress((O/p).read_bytes(),mtime=0))
fixtures=json.load(open(O/'fixtures.json'));witness={};source_equal={};audit={};conditions=[]
for f in fixtures:
 label=f['project'];v=pathlib.Path(f['version']);copy(v/'dataset-identity.json',P/(label+'-identity.json'))
 for kind in ['sources','graph','vector']:(P/(label+'-'+kind+'-manifest.json.gz')).write_bytes(gzip.compress((v/kind/'manifest.json').read_bytes(),mtime=0))
 manifest=json.load(open(v/'sources/manifest.json'));records={(r['origin_id'],r['path']):r for r in manifest['files']};wanted={r['path']:r['sha256']for r in manifest['files']if r['origin_id']=='repo'};seen={}
 proc=subprocess.Popen(['git','-C',f['original_root'],'archive',f['source_commit']],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with tarfile.open(fileobj=proc.stdout,mode='r|')as archive:
  for entry in archive:
   if entry.name in wanted:
    assert entry.isfile();h=hashlib.sha256();stream=archive.extractfile(entry)
    for b in iter(lambda:stream.read(4<<20),b''):h.update(b)
    assert h.hexdigest()==wanted[entry.name],(label,entry.name);seen[entry.name]=h.hexdigest()
 proc.stdout.close();stderr=proc.stderr.read();code=proc.wait(timeout=20);assert code==0 and not stderr and seen==wanted
 source_equal[label]={'base_commit':f['source_commit'],'repo_files_verified_against_original_git_archive':len(seen),'equal':True,'sha256':sha(json.dumps(seen,sort_keys=True).encode())}
 def add(c):
  origin,path=c.get('origin_id','repo'),c['file']
  if path.startswith('@cks/docs/'):
   index,path=path[len('@cks/docs/'):].split('/',1);origin='docs:corpus.'+index
  row=records[(origin,path)];witness[(label,origin,path)]=row
 selected_source=next(x['source']for x in json.load(open(O/'shared-symbols.json'))if x['project']==label);shared_record=records[('repo',selected_source['file'])];witness[(label,'repo',selected_source['file'])]=shared_record
 if label=='go-stablenet':witness[(label,'docs:corpus.1','corpus.jsonl')]=records[('docs:corpus.1','corpus.jsonl')]
 config_record=records[('repo','eth/ethconfig/config.go')];config_raw=(v/'sources/blobs'/config_record['sha256']).read_bytes();start,end=(182,211)if label=='go-stablenet'else(217,247);end=min(end,len(config_raw.splitlines(keepends=True)));body=b''.join(config_raw.splitlines(keepends=True)[start-1:end]);witness[(label,'repo','eth/ethconfig/config.go')]=config_record
 conditions.append({'project':label,'coordinates':f['coordinates'],'file':'eth/ethconfig/config.go','start_line':start,'end_line':end,'file_sha256':config_record['sha256'],'content_sha256':sha(body),'body':body.decode(),'interpretation':'source selection depends on configuration; no running network selected or policy inferred'})
 message_paths=[O/('search-'+label)/'messages.json']
 for path in(O/'diagnostics').rglob('messages.json'):
  if(label=='go-wemix')==(path.parent.name=='search-go-wemix'):message_paths.append(path)
 for r in [r for path in message_paths for r in json.load(open(path))]:
  if r['request']['method']!='tools/call'or failed(r['response']):continue
  p=payload(r['response'])
  for hit in (p.get('hits')or[]):
   if not hit.get('non_citable_metadata'):add(hit['citation'])
  for c in p.get('citations',[]):add(c)
 for concept in ['staking','staking-policy','consensus','finality','mempool-admission','transaction-ordering']:
  matrix=json.load(open(O/'comparison'/('matrix-'+concept+'.json')));group=next(g for g in matrix['groups']if g['participant']['scope']['coordinates']==f['coordinates'])
  for cell in group['cells']:
   for mapping in cell['mappings']:
    for e in mapping['binding']['evidence']:add(e['reference']['citation'])
 audit[label]={'source_origins':dict(collections.Counter(r['origin_id']for r in manifest['files'])),'embedding_identity':f['embedding'],'chunks':json.load(open(v/'vector/manifest.json'))['chunk_count']}
for(label,origin,path),row in witness.items():
 f=next(f for f in fixtures if f['project']==label);p=pathlib.Path(f['version'])/'sources/blobs'/row['sha256'];assert sha(p.read_bytes())==row['sha256'];copy(p,P/'source-witness'/(row['sha256']+'.txt'))
dump(P/'witness-index.json',[{'project':label,'origin_id':origin,'path':path,'sha256':row['sha256']}for(label,origin,path),row in sorted(witness.items())]);dump(P/'source-equality.json',source_equal);dump(P/'data-audit.json',audit)
dump(P/'implementation-conditions.json',conditions)
copy(pathlib.Path('/private/tmp/ks-KM064-real-native-second-20261016/go-wemix/dataset/real-source-v1/dataset-identity.json'),P/'legacy-wemix-identity.json')
dump(P/'execution.json',{'document_date':'2026-10-18','native_source_commit':'38dd5c5449b1e57759e2532090dce101b3ad9124','baseline_source_commit':'4cebf0c890b6708f3c6cd756749ccfdc55e096eb','reader_binary_path':str(O/'read-cks'),'formal_completed':0,'formal_total':9,'reviewer_assignment':'미정','paid_LLM_calls':0,'production_writes':0,'external_publication':0,'independent_quality_acceptance':False,'new_Go_changes':['cmd/cks/mcpcli/serve.go','cmd/cks/mcpcli/pinned_pair.go','cmd/cks/mcpcli/pinned_pair_test.go'],'native_validation':'fresh complete build/test/race/fmt/vet/lint/boundaries/docs/build-bins from clean pinned native source; old pre-fix race232 is diagnostic only'})
(P/'.gitattributes').write_text('**/*.gz binary\nsource-witness/*.txt -whitespace\n*-build-info.txt whitespace=-blank-at-eol\n')
s=importlib.util.spec_from_file_location('comparisoncheck',R/'scripts/check-stablenet-comparison.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);result=m.derive(P);dump(P/'result.json',result)
dump(P/'manifest.json',{'schema_version':1,'checker':'scripts/check-stablenet-comparison.py','checker_sha256':sha((R/'scripts/check-stablenet-comparison.py').read_bytes()),'artifacts':{str(p.relative_to(P)):sha(p.read_bytes())for p in sorted(P.rglob('*'))if p.is_file()and p!=P/'manifest.json'}});print(json.dumps(result,ensure_ascii=False),flush=True)
