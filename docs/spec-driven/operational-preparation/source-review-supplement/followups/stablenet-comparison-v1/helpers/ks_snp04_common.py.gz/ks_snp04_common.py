import pathlib,json,hashlib,importlib.util,sys,copy
R=pathlib.Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');O=pathlib.Path('/private/tmp/ks-snp04-20261018-01')
sys.path.insert(0,str(R/'scripts'));s=importlib.util.spec_from_file_location('snp04_stdio',R/'scripts/prepare-consumer-stdio-readiness.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def payload(r):
 a=r.get('result',{})
 if 'structuredContent'in a:return a['structuredContent']
 try:return json.loads(a['content'][0]['text'])
 except (KeyError,ValueError):return {'text':str(a.get('content',r))}
def failed(r):return 'error'in r or r.get('result',{}).get('isError')is True
class Client(m.OwnedClient):
 def __init__(self,name,command):self.attempts=[];super().__init__(command,O/name)
 def request(self,label,method,params=None):
  params=copy.deepcopy(params)
  row={'label':label,'method':method,'params':params,'outcome':'attempted'};self.attempts.append(row);dump(self.path/'attempts.json',self.attempts)
  try:r=super().request(label,method,params);row.update(outcome='response',response=r);return r
  except Exception as e:row['outcome']=type(e).__name__;raise
  finally:dump(self.path/'attempts.json',self.attempts)
 def call(self,label,name,args=None):return self.request(label,'tools/call',{'name':name,'arguments':args or{}})
class ComparisonClient(Client):
 def __init__(self,binary,graph,root,command=None,namespace=''):
  root.rmdir();self.root=root;super().__init__(str(root.relative_to(O)),command)
 def request(self,method,params=None):return super().request(method+'-'+str(self.id+1),method,params)
def config(label,version,source):
 p=O/(label+'.yaml');p.write_text(f'''version: 1
name: snp04-{label}
backends:
  ckg:
    path: {version}/graph/graph.db
    source_root: {source}
  ckv:
    path: {version}/vector
    provider: ollama
    embed_model: bge-m3:latest
    embed_dim: 1024
    ollama_url: http://127.0.0.1:11434
listen:
  transport: stdio
logging:
  level: error
sanitize:
  rules_path: {R}/system/policies/sanitization_rules.yaml
  default_action: drop
  fail_closed_on_unknown_rule: true
semantic:
  ontology_mode: off
retrieval:
  recall_k: 10
  type_neighbors: false
''');return p
