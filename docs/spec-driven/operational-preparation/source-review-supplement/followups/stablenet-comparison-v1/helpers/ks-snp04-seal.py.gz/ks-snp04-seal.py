from ks_snp04_common import *
import shutil,gzip,re
D=R/'docs/spec-driven';P=D/'operational-preparation/source-review-supplement/followups/stablenet-comparison-v1';proposal=D/'OPERATIONAL-ACCEPTANCE-DECISION-PROPOSAL.json';refpath=str((P/'manifest.json').relative_to(R));folder=O/'validation/final';rows=json.load(open(folder/'receipts.json'));assert len(rows)==10 and all(r['exit_code']==0 for r in rows)
__import__('shutil').copyfile(O/'sequence.json',P/'sequence.json')
__import__('shutil').copyfile(O/'finalization-receipts.json',P/'finalization-receipts.json')
target=P/'validation/final';target.mkdir(exist_ok=True);shutil.copyfile(folder/'receipts.json',target/'receipts.json')
for r in rows:
 if r['label']!='original-completion-guard':shutil.copyfile(folder/r['raw_file'],target/r['raw_file'])
counts={k:int(re.search(r'Ran (\d+) tests?',(folder/(k+'.log')).read_text()).group(1))for k in ['comparison-guards','prior-error-guards','documentation-contract','package-notice']};assert counts=={'comparison-guards':22,'prior-error-guards':13,'documentation-contract':20,'package-notice':3};assert '134 live documents'in(folder/'live-documentation.log').read_text()
dump(P/'validation-summary.json',{'observation_date':'2026-10-18','checks':rows,'guard_tests':counts,'scoped_Python_tests':sum(counts.values()),'raw_Text_contract':'indexed hint/prose or density rendering, not a literal code quotation; 86 projections checked against actual selected DB, flow corpus independently regenerated; v2/compare body bytes strict','fresh_native_comparison_collection_race':{'pass':232,'skip':0,'fail':0},'full_native_validation':'fresh full build/test/race/fmt/vet/lint/boundaries/docs/build-bins from clean38dd5c54; historical pre-fix observations not counted as current-source passes','live_documents':134,'original_completion_guard_raw_log':'private_only_not_published','original_completion_guard_exit_code':0,'formal_completed':0,'formal_total':9,'reviewer_assignment':'미정','historical_packets_unchanged':True,'previously_ignored_historical_logs_to_track':21,'staged_packet_completeness':'all sealed artifacts will be checked against the staged Git blob bytes before signed final commit; private receipt avoids self hashing','historical_validation':'13 prior error evidence guard tests executed in clean652e977c; prior error/rebuild artifact guards explicitly --no-live-source; not current-source native results','self_containing_commit':'signed local commit/signature/clean tree verified after creation; no circular self hash'})
for p in [*pathlib.Path('/private/tmp').glob('ks-snp04-*.py'),pathlib.Path('/private/tmp/ks_snp04_common.py')]:
 (P/'helpers'/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
p=P/'REPORT.txt';t=p.read_text().replace('남은 전체 작업\n','이전 패킷 재현성 보완: SN-P03 manifest가 선언한 로그21개는 원문이 로컬에 존재했지만 Gitignore로 이전 커밋에 없었다. 기존 byte·SHA·manifest는 바꾸지 않고 이번 커밋에 해당 원문을 명시적으로 포함해 최신 checkout에서 재현 가능하게 보완했다. 역사652e977c 소스에서 원문을 복원해13개 보호검사를 통과했고 이번 소스의 새 검사와 구분한다. historical-archive-completeness.json을 따른다.\n\n남은 전체 작업\n').replace('최종 문서/증거보호 결과는 validation-summary.json을 따른다.','최종 비교 증거보호22·역사source의이전 오류보호13·문서계약20·고지3(총58), live문서134·기존완료guard·새 재검산·이전 오류 및 역사 rebuild 재검산·공백검사가 통과했다. validation-summary.json을 따른다.');p.write_text(t)
dump(P/'manifest.json',{'schema_version':1,'checker':'scripts/check-stablenet-comparison.py','checker_sha256':sha((R/'scripts/check-stablenet-comparison.py').read_bytes()),'artifacts':{str(p.relative_to(P)):sha(p.read_bytes())for p in sorted(P.rglob('*'))if p.is_file()and p!=P/'manifest.json'}});digest=sha((P/'manifest.json').read_bytes())
def refresh(d):
 if isinstance(d,dict):
  if d.get('manifest')==refpath:d['sha256']=digest
  if d.get('path')==str(proposal.relative_to(R)):d['sha256']=sha(proposal.read_bytes())
  for v in d.values():refresh(v)
 elif isinstance(d,list):
  for v in d:refresh(v)
d=json.load(open(proposal));refresh(d);dump(proposal,d)
for name in ['OPERATIONAL-ACCEPTANCE-PROGRESS.json','OPERATIONAL-ACCEPTANCE-PROTOCOL.json','operational-preparation/source-review-supplement/GAPS.json']:
 p=D/name;d=json.load(open(p));refresh(d);dump(p,d)
with(D/'operational-preparation/source-review-supplement/PROGRESS.txt').open('a')as f:f.write('\n검증42 최종: 비교 증거보호22·역사source의이전오류보호13·문서계약20·고지3(총58), 새 비교/격리race232·live문서134·기존완료guard·새 재검산·이전오류/역사rebuild재검산·공백검사 통과. 원본완료guard 로그는private에보존. 최종서명커밋/clean은생성후확인한다.\n')
print('stage42 evidence/docs validation sealed; current references refreshed; formal0/9 unchanged',flush=True)
