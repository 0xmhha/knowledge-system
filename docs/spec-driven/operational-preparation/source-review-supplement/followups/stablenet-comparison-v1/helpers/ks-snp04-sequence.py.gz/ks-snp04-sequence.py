import pathlib,json,subprocess,time,sys
O=pathlib.Path('/private/tmp/ks-snp04-20261018-01');started=time.monotonic();rows=[]
while not(O/'build-exit.json').exists():
 if time.monotonic()-started>5900:raise TimeoutError('held build receipt not produced')
 time.sleep(5)
assert json.load(open(O/'build-exit.json'))['exit_code']==0
while 'vcs.revision=38dd5c5449b1e57759e2532090dce101b3ad9124'not in(O/'reader-build-info.txt').read_text():time.sleep(3)
for stage in ['runtime','audit','packet','docs']:
 if stage=='audit':
  while True:
   receipt=O/'validation/native-isolated/receipts.json'
   if receipt.exists():
    native=json.load(open(receipt))
    assert all(r['exit_code']==0 for r in native),'fresh native gate failed'
    if len(native)==5:break
   time.sleep(5)
 script=pathlib.Path('/private/tmp')/('ks-snp04-'+stage+'.py');row={'stage':stage,'command':['python3',str(script)],'state':'started','started_monotonic':time.monotonic()};rows.append(row);(O/'sequence.json').write_text(json.dumps(rows,indent=2)+'\n')
 with(pathlib.Path('/private/tmp')/('ks-snp04-'+stage+'.log')).open('wb')as log:
  p=subprocess.Popen(row['command'],stdout=log,stderr=subprocess.STDOUT);row['pid']=p.pid;code=p.wait()
 row.update(state='finished',exit_code=code,reaped=True,elapsed_seconds=time.monotonic()-row['started_monotonic']);(O/'sequence.json').write_text(json.dumps(rows,indent=2)+'\n');print(stage,'exit',code,flush=True)
 if code:raise SystemExit(code)
