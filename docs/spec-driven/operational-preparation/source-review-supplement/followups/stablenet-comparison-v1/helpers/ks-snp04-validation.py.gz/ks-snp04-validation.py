from ks_snp04_common import *
import subprocess,time,os
D=O/'validation/final';D.mkdir(exist_ok=True,parents=True);rows=[]
commands=[('comparison-guards',['python3','scripts/test_stablenet_comparison.py']),('prior-error-guards',['python3',str(O/'historical-source/scripts/test_stablenet_errors.py')]),('documentation-contract',['python3','scripts/test_documentation_contract.py']),('package-notice',['python3','scripts/test_package_notice_recipe.py']),('live-documentation',['python3','scripts/check-docs.py']),('original-completion-guard',['python3','scripts/check-refactoring-progress.py']),('comparison-check',['python3','scripts/check-stablenet-comparison.py']),('prior-error-check',['python3','scripts/check-stablenet-errors.py','--no-live-source']),('rebuild-historical-check',['python3','scripts/check-stablenet-rebuild.py','--no-live-source']),('whitespace',['git','diff','--check'])]
for label,args in commands:
 start=time.monotonic();p=D/(label+'.log')
 with p.open('wb')as log:result=__import__('subprocess').run(args,cwd=R,stdout=log,stderr=__import__('subprocess').STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=300)
 row={'label':label,'argv':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'raw_sha256':sha(p.read_bytes()),'raw_file':p.name};rows.append(row);dump(D/'receipts.json',rows);print(label,'exit',result.returncode,flush=True)
 if result.returncode:raise SystemExit(1)
