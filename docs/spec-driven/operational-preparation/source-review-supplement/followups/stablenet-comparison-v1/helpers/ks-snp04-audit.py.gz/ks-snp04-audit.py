from ks_snp04_common import *
import subprocess,os,urllib.request,urllib.parse,fcntl,hashlib
def inventory(p):
 result={}
 for x in sorted(p.rglob('*')):
  if x.is_file():
   h=hashlib.sha256()
   with x.open('rb')as stream:
    for b in iter(lambda:stream.read(4<<20),b''):h.update(b)
   result[str(x.relative_to(p))]={'sha256':h.hexdigest(),'bytes':x.stat().st_size,'mode':x.stat().st_mode&0o777}
 return result
before=json.load(open(O/'protected-before.json'));after={'versions':{k:inventory(pathlib.Path(k))for k in before['versions']},'current_target':os.readlink('/Users/kevin/work/github/0xmhha/auto-coding/knowledge-data/go-stablenet-comparison-20261013/current'),'old_wemix_current':os.readlink('/private/tmp/ks-KM064-real-native-second-20261016/go-wemix/dataset/current'),'sn_current_exists':pathlib.Path('/private/tmp/ks-stablenet-rebuild-20261017-01/dataset/current').exists()};dump(O/'protected-after.json',after);assert before==after
fixtures=json.load(open(O/'fixtures.json'));owned={f['project']:inventory(pathlib.Path(f['version']))for f in fixtures};dump(O/'owned-after.json',owned);assert owned==json.load(open(O/'owned-before.json'));source_identities=[]
for f in fixtures:
 version=pathlib.Path(f['version']);lock=version.parent/'.readers'/(version.name+'.lock')
 with lock.open('rb')as stream:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(stream,fcntl.LOCK_UN)
 assert subprocess.check_output(['git','-C',f['original_root'],'rev-parse','HEAD'],text=True).strip()==f['source_commit']and not subprocess.check_output(['git','-C',f['original_root'],'status','--porcelain'])
 assert subprocess.check_output(['git','-C',f['owned_clone'],'status','--porcelain=v1'],text=True).strip()==f['prepared_git_status']
 remote=subprocess.check_output(['git','-C',f['original_root'],'remote','get-url','origin'],text=True).strip()
 if '://'in remote:
  parsed=urllib.parse.urlsplit(remote);safe_remote=parsed.scheme+'://'+(parsed.hostname or '')+parsed.path
 else:safe_remote=remote.split('@',1)[-1]
 source_identities.append({'project':f['project'],'source_root':f['original_root'],'commit':f['source_commit'],'original_status':'','module':(pathlib.Path(f['original_root'])/'go.mod').read_text().splitlines()[0],'origin_without_credentials':safe_remote,'owned_prepared_status':f['prepared_git_status'],'source_mode':f['coordinates']['source_mode']})
dump(O/'source-identities.json',source_identities)
s=importlib.util.spec_from_file_location('scopeaudit',R/'scripts/run-consumer-final.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a);plan=json.load(open(a.PLAN));scope={'global':a.global_state(plan),'operations':a.operations(plan),'source_repos':a.sources()['repos']};dump(O/'scope-after.json',scope);prior=json.load(open(O/'scope-before.json'))
probes=[]
runtime_paths=[O/name/'lifecycle.json'for name in ['search-go-stablenet','search-go-wemix','swapped-go-stablenet','swapped-go-wemix','comparison/bootstrap-session','comparison/comparison-session','comparison/bad-mapping-session']]+list((O/'diagnostics').rglob('lifecycle.json'))
for path in runtime_paths:
 life=json.load(open(path));p=subprocess.run(['ps','-p',str(life['pid']),'-o','pid=,ppid=,lstart=,command='],capture_output=True,text=True);gone=p.returncode==1 or str(O/'read-cks')not in p.stdout;assert gone;probes.append({'case':str(path.parent.relative_to(O)),'pid':life['pid'],'identity_gone':gone,'ps_exit_code':p.returncode,'current_identity_sha256':sha(p.stdout.encode())})
build=json.load(open(O/'build-start.json'));p=subprocess.run(['ps','-p',str(build['pid']),'-o','command='],capture_output=True,text=True);assert p.returncode==1 or str(O/'bin/cks')not in p.stdout;probes.append({'case':'owned-build','pid':build['pid'],'identity_gone':True,'ps_exit_code':p.returncode})
dump(O/'process-audit.json',{'probes':probes,'unowned_signals':0})
model=next(x for x in json.load(urllib.request.urlopen('http://127.0.0.1:11434/api/tags'))['models']if x['name']=='bge-m3:latest');dump(O/'model-after.json',{'model':model,'runtime':json.load(urllib.request.urlopen('http://127.0.0.1:11434/api/version'))});assert model['digest']==json.load(open(O/'model-before.json'))['model']['digest']
request={'model':'bge-m3:latest','input':['SN-P04 actual local embedding dimensional identity probe'],'truncate':False};raw=json.dumps(request).encode();req=urllib.request.Request('http://127.0.0.1:11434/api/embed',data=raw,headers={'Content-Type':'application/json'});response=urllib.request.urlopen(req,timeout=60).read();obj=json.loads(response);dump(O/'model-probe.json',{'request':request,'request_sha256':sha(raw),'response_sha256':sha(response),'model':obj['model'],'vector_dimensions':[len(v)for v in obj['embeddings']],'actual_local_inference':True})
preservation={'original_and_previous_datasets_equal':before==after,'owned_dataset_bytes_restored':True,'owned_source_scope_restored':True,'owned_reader_leases_released':True,'global_configuration_equal':prior['global']==scope['global'],'global_entries':len(scope['global']),'operational_metadata_equal':prior['operations']['metadata']==scope['operations']['metadata'],'operational_metadata_entries':len(scope['operations']['metadata']),'prior_source_checkouts_equal':prior['source_repos']==scope['source_repos'],'unowned_engines_preserved':all(x in scope['operations']['engines']for x in prior['operations']['engines']),'unowned_engines':len(prior['operations']['engines']),'no_owned_current':all(not(pathlib.Path(f['version']).parent/'current').exists()for f in fixtures),'shared_model_signals':0,'production_writes':0,'external_publication':0,'paid_LLM_calls':0};assert not subprocess.check_output(['git','-C',str(O/'native-source'),'status','--porcelain']);preservation['native_source_checkout_clean']=True;dump(O/'preservation.json',preservation);assert all(preservation[k]for k in ['global_configuration_equal','operational_metadata_equal','prior_source_checkouts_equal','unowned_engines_preserved','no_owned_current']);print('original/source/model/scope/owned data/leases/process cleanup PASS',flush=True)
