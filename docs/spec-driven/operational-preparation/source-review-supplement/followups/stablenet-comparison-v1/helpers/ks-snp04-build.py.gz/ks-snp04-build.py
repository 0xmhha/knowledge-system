import pathlib,subprocess,json,hashlib,shutil,os,time,sys,importlib.util,urllib.request
R=pathlib.Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system')
O=pathlib.Path('/private/tmp/ks-snp04-20261018-01')
S=pathlib.Path('/Users/kevin/work/github/0xmhha/auto-coding/chain/go-wemix')
P=R/'docs/spec-driven/operational-preparation/source-review-supplement/followups/stablenet-comparison-v1'
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(4<<20),b''):h.update(b)
 return h.hexdigest()
def inventory(p):return {str(f.relative_to(p)):{'sha256':sha(f),'bytes':f.stat().st_size,'mode':f.stat().st_mode&0o777}for f in sorted(p.rglob('*'))if f.is_file()}
def git(p,*args):return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-C',str(p),*args],text=True).strip()
assert not O.exists();O.mkdir();P.mkdir(parents=True,exist_ok=True)
spec={'document_date':'2026-10-18','scope':'SN-P04','status':'in_progress','entry_commit':git(R,'rev-parse','HEAD'),'purpose':'Actual pinned go-wemix versus go-stablenet source, model, concept extraction, retrieval, provenance and foreign-project boundaries; not independent quality acceptance.','acceptance':['identify real sources and retained dataset coordinates including legacy mock64 versus new BGE-M3 1024 distinction','held go-wemix BGE-M3 build, same digest/query transforms as retained go-stablenet; explicitly retain corpus/config asymmetry','actual comparison MCP six concepts with proposed mappings only; unknown/not_collected never means absent','same exposed inputs through keyword/semantic/v2 and source-body/hash verification by selected project','foreign project/pin/mapping and swapped dataset archive refuse or remain explicitly unavailable without fallback; restore owned bytes','all attempts and normal EOF/reap; original source/data/config/current and previous evidence preserved'],'source_commits':{'go-stablenet':'0bf2f4d1bfeb6605006d556957ef8c045d8f8ed8','go-wemix':'1350376a680489298b3203a44d9ebddb7747f9cc'},'go_wemix_capture':'working-tree of pinned commit with cmd/gwemix directory symlink alias excluded in owned clone only; regular cmd/geth retained','formal_completed':0,'formal_total':9,'reviewer_assignment':'미정','paid_LLM_calls':0,'production_activation':False,'publication':False}
dump(P/'spec.json',spec)
sys.path.insert(0,str(R/'scripts'));s=importlib.util.spec_from_file_location('scope',R/'scripts/run-consumer-final.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);plan=json.load(open(m.PLAN));dump(O/'scope-before.json',{'global':m.global_state(plan),'operations':m.operations(plan),'source_repos':m.sources()['repos']})
old=pathlib.Path('/private/tmp/ks-KM064-real-native-second-20261016/go-wemix/dataset/real-source-v1');sn=pathlib.Path('/private/tmp/ks-stablenet-rebuild-20261017-01/dataset/retained-origins-v2')
selected=pathlib.Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge-data/go-stablenet-comparison-20261013/current')
dump(O/'protected-before.json',{'versions':{str(p):inventory(p)for p in [old,sn,selected.resolve()]},'current_target':os.readlink(selected),'old_wemix_current':os.readlink(old.parent/'current'),'sn_current_exists':(sn.parent/'current').exists()})
assert git(S,'rev-parse','HEAD')==spec['source_commits']['go-wemix']and not git(S,'status','--porcelain=v1')
subprocess.run(['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(S),str(O/'source')],check=True,capture_output=True)
subprocess.run(['git','-c','core.hooksPath=/dev/null','-C',str(O/'source'),'checkout','--detach',spec['source_commits']['go-wemix']],check=True,capture_output=True)
alias=O/'source/cmd/gwemix';assert alias.is_symlink()and os.readlink(alias)=='geth';alias.unlink();assert git(O/'source','status','--porcelain=v1')=='D cmd/gwemix'
dump(O/'source-scope.json',{'base_commit':git(S,'rev-parse','HEAD'),'original_status':git(S,'status','--porcelain=v1'),'owned_status':git(O/'source','status','--porcelain=v1'),'excluded_non_regular':[{'path':'cmd/gwemix','target':'geth','reason':'directory alias only; cmd/geth regular source retained'}],'module':(S/'go.mod').read_text().splitlines()[0]})
(O/'bin').mkdir();pins={}
for name in ['cks','ckg','ckv']:
 origin=pathlib.Path('/private/tmp/ks-stablenet-rebuild-20261017-01/bin')/name;p=O/'bin'/name;shutil.copyfile(origin,p);p.chmod(0o755);info=subprocess.check_output(['go','version','-m',str(p)],text=True);(O/(name+'-build-info.txt')).write_text(info);assert 'vcs.modified=false'in info;pins[name]={'sha256':sha(p),'source':next(l.split('vcs.revision=')[1]for l in info.splitlines()if'vcs.revision='in l)}
reader=O/'read-cks';shutil.copyfile('/private/tmp/ks-stablenet-errors-20261018-01/bin/cks',reader);reader.chmod(0o755);info=subprocess.check_output(['go','version','-m',str(reader)],text=True);(O/'reader-build-info.txt').write_text(info);assert 'vcs.revision=4cebf0c890b6708f3c6cd756749ccfdc55e096eb'in info and 'vcs.modified=false'in info;pins['reader']={'sha256':sha(reader),'source':'4cebf0c890b6708f3c6cd756749ccfdc55e096eb'};dump(O/'binary-pins.json',pins)
model=next(x for x in json.load(urllib.request.urlopen('http://127.0.0.1:11434/api/tags'))['models']if x['name']=='bge-m3:latest');assert model['digest']=='7907646426070047a77226ac3e684fbbe8410524f7b4a74d02837e43f2146bab';dump(O/'model-before.json',{'model':model,'runtime':json.load(urllib.request.urlopen('http://127.0.0.1:11434/api/version')),'dimension':1024})
shutil.copytree(sn,O/'stablenet/retained-origins-v2');(O/'stablenet/.readers').mkdir();(O/'stablenet/.readers/retained-origins-v2.lock').touch();(O/'stablenet/.reindex.lock').touch()
cfg={'project_id':'comparison-go-wemix','source_mode':'working-tree','src':str(O/'source'),'out':str(O/'wemix'),'graph_bin':str(O/'bin/ckg'),'vector_bin':str(O/'bin/ckv'),'embedder':'ollama','model_name':'bge-m3:latest','embed_dim':1024,'ollama_url':'http://127.0.0.1:11434','query_prefix_policy':'registry','build_timeout':'90m'};dump(O/'setup.yaml',cfg)
cmd=[str(O/'bin/cks'),'setup','--config',str(O/'setup.yaml'),'--version','bge-source-v1','--hold-for-review','--progress','json'];started=time.monotonic()
with(O/'build.stdout.jsonl').open('wb')as out,(O/'build.stderr.txt').open('wb')as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True);dump(O/'build-start.json',{'pid':p.pid,'command':cmd,'owned_process_group':p.pid});code=p.wait(timeout=5700)
dump(O/'build-exit.json',{'pid':p.pid,'exit_code':code,'reaped':True,'elapsed_seconds':time.monotonic()-started,'forced_termination':False,'current_exists':(O/'wemix/current').exists()});assert code==0
print('held go-wemix BGE-M3 build PASS',flush=True)
