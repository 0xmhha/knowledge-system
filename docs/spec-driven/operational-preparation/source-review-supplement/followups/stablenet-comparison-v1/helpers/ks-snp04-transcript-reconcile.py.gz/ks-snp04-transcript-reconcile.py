from ks_snp04_common import *
import copy,gzip,shutil
repairs=[];destination=O/'provenance-preflight-diagnostics/transcript-view';destination.mkdir(parents=True,exist_ok=True)
for path in(O/'comparison').glob('*/messages.json'):
 folder=path.parent;messages=json.load(open(path));attempts=json.load(open(folder/'attempts.json'));incoming={r['id']:r for r in(json.loads(s)for s in(folder/'stdin.jsonl').read_text().splitlines())if'id'in r}
 for row,attempt in zip(messages,attempts):
  raw=incoming[row['request']['id']]
  if row['request']!=raw:
   if not(destination/(folder.name+'-messages.before.json')).exists():
    shutil.copyfile(path,destination/(folder.name+'-messages.before.json'));shutil.copyfile(folder/'attempts.json',destination/(folder.name+'-attempts.before.json'))
   repairs.append({'session':folder.name,'request_id':raw['id'],'label':row['label'],'derived_request_before':copy.deepcopy(row['request']),'unchanged_raw_request':raw,'raw_stdin_sha256':sha((folder/'stdin.jsonl').read_bytes()),'raw_stdout_sha256':sha((folder/'stdout.jsonl').read_bytes())});row['request']=copy.deepcopy(raw);attempt.update(method=raw['method'],params=copy.deepcopy(raw.get('params')))
 dump(path,messages);dump(folder/'attempts.json',attempts)
assert len(repairs)==1,repairs
dump(destination/'repairs.json',{'kind':'derived transcript views reconstructed from unchanged actual stdin after mutable budget dict alias was found','repairs':repairs,'raw_transport_modified':False,'tool_requests_reexecuted':0})
(destination/'common-before-deepcopy.py.gz').write_bytes(gzip.compress(pathlib.Path('/private/tmp/ks_snp04_common.py').read_bytes(),mtime=0));print('derived transcript requests corrected from unchanged actual stdin',len(repairs),flush=True)
