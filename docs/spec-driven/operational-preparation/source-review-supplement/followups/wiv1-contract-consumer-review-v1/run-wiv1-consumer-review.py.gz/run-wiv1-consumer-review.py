import os,sys,unittest,importlib.util,json,time,hashlib
from pathlib import Path
root=Path('/private/tmp/ks-adopted-consumer-20261017');tests=root/'plugin/scripts/tests';out=Path('/private/tmp/wi-v1-review-run');out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'plugin/scripts'))
def load(name):
 spec=importlib.util.spec_from_file_location(name,tests/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
s=load('test_fix_selection');o=load('test_oracle_gate')
suite=unittest.defaultTestLoader.loadTestsFromTestCase(s.DecisionTests)
for n in ['test_actual_candidates_run_frozen_oracles_and_regression_without_checkout_changes','test_frozen_criteria_change_invalidates_selection','test_duplicate_source_trees_do_not_count_as_alternatives','test_failed_panel_is_deferred_and_never_reuses_a_previous_selection','test_failed_readonly_check_does_not_destroy_successful_report']:
 suite.addTest(s.ExecutionTests(n))
for n in ['test_real_bug_fix_controls_and_both_source_mutants','test_base_green_is_not_a_warning_pass','test_compile_failure_is_error_not_symptom_red','test_wrong_assertion_identity_cannot_reproduce_ticket','test_timeout_is_not_red','test_normal_controls_reject_literal_fix_even_when_primary_symptom_is_green','test_overall_budget_is_bounded_and_never_passes_partial_runs']:
 suite.addTest(o.OracleGateTests(n))
started=time.monotonic()
with (out/'consumer-tests.log').open('w') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
summary=dict(tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skips=len(r.skipped),elapsed_seconds=time.monotonic()-started,kind='pinned_consumer_mechanical_fixtures_not_actual_four_role_WIV1_or_independent_oracle',actual_LLM_calls=0)
(out/'consumer-tests.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary));sys.exit(not r.wasSuccessful())
