import sys,json,gzip,hashlib,subprocess
from pathlib import Path
sys.path.insert(0,'scripts')
import full_host_owner as owner, four_role_readiness as role, owner_scope_adoption as adoption
root=Path.cwd();base=Path('docs/spec-driven/operational-preparation/source-review-supplement/followups');sha=lambda b:hashlib.sha256(b).hexdigest();out=Path('/private/tmp/wi-v1-review-run')
packets={};total=0
for name in ['owner-schedule-contract-v1','full-host-owner-v1','ticket-method-schedules-v1','four-role-current-v1','full-host-factory-v1','real-peer-sync-v1','ticket-dev-gold-v1']:
 p=base/name;manifest=p/('ADOPTION-MANIFEST.json'if name=='owner-schedule-contract-v1'else'manifest.json');m=json.loads(manifest.read_text());artifacts=m['artifacts'];assert isinstance(artifacts,dict),name
 for n,h in artifacts.items():assert sha((p/n).read_bytes())==h,(name,n)
 total+=len(artifacts);packets[name]=dict(path=str(manifest),sha256=sha(manifest.read_bytes()),artifact_hashes_verified=len(artifacts))
a=adoption.derive();assert a['full12_acceptance']is False
p=root/base/'full-host-owner-v1';summary=json.loads((p/'SUMMARY.json').read_text());owner_rows=[]
for row in summary['slots']:
 events=owner.events(gzip.decompress((p/'actual/slots'/row['slot_id']/'owner.jsonl.gz').read_bytes()));obs=owner.observation(events,row['candidate']);assert obs==row['observations'];owner_rows.extend(obs)
p=root/base/'four-role-current-v1';roles=role.inspect_attempt(p/'actual');assert len(roles)==4 and sum(r['completion_refused']for r in roles)==4
consumer=Path('/private/tmp/ks-adopted-consumer-20261017');revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=consumer,text=True).strip();assert revision==role.CONSUMER_REV and not subprocess.check_output(['git','status','--porcelain'],cwd=consumer)
before=role.read(p/'actual/evidence/consumer-before.json.gz');selected={}
for n in ['plugin/scripts/oracle_gate.py','plugin/scripts/fix_selection.py',*[f'plugin/agents/{r}.md'for r in role.ROLES]]:
 digest=sha((consumer/n).read_bytes());expected=before[n];assert digest==(expected['sha256']if isinstance(expected,dict)else expected),(n,expected);selected[n]=digest
result=dict(kind='WI_V1_evidence_replay_and_consumer_source_review_not_new_host_execution',packet_manifests=packets,preserved_artifact_hashes_verified=total,actual_owner_observations_replayed=len(owner_rows),historical_actual_roles_replayed=roles,consumer_revision=revision,consumer_source_sha256=selected,latest_CKS_revision='87fed3d970cfd32931cb278cde70b5d6fbdc7209',historical_host_CKS_revision=role.REVISION,current_CKS_four_role_rerun=False,installed_positive_WIV1_oracle=False,full12_acceptance=False,independent_approved=0,formal_completed=0,FINAL=0,freeze=None,execution_allowed=False)
(out/'input-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(artifacts_verified=total,owner_observations=len(owner_rows),historical_roles=len(roles),consumer_revision=revision)))
