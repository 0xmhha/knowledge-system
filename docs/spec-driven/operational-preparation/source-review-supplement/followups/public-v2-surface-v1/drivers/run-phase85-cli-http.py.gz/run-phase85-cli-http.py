import gzip,hashlib,importlib.util,json,os,signal,socket,subprocess,sys,threading,time,urllib.request,urllib.error,re
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');sys.path.insert(0,str(ROOT/'scripts'));import viewer_readiness as v
s=importlib.util.spec_from_file_location('owned',ROOT/'scripts/run-wi4-target-subscription.py');owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
s=importlib.util.spec_from_file_location('pilot',ROOT/'scripts/run-wi6-pair-pilot.py');pilot=importlib.util.module_from_spec(s);s.loader.exec_module(pilot)
WORK=Path('/private/tmp/ks-phase85-cli-http-20261020');BIN=Path('/private/tmp/ks-phase85-public-cli-candidate-20261020');DATA=Path('/private/tmp/ks-phase84-scale-long-functions-20261019/data');WORK.mkdir();before=pilot.inventory(DATA);v.write(WORK/'payload-before.json',before)
PROMPT='Explain SyncStatusSubscription Unsubscribe in eth downloader'
env={k:os.environ[k]for k in('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin')
http=[];lock=threading.Lock()
class Proxy(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def relay(self):
  n=int(self.headers.get('Content-Length','0'));body=self.rfile.read(n)if n else None
  req=urllib.request.Request('http://127.0.0.1:11434'+self.path,data=body,method=self.command,headers={'Content-Type':'application/json'})
  try:r=urllib.request.urlopen(req,timeout=20)
  except urllib.error.HTTPError as e:r=e
  with r:
   b=r.read(8*1024*1024+1);assert len(b)<=8*1024*1024
   row=dict(path=self.path,status=r.status,request_sha256=v.sha(body or b''),response_sha256=v.sha(b))
   if self.path=='/api/embed':
    q=json.loads(body);item=q['input'];row.update(inputs=1 if isinstance(item,str)else len(item),model=q['model'])
   with lock:http.append(row)
   self.send_response(r.status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 do_GET=relay;do_POST=relay
proxy=ThreadingHTTPServer(('127.0.0.1',0),Proxy);thread=threading.Thread(target=proxy.serve_forever,daemon=True);thread.start()
base=(Path('/private/tmp/ks-phase84-scale-long-functions-20261019/session/config.yaml')).read_text().replace('/private/tmp/ks-phase84-scale-long-functions-20261019',str(WORK)).replace(str(WORK/'data'),str(DATA));base,count=re.subn(r'(?m)^(\s*)ollama_url:.*$',r'\1ollama_url: http://127.0.0.1:'+str(proxy.server_port),base);assert count==1
(WORK/'empty-live-source').mkdir();config=WORK/'config.yaml';config.write_text(base)
v.write(WORK/'SCOPE.json',dict(kind='actual_v2_CLI_and_existing_HTTP_DEV_not_formal',binary_sha256=v.sha((BIN/'cks').read_bytes()),source_binding_sha256=v.sha((BIN/'source-binding.json').read_bytes()),prompt=PROMPT,actual_LLM_calls=0,paid_external_calls=0,independent_approved=0,formal_completed=0,whole_native_pending=True,driver_sha256=v.sha(Path(__file__).read_bytes()),data_reuse='owned phase84 data, payload must remain identical'))
wrapper=WORK/'observed-server';wrapper.write_text('#!'+sys.executable+'\nimport json,os,subprocess,sys\nfrom pathlib import Path\np=Path(os.environ["KS_SERVER_RECEIPT_DIR"]);p.mkdir()\nc=subprocess.Popen(['+repr(str(BIN/'cks'))+']+sys.argv[1:])\n(p/"live.json").write_text(json.dumps(dict(wrapper=os.getpid(),child=c.pid,parent=os.getppid(),argv=c.args)))\nr=c.wait()\n(p/"exit.json").write_text(json.dumps(dict(exit_code=r,reaped=True)))\nsys.exit(r)\n');wrapper.chmod(0o700)
server=None;fout=None;ferr=None;failed=None;receipts=[]
try:
 for name,extra,expected in [('v2',['--format=v2','--output',str(WORK/'context-v2.json')],0),('existing-output',['--format=v2','--output',str(WORK/'context-v2.json')],1),('legacy',[],0)]:
  q=WORK/name;env['KS_SERVER_RECEIPT_DIR']=str(WORK/(name+'-server'));argv=[str(BIN/'cks'),'agent','--config',str(config),'--cks-mcp',str(wrapper),'--prompt',PROMPT]+extra;r=owned.command(argv,WORK,q,env,180);receipts.append(dict(name=name,receipt=r));v.write(WORK/'CLI-receipts.json',receipts);assert r['exit_code']==expected and not r['remaining_live_group_members'];assert v.read(WORK/(name+'-server')/'exit.json')['exit_code']==0
  if name=='v2':original=(WORK/'context-v2.json').read_bytes();v.write(WORK/'v2-artifact.json',dict(sha256=v.sha(original),bytes=len(original)))
  if name=='existing-output':assert(WORK/'context-v2.json').read_bytes()==original;assert json.loads((q/'stderr').read_text())['code']=='output_exists'
 sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();url='http://127.0.0.1:'+str(port)+'/mcp'
 fout=(WORK/'HTTP-server.stdout').open('wb');ferr=(WORK/'HTTP-server.stderr').open('wb');server=subprocess.Popen([str(BIN/'cks'),'mcp','--config',str(config),'--http-addr','127.0.0.1:'+str(port)],cwd=WORK,env={k:x for k,x in env.items()if k!='KS_SERVER_RECEIPT_DIR'},stdout=fout,stderr=ferr,start_new_session=True);v.write(WORK/'HTTP-server-live.json',dict(pid=server.pid,pgid=server.pid,url=url))
 deadline=time.monotonic()+60
 while True:
  assert server.poll()is None,'HTTP server exited before ready'
  try:
   with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/healthz',timeout=3)as r:health=json.load(r)
   if health.get('serviceable'):break
  except OSError:pass
  if time.monotonic()>deadline:raise TimeoutError('HTTP ready deadline')
  time.sleep(.1)
 v.write(WORK/'HTTP-health.json',health);headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'};wire=[]
 def rpc(id,method,params):
  request=dict(jsonrpc='2.0',id=id,method=method,params=params);req=urllib.request.Request(url,data=json.dumps(request).encode(),headers=headers)
  with urllib.request.urlopen(req,timeout=60)as r:
   body=r.read(4*1024*1024+1);assert len(body)<=4*1024*1024;session=r.headers.get('Mcp-Session-Id');ct=r.headers.get('Content-Type','')
   if session:headers['Mcp-Session-Id']=session
   if 'event-stream'in ct:
    candidates=[json.loads(line[5:].strip())for line in body.decode().splitlines()if line.startswith('data:')and line[5:].strip()]
    response=next(x for x in candidates if x.get('id')==id)
   else:response=json.loads(body)
   wire.append(dict(request=request,response=response,content_type=ct,status=r.status,session_header_sha256=v.sha(session.encode())if session else None));v.write(WORK/'HTTP-wire.json',wire);return response
 init=rpc(1,'initialize',dict(protocolVersion='2024-11-05',capabilities={},clientInfo=dict(name='owned-v2-http',version='1')));headers['MCP-Protocol-Version']=init['result']['protocolVersion']
 got=rpc(2,'tools/call',dict(name='cks.context.get_for_task_v2',arguments=dict(prompt=PROMPT)))
 result=got['result'];pack=result.get('structuredContent')or json.loads(result['content'][0]['text']);v.write(WORK/'HTTP-v2.json',pack);cli=json.loads(original);assert pack['format_version']==cli['format_version']==2 and pack['coordinates']==cli['coordinates']and pack['query']==cli['query']==PROMPT
 bad=rpc(3,'tools/call',dict(name='cks.context.get_for_task_v2',arguments=dict(prompt=PROMPT,intent='not-an-intent')));assert bad['result']['isError']and bad['result']['structuredContent']['code']=='invalid_request'
 v.write(WORK/'transport-result.json',dict(same_coordinates=True,same_query=True,CLI_source_mode=cli['coordinates']['source_mode'],CLI_citations=len(cli['citations']),HTTP_citations=len(pack['citations']),same_integrity_hash=cli['metadata']['integrity_hash']==pack['metadata']['integrity_hash'],HTTP_invalid_request=True,legacy_markdown_retained=True))
except Exception as e:failed=dict(type=type(e).__name__,message=str(e))
finally:
 if server is not None:
  if server.poll()is None:server.send_signal(signal.SIGTERM)
  try:server.wait(timeout=15);forced=False
  except subprocess.TimeoutExpired:forced=True;os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=5)
  v.write(WORK/'HTTP-server-exit.json',dict(exit_code=server.returncode,reaped=True,forced=forced,remaining_group=pilot.live_group(server.pid)))
  fout.close();ferr.close()
 proxy.shutdown();proxy.server_close();thread.join(3);v.write(WORK/'HTTP-model-events.json',http);v.write(WORK/'payload-after.json',pilot.inventory(DATA));v.write(WORK/'receipt.json',dict(failure=failed,proxy_thread_alive=thread.is_alive(),payload_preserved=pilot.inventory(DATA)==before,actual_LLM_calls=0,paid_external_calls=0,independent_approved=0,formal_completed=0))
if failed:raise RuntimeError(failed)
print('actual v2 CLI/output refusal/legacy and existing HTTP routes passed',flush=True)
