import os,json,importlib.util,subprocess
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');native=Path('/private/tmp/ks-phase85-native-20261020');out=Path('/private/tmp/ks-phase85-post-native-docs-20261020');assert(native/'graph-binary.json').exists(),'whole native checks must finish first';out.mkdir()
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b=json.loads((native/'source-binding.json').read_text());doc='docs/spec-driven/PUBLIC-CONTRACT-V2.md';before=(root/doc).read_bytes();assert m.sha(before)==b['source_sha256'][doc];assert Path('/private/tmp/phase85-native-public-contract.md').read_bytes()==before
old='CKG 독립 export와 일반 `--format=v2`/HTTP 표면은 아직 이 표의 설계 계약에 머무른다.';new='선택형 CKS CLI v2, 기존 HTTP MCP의 v2 도구, CKG 독립 원시 그래프 JSON v2는 위 구현 경로를 따른다. 직접 CKV retained v2와 정적 분할 v2는 별도 미구현 경로로 구분한다.';text=before.decode();assert text.count(old)==1;(root/doc).write_text(text.replace(old,new))
for n,h in {**b['source_sha256'],**b['approved_input_sha256'],**b['generated_input_sha256']}.items():
 if n!=doc:assert m.sha((root/n).read_bytes())==h,n
prior={n:m.sha((root/'bin'/n).read_bytes())for n in ('cks','ckg','ckv')}
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
r=m.command(['make','docs-check'],root,out,env,600);assert r['exit_code']==0 and not r['remaining_live_group_members'];after={n:m.sha((root/'bin'/n).read_bytes())for n in prior};assert prior==after
m.write(out/'binary-equality.json',dict(**after,Go_inputs_preserved=True,all_three_default_binaries_unchanged=True,before=prior));m.write(out/'DELTA.json',{doc:dict(baseline_sha256=m.sha(before),current_sha256=m.sha((root/doc).read_bytes()),not_a_native_compilation_input=True)})
p=root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/public-v2-surface-v1/SPEC.json';d=json.loads(p.read_text());d['requirements']['sha256']=m.sha((root/doc).read_bytes());p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print('one prose correction; documentation and all three binary equality passed',flush=True)
