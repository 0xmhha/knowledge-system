import hashlib,importlib.util,json,os,shutil,signal,sqlite3,subprocess,time
from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');BIN=Path('/private/tmp/ks-phase85-public-final-candidate-20261020');DATA=Path('/private/tmp/ks-phase84-scale-long-functions-20261019/data');WORK=Path('/private/tmp/ks-phase85-graph-20261020');WORK.mkdir()
s=importlib.util.spec_from_file_location('owned',ROOT/'scripts/run-wi4-target-subscription.py');owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
s=importlib.util.spec_from_file_location('pilot',ROOT/'scripts/run-wi6-pair-pilot.py');pilot=importlib.util.module_from_spec(s);s.loader.exec_module(pilot)
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
before=pilot.inventory(DATA);write(WORK/'payload-before.json',before);assert shutil.disk_usage(WORK).free>2*1024**3
scope=dict(binary_sha256=sha((BIN/'ckg').read_bytes()),source_binding_sha256=sha((BIN/'source-binding.json').read_bytes()),driver_sha256=sha(Path(__file__).read_bytes()),actual_LLM_calls=0,formal_completed=0);write(WORK/'SCOPE.json',scope)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env['PATH']='/usr/bin:/bin:/usr/sbin:/sbin'
out=WORK/'graph-v2.json';args=[str(BIN/'ckg'),'export-json','--graph',str(DATA/'graph'),'--out',str(out),'--format=v2','--minimal']
r=owned.command(args,WORK,WORK/'success',env,600);assert r['exit_code']==0 and not r['remaining_live_group_members']
# Incremental independent JSON reader: retain at most a row plus a small input
# buffer rather than loading this whole export into the verifier's memory.
class Reader:
 def __init__(self,p):self.f=p.open();self.buf='';self.pos=0;self.decoder=json.JSONDecoder();self.eof=False
 def more(self):
  self.buf=self.buf[self.pos:]+self.f.read(65536);self.pos=0
  if not self.buf:self.eof=True
 def whitespace(self):
  while True:
   while self.pos<len(self.buf)and self.buf[self.pos].isspace():self.pos+=1
   if self.pos<len(self.buf)or self.eof:return
   self.more()
 def token(self,c):
  self.whitespace();assert self.buf[self.pos:self.pos+1]==c,(c,self.buf[self.pos:self.pos+20]);self.pos+=1
 def value(self):
  while True:
   self.whitespace()
   try:v,end=self.decoder.raw_decode(self.buf,self.pos);self.pos=end;return v
   except json.JSONDecodeError:
    old=len(self.buf)-self.pos;self.more()
    if len(self.buf)==old:raise
 def array(self):
  self.token('[');self.whitespace()
  if self.buf[self.pos:self.pos+1]==']':self.pos+=1;return
  while True:
   yield self.value();self.whitespace()
   if self.buf[self.pos:self.pos+1]==']':self.pos+=1;return
   self.token(',')
reader=Reader(out);reader.token('{')
def field(name):
 assert reader.value()==name;reader.token(':')
field('format');assert reader.value()=='ckg-graph-v2';reader.token(',');field('format_version');assert reader.value()==2;reader.token(',');field('coordinates');coords=reader.value();reader.token(',');field('source');source=reader.value();reader.token(',');field('header');header=reader.value();reader.token(',');field('nodes')
db=sqlite3.connect((DATA/'graph/graph.db').as_uri()+'?mode=ro&immutable=1',uri=True);man=dict(db.execute('select key,value from manifest'))
assert coords==dict(project_id=man['project_id'],dataset_id=man['dataset_id'],snapshot_id=man['snapshot_id'],source_mode=man['source_mode'],base_commit=man['src_commit']);assert source=={k:man[k]for k in ('file_manifest_digest','capture_policy_digest')}
names=['id','type','name','qualified_name','file_path','start_line','end_line','language','confidence'];cursor=db.execute('select '+','.join(names)+' from nodes order by id');node_count=0
for row in reader.array():
 expected=cursor.fetchone();assert expected is not None and row==dict(zip(names,expected));node_count+=1
assert cursor.fetchone()is None
reader.token(',');field('edges');names=['src','dst','type','file_path','line','count','confidence','dispatch_kind'];cursor=db.execute("select src,dst,type,coalesce(file_path,''),coalesce(line,0),count,confidence,coalesce(dispatch_kind,'') from edges order by id");edge_count=0
for row in reader.array():
 expected=cursor.fetchone();assert expected is not None;d=dict(zip(names,expected));d={k:v for k,v in d.items()if k not in ('file_path','line','dispatch_kind')or bool(v)};assert row==d;edge_count+=1
assert cursor.fetchone()is None
reader.token(',');field('counts');counts=reader.value();reader.token('}');reader.whitespace();assert reader.eof and counts==dict(nodes=node_count,edges=edge_count)==dict(nodes=244989,edges=1964193)
reader.f.close();db.close();write(WORK/'ROW-VERIFICATION.json',dict(counts=counts,coordinates=coords,source=source,all_minimal_rows_match_SQLite=True,output_bytes=out.stat().st_size,output_sha256=sha(out.read_bytes())))
# A real interrupted second export must close and remove its owned partial file.
cancelout=WORK/'canceled.json';cancelargs=args.copy();cancelargs[cancelargs.index(str(out))]=str(cancelout);stdout=(WORK/'cancel.stdout').open('wb');stderr=(WORK/'cancel.stderr').open('wb');p=subprocess.Popen(cancelargs,cwd=WORK,env=env,stdout=stdout,stderr=stderr,start_new_session=True);write(WORK/'cancel-live.json',dict(pid=p.pid,pgid=p.pid,argv=cancelargs));sent=False;forced=False
try:
 deadline=time.monotonic()+30
 while p.poll()is None:
  partials=list(WORK.glob('.ckg-graph-v2-*'))
  if any(x.stat().st_size>65536 for x in partials):p.send_signal(signal.SIGTERM);sent=True;break
  if time.monotonic()>deadline:raise TimeoutError('owned partial not observed')
  time.sleep(.01)
 p.wait(timeout=15)
finally:
 if p.poll()is None:forced=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 stdout.close();stderr.close();write(WORK/'cancel-exit.json',dict(exit_code=p.returncode,reaped=True,term_sent=sent,forced=forced,remaining_group=pilot.live_group(p.pid)))
assert sent and not forced and p.returncode==1 and not pilot.live_group(p.pid);assert json.loads((WORK/'cancel.stderr').read_text())['code']=='request_canceled';assert not cancelout.exists();temporary=list(WORK.glob('.ckg-graph-v2-*'));assert not temporary
after=pilot.inventory(DATA);write(WORK/'payload-after.json',after);assert before==after
write(WORK/'RESULT.json',dict(success=True,counts=counts,coordinates=coords,all_minimal_rows_match_SQLite=True,canceled_output_absent=True,temporary_files_remaining=len(temporary),payload_preserved=True,actual_LLM_calls=0,formal_completed=0,independent_approved=0,paid_external_calls=0,binary_sha256=scope['binary_sha256'],source_binding_sha256=scope['source_binding_sha256'],output_bytes=out.stat().st_size,output_sha256=sha(out.read_bytes()),normal_export_exit_code=r['exit_code'],canceled_export_exit_code=p.returncode,remaining_process_groups=0))
print('all graph rows matched; normal export and actual SIGTERM recovery passed',flush=True)
