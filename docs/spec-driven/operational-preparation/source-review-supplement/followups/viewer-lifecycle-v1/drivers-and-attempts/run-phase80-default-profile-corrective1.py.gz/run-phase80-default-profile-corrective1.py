import os,json,importlib.util
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase80-default-profile-corrective1-20261019');out.mkdir();payload=root/'internal/system/viewer/web_assets/app';hold=out/'held-payload';s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
before={str(p.relative_to(payload)):m.sha(p.read_bytes())for p in payload.rglob('*')if p.is_file()};m.write(out/'payload-before.json',before)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH='/Users/kevin/.gvm/gos/go1.26.8/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
payload.rename(hold)
try:
 for label,argv in [('test',['go','test','-race','-json','-count=1','-timeout=3m','./cmd/cks/viewercli','./internal/system/viewer']),('build',['go','build','-o',str(out/'cks'),'./cmd/cks']),('export-command',[str(out/'cks'),'viewer','export','--out',str(out/'export')])]:
  r=m.command(argv,root,out/label,env,240);assert r['exit_code']==0 and not r['remaining_live_group_members']
 files={str(p.relative_to(out/'export')):m.sha(p.read_bytes())for p in(out/'export').rglob('*')if p.is_file()};assert list(files)==['index.html']and b'not built'in(out/'export/index.html').read_bytes();m.write(out/'export-result.json',dict(files=files,unbuilt_stub=True,UI_success_claimed=False,binary_sha256=m.sha((out/'cks').read_bytes())))
finally:
 assert not payload.exists();hold.rename(payload);after={str(p.relative_to(payload)):m.sha(p.read_bytes())for p in payload.rglob('*')if p.is_file()};m.write(out/'payload-after.json',after);assert before==after
m.write(out/'receipt.json',dict(optional_payload_restored=True,generated_files_preserved=46,default_stub_export_only=True,real_UI_success_claimed=False))
print('default no-frontend profile tests/build/export passed;46 payload restored',flush=True)
