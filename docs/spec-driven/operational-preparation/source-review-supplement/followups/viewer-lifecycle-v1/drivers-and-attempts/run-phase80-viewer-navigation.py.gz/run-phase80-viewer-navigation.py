"""Owned real viewer + real graph API; leaves a bounded browser window."""
import importlib.util,json,os,signal,shutil,socket,subprocess,time,urllib.request
from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system')
s=importlib.util.spec_from_file_location('pilot',ROOT/'scripts/run-wi6-pair-pilot.py');pilot=importlib.util.module_from_spec(s);s.loader.exec_module(pilot)
WORK=Path('/private/tmp/ks-phase80-viewer-navigation-20261019');BIN=Path('/private/tmp/ks-phase80-viewer-candidate-built-20261019')
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):return __import__('hashlib').sha256(p.read_bytes()).hexdigest()
def live(pgid):
 return [int(r[0])for line in subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines()if len(r:=line.split())==3 and int(r[1])==pgid]
WORK.mkdir();before=pilot.inventory(pilot.DATA);write(WORK/'original-before.json',before)
(WORK/'data').symlink_to('/private/tmp/ks-phase80-viewer-actual-built-20261019/data',target_is_directory=True);write(WORK/'owned-before.json',pilot.inventory(WORK/'data'));assert pilot.inventory(WORK/'data')==before
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
metadata=json.loads((WORK/'data/graph/manifest.json').read_text());scope=dict(kind='owned_actual_embedded_viewer_and_real_graph_API_DEV',base_revision='49662a5bc27dbae01e956c8c03a72a5b803a174e',source_binding_sha256=sha(BIN/'source-binding.json'),binaries={name:sha(BIN/name)for name in ['cks','ckg']},source_commit=metadata['src_commit'],project_id=metadata['project_id'],dataset_id=metadata['dataset_id'],source_snapshot_id=metadata['snapshot_id'],address='http://127.0.0.1:'+str(port),automatic_trial_retries=0,child_exit_requested='SIGTERM_via_parent_CLI_context',external_API_not_used=True,actual_LLM_calls=0,formal_completed=0,independent_approved=0,driver_sha256=sha(Path(__file__)),max_browser_window_seconds=900)
scope['owned_data_reuse']='previous owned copy, never original; all before/after2248 maps rechecked';write(WORK/'SCOPE.json',scope)
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=str(BIN)+':/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
argv=[str(BIN/'cks'),'viewer','--graph',str(WORK/'data/graph'),'--port',str(port)]
start=time.monotonic();forced=False;kill=False;failure=None;p=None
with(WORK/'stdout').open('wb')as stdout,(WORK/'stderr').open('wb')as stderr:
 try:
  p=subprocess.Popen(argv,cwd=WORK,env=env,stdout=stdout,stderr=stderr,start_new_session=True);write(WORK/'live.json',dict(pid=p.pid,pgid=p.pid,argv=argv))
  deadline=time.monotonic()+40
  while True:
   if p.poll()is not None:raise RuntimeError('viewer exited before browser readiness: '+str(p.returncode))
   try:
    with urllib.request.urlopen(scope['address']+'/api/manifest',timeout=.5)as response:body=response.read()
    if response.status==200:break
   except OSError:pass
   if time.monotonic()>deadline:raise TimeoutError('actual dashboard not ready')
   time.sleep(.1)
  (WORK/'actual-manifest.json').write_bytes(body)
  rows=[]
  for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,stat=,comm='],text=True).splitlines():
   r=line.split(None,4)
   if len(r)==5 and(int(r[1])==p.pid or int(r[0])==p.pid):rows.append(dict(pid=int(r[0]),ppid=int(r[1]),pgid=int(r[2]),stat=r[3],executable=r[4]))
  assert len(rows)==2 and any(r['ppid']==p.pid and Path(r['executable']).name=='ckg'for r in rows)
  write(WORK/'ready-processes.json',rows);write(WORK/'READY.json',dict(url=scope['address'],pid=p.pid,actual_graph_manifest_recorded=True))
  print('owned viewer and graph API ready '+scope['address'],flush=True)
  while not(WORK/'STOP').exists()and time.monotonic()-start<scope['max_browser_window_seconds']:
   if p.poll()is not None:raise RuntimeError('actual viewer unexpectedly exited '+str(p.returncode))
   time.sleep(.2)
 except Exception as error:failure=dict(type=type(error).__name__,message=str(error))
 finally:
  if p is not None:
   if p.poll()is None:p.send_signal(signal.SIGTERM)
   try:p.wait(timeout=20)
   except subprocess.TimeoutExpired:
    forced=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:kill=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   write(WORK/'process-receipt.json',dict(pid=p.pid,exit_code=p.returncode,reaped=p.poll()is not None,normal_parent_SIGTERM_requested=True,cleanup_fallback_group_TERM=forced,cleanup_fallback_group_KILL=kill,remaining_group_members=live(p.pid),elapsed_seconds=time.monotonic()-start,failure=failure))
write(WORK/'original-after.json',pilot.inventory(pilot.DATA));write(WORK/'owned-after.json',pilot.inventory(WORK/'data'))
assert before==pilot.inventory(pilot.DATA)==pilot.inventory(WORK/'data')
rows=[parts for line in subprocess.check_output(['ps','-axo','pid=,stat='],text=True).splitlines()if len(parts:=line.split())==2];known=json.loads((WORK/'ready-processes.json').read_text())if(WORK/'ready-processes.json').exists()else[];write(WORK/'cleanup-recorded-PIDs.json',dict(recorded=[r['pid']for r in known],remaining=[r for r in rows if int(r[0])in[r['pid']for r in known]]))
for name,h in scope['binaries'].items():assert sha(BIN/name)==h
write(WORK/'receipt.json',dict(original_owned_payload_preserved=True,source_binding_sha256=scope['source_binding_sha256'],binary_hashes_preserved=True,actual_LLM_calls=0,formal_completed=0,independent_approved=0,failed=failure is not None))
if failure:raise RuntimeError(failure)
print('actual viewer ended and original/owned payload preserved',flush=True)
