import importlib.util,json,os,subprocess,hashlib
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');candidate=Path('/private/tmp/ks-phase80-viewer-candidate-built-corrective1-20261019');out=Path('/private/tmp/ks-phase80-native-corrective1-20261019');binding=json.loads((candidate/'source-binding.json').read_text())
s=importlib.util.spec_from_file_location('native',root/'scripts/verify-wi3-reasons-native.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
original=m.check_sources
def check(root,b):
 original(root,b)
 if out.exists() and not(out/'TOOLS-BEFORE-LINT.json').exists():
  m.write(out/'TOOLS-BEFORE-LINT.json',before_tools)
  previous={json.loads(line)['Package']for line in Path('/private/tmp/ks-phase80-native-20261019/test.stdout').read_text().splitlines()if line.strip()and 'Package'in json.loads(line)}
  current=set(subprocess.check_output(['go','list','./...'],cwd=root,text=True).splitlines());removed=previous-current;assert removed=={'github.com/0xmhha/knowledge-system/tools/viewer/node_modules/flatted/golang/pkg/flatted'}and not(current-previous);m.write(out/'package-boundary-proof.json',dict(previous=sorted(previous),current=sorted(current),removed_external_only=sorted(removed),maintained_packages_preserved=True,lint_rule_or_config_changed=False))
 actual={str(p.relative_to(root)):m.sha(p.read_bytes())for p in (root/'internal/system/viewer/web_assets/app').rglob('*')if p.is_file()}
 assert actual==b['generated_input_sha256'],'generated inputs changed'
m.check_sources=check
env={k:os.environ[k]for k in ('HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','CGO_ENABLED','CC','CXX','PKG_CONFIG_PATH')if k in os.environ};env.update(PATH='/Users/kevin/.gvm/gos/go1.26.8/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1');os.environ.clear();os.environ.update(env)
before_tools=dict(capture_before_lint=True,go=subprocess.check_output(['go','version'],text=True).strip(),lint=subprocess.check_output(['/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint','version'],text=True).strip(),lint_configuration_sha256=m.sha((root/'.golangci.yml').read_bytes()),executable_sha256={n:m.sha(Path(p).read_bytes())for n,p in {'go':'/Users/kevin/.gvm/gos/go1.26.8/bin/go','lint':'/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint'}.items()})
m.run(root,out,binding,Path('/private/tmp/ks-go-cache'))
p=out/'binary.json';d=json.loads(p.read_text());d['source_mode']=binding['source_mode'];m.write(p,d);assert d['sha256']==m.sha((candidate/'cks').read_bytes())
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
for label,argv in [('build-graph-runtime',['go','build','-o',str(out/'read-ckg'),'./cmd/graph']),('graph-build-info',['go','version','-m',str(out/'read-ckg')])]:
 check(root,binding);r=owned.command(argv,root,out/label,env,900);r.update(label=label,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()));m.write(out/(label+'-receipt.json'),r);assert r['exit_code']==0 and not r['remaining_live_group_members'];check(root,binding)
assert m.sha((out/'read-ckg').read_bytes())==m.sha((candidate/'ckg').read_bytes())
groups=[]
for r in json.loads((out/'receipts.json').read_text()):
 members=[line for line in subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines()if len(x:=line.split())==3 and int(x[1])==r['pid']];assert not members;groups.append(dict(label=r['label'],pgid=r['pid'],remaining_live_group_members=0))
m.write(out/'process-groups.json',groups);m.write(out/'installed-tools.json',dict(go=subprocess.check_output(['go','version'],text=True).strip(),lint=subprocess.check_output(['/Users/kevin/.gvm/pkgsets/go1.26.8/global/bin/golangci-lint','version'],text=True).strip()));m.write(out/'graph-binary.json',dict(sha256=m.sha((out/'read-ckg').read_bytes()),source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
print('native CKS and CKG match observed runtime binaries',flush=True)
