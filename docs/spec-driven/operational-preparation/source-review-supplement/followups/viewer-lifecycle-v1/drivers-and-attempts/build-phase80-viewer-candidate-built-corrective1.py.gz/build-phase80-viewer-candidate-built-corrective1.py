import os,json,subprocess,importlib.util,hashlib
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase80-viewer-candidate-built-corrective1-20261019');out.mkdir()
spec=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/intent-startup-batch-v1/source-binding.json').read_text());names=set(old['source_sha256']);inventory=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.go'],cwd=root,text=True).splitlines();names.update(n for n in inventory if n.startswith(('cmd/','pkg/','internal/')))
current={n:m.sha((root/n).read_bytes())for n in sorted(names)};revision='49662a5bc27dbae01e956c8c03a72a5b803a174e';changes=[]
for n in current:
 r=subprocess.run(['git','show',revision+':'+n],cwd=root,capture_output=True)
 if r.returncode or m.sha(r.stdout)!=current[n]:changes.append(n)
extra=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','tools/viewer'],cwd=root,text=True).splitlines()+['graph/Makefile','.gitignore']
for n in extra:current[n]=m.sha((root/n).read_bytes())
changes=[]
for n in sorted(current):
 r=subprocess.run(['git','show',revision+':'+n],cwd=root,capture_output=True)
 if r.returncode or m.sha(r.stdout)!=current[n]:changes.append(n)
generated={str(p.relative_to(root)):m.sha(p.read_bytes())for p in sorted((root/'internal/system/viewer/web_assets/app').rglob('*'))if p.is_file()}
assert len(generated)>1 and 'internal/system/viewer/web_assets/app/index.html'in generated
binding=dict(base_revision=revision,source_mode='working_tree_6_Go_with_owned_optional_viewer_payload',source_sha256=current,generated_input_sha256=generated,approved_input_sha256=old['approved_input_sha256'],changed_native_files=changes)

assert sum(n.endswith('.go')for n in changes)==6
m.write(out/'source-binding.json',binding)
go='/Users/kevin/.gvm/gos/go1.26.8/bin/go';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=str(Path(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod')
r=m.command([go,'build','-o',str(out/'cks'),'./cmd/cks'],root,out/'build',env,900);assert r['exit_code']==0 and not r['remaining_live_group_members']
for n,h in{**current,**generated,**binding['approved_input_sha256']}.items():assert m.sha((root/n).read_bytes())==h
info=subprocess.check_output([go,'version','-m',str(out/'cks')],cwd=out,env=env);(out/'build-info.txt').write_bytes(info)
m.write(out/'binary.json',dict(sha256=m.sha((out/'cks').read_bytes()),source_revision=revision,source_mode=binding['source_mode'],source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
print('candidate source files',len(current),'changed',changes,flush=True)

r=m.command([go,'build','-o',str(out/'ckg'),'./cmd/graph'],root,out/'build-ckg',env,900);assert r['exit_code']==0 and not r['remaining_live_group_members']
for n,h in{**current,**generated,**binding['approved_input_sha256']}.items():assert m.sha((root/n).read_bytes())==h
m.write(out/'graph-binary.json',dict(sha256=m.sha((out/'ckg').read_bytes()),source_revision=revision,source_mode=binding['source_mode'],source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
(out/'graph-build-info.txt').write_bytes(subprocess.check_output([go,'version','-m',str(out/'ckg')],cwd=out,env=env))
