import gzip,io,tarfile,json,sys,shutil
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');sys.path.insert(0,str(root/'scripts'));import viewer_readiness as v
p=root/v.PACKET
assert not(p/'manifest.json').exists(),'refusing sealed packet overwrite'
def archive(src,dst,skip=()):
 for x in sorted(src.rglob('*')):
  rel=x.relative_to(src)
  if x.is_file()and not x.is_symlink()and not any(a in skip for a in rel.parts):
   target=dst/(str(rel)+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(x.read_bytes(),mtime=0))
native=Path('/private/tmp/ks-phase80-native-corrective1-20261019');candidate=Path('/private/tmp/ks-phase80-viewer-candidate-built-corrective1-20261019')
shutil.copyfile(native/'source-binding.json',p/'source-binding.json');archive(native,p/'native',('read-cks','read-ckg'));archive(candidate,p/'candidate',('cks','ckg'))
archive(Path('/private/tmp/ks-phase80-viewer-candidate-built-20261019'),p/'runtime-candidate',('cks','ckg'))
archive(Path('/private/tmp/ks-phase80-native-20261019'),p/'failed-native',('read-cks','read-ckg'))
for name,directory in [('initial','ks-phase80-viewer-actual-20261019'),('actual','ks-phase80-viewer-actual-built-20261019')]:
 archive(Path('/private/tmp')/directory,p/name,('data',))
archive(Path('/private/tmp/ks-phase80-viewer-browser-20261019'),p/'initial-browser')
archive(Path('/private/tmp/ks-phase80-viewer-navigation-20261019'),p/'navigation',('data','export'))
archive(Path('/private/tmp/ks-phase80-viewer-navigation-browser-20261019'),p/'navigation-browser')
browser=Path('/private/tmp/ks-phase80-viewer-browser-built-20261019');archive(browser,p/'browser');shutil.copyfile(browser/'browser-cleanup.json',p/'browser-cleanup.json')
for directory in ['ks-phase80-viewer-focused-20261019','ks-phase80-viewer-focused-corrective1-20261019','ks-phase80-viewer-focused-corrective2-20261019','ks-phase80-viewer-focused-final-20261019','ks-phase80-viewer-focused-built-20261019']:
 archive(Path('/private/tmp')/directory,p/'focused'/directory)
for pattern in ['prepare-phase80-packet.py','finalize-phase80.py','phase80-viewer-*.log','phase80-native*-driver.log','run-phase80-*.py','build-phase80-*.py']:
 for x in Path('/private/tmp').glob(pattern):
  if x.is_file():target=p/'drivers-and-attempts'/(x.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(x.read_bytes(),mtime=0))
# Archive only the exact generated inputs, never node_modules/caches or binary/data.
binding=v.read(p/'source-binding.json');buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as t:
 for name in sorted(binding['generated_input_sha256']):
  data=(root/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
(p/'generated-payload.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
v.write(p/'VISUAL-REVIEW.json',dict(inspected=True,screenshots=['browser/selected-node.png.gz','browser/selected-node-2d.png.gz'],graph_canvas_visible=True,search_and_selected_source_visible=True,keyboard_focus_visible=True,long_qualified_name_wraps_in_existing_sidebar=True,all_accessibility_criteria_approved=False,independent_approved=0))
v.write(p/'LIMITATIONS.json',dict(initial_actual_UI='tracked unbuilt placeholder despite healthy API; retained and not counted as UI success',browser_console='two expected static-mode manifest probes404 then serve API; five CSS preload warnings retained; no assertion of zero console errors',network_capture='CLI network command unsupported, exit1 retained; no actual network log claimed',screenshot_command='second image exists and visually inspected; enclosing set-e script exit1 retained, close executed separately with receipt',Atlas='navigation present, vector backend not wired or verified',build='optional Next16 static export copied into ignored app directory before Go compile; source checkout retains tracked stub',environment='Node25.2.1 npm11.6.2 Go1.26.8; no global install or source dependency upgrades',initial_failures=['npm ci invoked at root before corrected --prefix','next.config ESLint process no-undef fixed by explicit node:process import','focused corrective1 unused synchronization variable compile failure','actual runner missing PYTHONPATH import preflight; no resource started'],formal_completed=0,independent_approved=0))
v.write(p/'POST-NATIVE-AUXILIARY-DELTA.json',{'scripts/check-operational-acceptance.py':dict(baseline_sha256=v.sha(__import__('subprocess').check_output(['git','show',v.BASE+':scripts/check-operational-acceptance.py'],cwd=root)),not_a_native_compilation_input=True,current_sha256=v.sha((root/'scripts/check-operational-acceptance.py').read_bytes()),scope='Python readiness-kind dispatch only; separately tested after native; zero Go/frontend/approved-input delta')})
current=json.loads(json.dumps(binding));current['source_sha256']['scripts/check-operational-acceptance.py']=v.sha((root/'scripts/check-operational-acceptance.py').read_bytes());current['native_source_binding_sha256']=v.sha((p/'source-binding.json').read_bytes());v.write(p/'current-source-binding.json',current)
v.write(p/'SUMMARY.json',v.derive(p))
print('packet prepared; not sealed',flush=True)
