// Owned source-observation bridge for the Notify-in-flight and ungated
// transport-close generation boundary.
//
// Each (API, status channel) key carries a generation that the real owner's
// install increments. Every source channel use is recorded with the generation
// current at that moment, so a use after the real owner ack of the same
// generation is distinguished from a use by an explicit new registration.
// The "notify-in-flight" schedule holds the RPC callback just before it
// forwards the done status to the client, closes the RPC connection while it
// is held, and then lets the callback return to its select. The
// "transport-ungated" schedule closes the connection before the native timer
// with no gate, then re-registers the acknowledged channel across the natural
// done broadcast.
package downloader

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"sort"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/rpc"
)

const (
	genScheduleNotify  = "notify-in-flight"
	genScheduleUngated = "transport-ungated"
	// genTeardownSettle lets the server finish its connection teardown while the
	// callback is held, so both callback exit channels are ready on release.
	genTeardownSettle = 500 * time.Millisecond
	genBoundedWait     = 3 * time.Second
	genTimerWait       = 75 * time.Second
	genQuietWindow     = 500 * time.Millisecond
)

// genUseEvents are source operations that read from or write to a status channel.
var genUseEvents = map[string]bool{
	"install_send_begin":         true,
	"native_send_begin_progress": true,
	"native_send_begin_done":     true,
	"method_status_received":     true,
	"callback_status_received":   true,
	"probe_status_received":      true,
}

type genKey struct {
	api *DownloaderAPI
	c   chan interface{}
}

type genRecorder struct {
	mu          sync.Mutex
	file        *os.File
	path        string
	schedule    string
	start       time.Time
	seq         int
	apis        map[*DownloaderAPI]int
	created     map[*DownloaderAPI]time.Time
	channels    map[genKey]int
	rpcids      map[genKey]string
	gen         map[genKey]int
	acked       map[genKey]int
	members     map[genKey]bool
	counts      map[genKey]map[int]map[string]int
	violations  map[genKey]int
	firstSeq    map[genKey]map[string]int
	global      map[string]int
	selected    genKey
	gateEntered chan struct{}
	gateRelease chan struct{}
	gateSeen    bool
	releaseOnce sync.Once
}

var gr *genRecorder

// OwnedNativeInit opens the trace exclusively and selects the schedule.
func OwnedNativeInit(path, schedule string) error {
	if schedule != genScheduleNotify && schedule != genScheduleUngated {
		return fmt.Errorf("unknown schedule %q", schedule)
	}
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	gr = &genRecorder{file: f, path: path, schedule: schedule, start: time.Now(), apis: map[*DownloaderAPI]int{}, created: map[*DownloaderAPI]time.Time{},
		channels: map[genKey]int{}, rpcids: map[genKey]string{}, gen: map[genKey]int{}, acked: map[genKey]int{}, members: map[genKey]bool{},
		counts: map[genKey]map[int]map[string]int{}, violations: map[genKey]int{}, firstSeq: map[genKey]map[string]int{}, global: map[string]int{},
		gateEntered: make(chan struct{}), gateRelease: make(chan struct{})}
	return nil
}

// OwnedNativeFinish closes the trace.
func OwnedNativeFinish() error {
	if gr == nil {
		return nil
	}
	return gr.file.Close()
}

func genEmitLocked(api *DownloaderAPI, name string, c chan interface{}, owner, member bool, value interface{}) {
	r := gr
	k := genKey{api, c}
	if api != nil && r.apis[api] == 0 {
		r.apis[api] = len(r.apis) + 1
		r.created[api] = time.Now()
	}
	r.seq++
	r.global[name]++
	id, g, postAck := 0, 0, false
	if c != nil {
		if r.channels[k] == 0 {
			r.channels[k] = len(r.channels) + 1
		}
		id = r.channels[k]
		if name == "install" {
			r.gen[k]++
		}
		g = r.gen[k]
		if r.counts[k] == nil {
			r.counts[k] = map[int]map[string]int{}
			r.firstSeq[k] = map[string]int{}
		}
		if r.counts[k][g] == nil {
			r.counts[k][g] = map[string]int{}
		}
		r.counts[k][g][name]++
		if r.firstSeq[k][name] == 0 {
			r.firstSeq[k][name] = r.seq
		}
		if owner {
			r.members[k] = member
		}
		if name == "ack_close_end" {
			r.acked[k] = g
		}
		postAck = genUseEvents[name] && r.acked[k] > 0 && r.acked[k] == g
		if postAck {
			r.violations[k]++
		}
	}
	age := int64(0)
	if api != nil {
		age = time.Since(r.created[api]).Nanoseconds()
	}
	row := map[string]interface{}{"sequence": r.seq, "event": name, "elapsed_ns": time.Since(r.start).Nanoseconds(), "api_id": r.apis[api], "api_age_ns": age,
		"channel_id": id, "subscription_id": r.rpcids[k], "generation": g, "acked_generation": r.acked[k], "channel_use": genUseEvents[name],
		"post_ack_same_generation_use": postAck, "owner_map_observed": owner, "member": member, "value": value}
	if e := json.NewEncoder(r.file).Encode(row); e != nil {
		panic(e)
	}
}

func ksNativeCapture(api *DownloaderAPI) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	genEmitLocked(api, "factory_API_created", nil, false, false, nil)
}

func ksNativeCallback(api *DownloaderAPI, name string, c chan interface{}, sid rpc.ID) {
	r := gr
	r.mu.Lock()
	k := genKey{api, c}
	r.rpcids[k] = string(sid)
	genEmitLocked(api, name, c, false, false, nil)
	wait := r.schedule == genScheduleNotify && name == "callback_notify_begin" && k == r.selected && r.gen[k] == 1
	if wait && !r.gateSeen {
		r.gateSeen = true
		close(r.gateEntered)
	}
	r.mu.Unlock()
	if wait {
		<-r.gateRelease
	}
}

func ksNativeLifecycle(api *DownloaderAPI, name string, c chan interface{}, members map[chan interface{}]struct{}) {
	r := gr
	r.mu.Lock()
	_, member := members[c]
	genEmitLocked(api, name, c, members != nil, member, nil)
	r.mu.Unlock()
}

func genEmitFor(k genKey, name string, value interface{}) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	genEmitLocked(k.api, name, k.c, false, false, value)
}

func genCount(k genKey, g int, name string) int {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	return gr.counts[k][g][name]
}

func genGeneration(k genKey) int { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.gen[k] }
func genMember(k genKey) bool    { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.members[k] }
func genAcked(k genKey) int      { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.acked[k] }

func genUntil(p func() bool, limit time.Duration) error {
	end := time.Now().Add(limit)
	for time.Now().Before(end) {
		if p() {
			return nil
		}
		time.Sleep(time.Millisecond)
	}
	return fmt.Errorf("bounded generation observation did not complete")
}

func genSnapshot(name string) error {
	b := make([]byte, 4<<20)
	n := runtime.Stack(b, true)
	if n == len(b) {
		return fmt.Errorf("truncated stack")
	}
	return os.WriteFile(gr.path+"."+name+".stack", b[:n], 0600)
}

func genRelease() {
	gr.releaseOnce.Do(func() { genEmitFor(gr.selected, "native_gate_release", nil); close(gr.gateRelease) })
}

// newCallbackKey returns the single callback key on the selected API created after seq.
func genNewCallbackKey(after int) (genKey, error) {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	var found []genKey
	for k, first := range gr.firstSeq {
		if k.api == gr.selected.api && first["callback_status_created"] > after {
			found = append(found, k)
		}
	}
	if len(found) != 1 {
		return genKey{}, fmt.Errorf("expected one new RPC callback channel, found %d", len(found))
	}
	return found[0], nil
}

func genGlobalCount(name string) int { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.global[name] }

func genCurrentSeq() int { gr.mu.Lock(); defer gr.mu.Unlock(); return gr.seq }

// OwnedNativePrepare selects the factory subscription whose API wraps the given real objects.
func OwnedNativePrepare(d *Downloader, chain *core.BlockChain, mux *event.TypeMux, sid string) error {
	return genUntil(func() bool {
		r := gr
		r.mu.Lock()
		defer r.mu.Unlock()
		for api := range r.apis {
			if api.d != d || api.chain != chain || api.mux != mux {
				continue
			}
			for k, id := range r.rpcids {
				if k.api == api && id == sid && r.counts[k][1]["install"] == 1 {
					r.selected = k
					genEmitLocked(api, "selected_factory_subscription", k.c, false, false, map[string]interface{}{"same_downloader": true, "same_blockchain": true,
						"same_mux": true, "unbuffered_status_channel": cap(k.c) == 0, "subscription_id": sid, "generation": 1})
					return true
				}
			}
		}
		return false
	}, genBoundedWait)
}

// ownedRescueReceive drains one pending owner send to k; it is an owned cleanup, not a source use.
func genOwnedRescueReceive(k genKey) error {
	genEmitFor(k, "owned_rescue_status_receive_begin", nil)
	select {
	case value := <-k.c:
		genEmitFor(k, "owned_rescue_status_receive_end", fmt.Sprint(value))
	case <-time.After(genBoundedWait):
		return fmt.Errorf("owned rescue receive stalled")
	}
	return nil
}

// ownedManualUninstall asks the real owner loop to delete and acknowledge k.
func genOwnedManualUninstall(k genKey) error {
	genEmitFor(k, "owned_rescue_manual_uninstall_begin", map[string]interface{}{"generation": genGeneration(k)})
	req := uninstallSyncSubscriptionRequest{c: k.c, uninstalled: make(chan interface{})}
	select {
	case k.api.uninstallSyncSubscription <- &req:
	case <-time.After(genBoundedWait):
		return fmt.Errorf("owned cleanup uninstall not accepted")
	}
	select {
	case <-req.uninstalled:
	case <-time.After(genBoundedWait):
		return fmt.Errorf("owned cleanup real acknowledgement missing")
	}
	genEmitFor(k, "owned_rescue_manual_uninstall_end", nil)
	return nil
}

// awaitAck waits for the real owner ack of the current generation of k, rescuing
// only when the source cannot reach it by itself (counted, never a fake ack).
func genAwaitAck(k genKey, allowManual bool) error {
	g := genGeneration(k)
	if genUntil(func() bool { return genCount(k, g, "ack_close_end") >= 1 }, genBoundedWait) == nil {
		return nil
	}
	if !allowManual {
		return fmt.Errorf("real owner ack for generation %d missing", g)
	}
	if e := genOwnedManualUninstall(k); e != nil {
		return e
	}
	return genUntil(func() bool { return genCount(k, g, "ack_close_end") >= 1 }, genBoundedWait)
}

// OwnedNotifyInFlight holds the selected callback just before it forwards the
// done status, closes the RPC connection, lets the server teardown settle and
// releases the callback. The exit branch it then takes is recorded.
func OwnedNotifyInFlight(client *rpc.Client, role string) error {
	k := gr.selected
	select {
	case <-gr.gateEntered:
	case <-time.After(genTimerWait):
		return fmt.Errorf("original native done never reached the selected callback")
	}
	genEmitFor(k, "callback_notify_gate_observed", map[string]interface{}{"native_timer_seconds": 60, "declared_schedule_gate": true})
	// Close returns only after the server side has torn down, so the begin
	// event is what orders the close before the callback exit.
	genEmitFor(k, "actual_transport_close_begin", nil)
	client.Close()
	genEmitFor(k, "actual_transport_closed", map[string]interface{}{"owner_ack_not_inferred": true})
	time.Sleep(genTeardownSettle)
	genEmitFor(k, "transport_teardown_settled", map[string]interface{}{"settle_ms": genTeardownSettle.Milliseconds()})
	if e := genSnapshot("before-callback-release"); e != nil {
		return e
	}
	genRelease()
	if e := genUntil(func() bool {
		return genCount(k, 1, "callback_exit_rpc_error")+genCount(k, 1, "callback_exit_transport_closed") == 1 && genCount(k, 1, "callback_returned") == 1
	}, genBoundedWait); e != nil {
		return e
	}
	genEmitFor(k, "notify_observation_frozen", genFrozen(k, 1))
	return genAwaitAck(k, role == "MUT-EARLY")
}

// OwnedPreTimerTransport closes the RPC connection before the native timer with
// no gate and waits for the old generation's real owner ack.
func OwnedPreTimerTransport(client *rpc.Client) error {
	k := gr.selected
	if genGlobalCount("native_timer_fired") > 0 || genGlobalCount("native_send_begin_done") > 0 {
		return fmt.Errorf("native timer already fired before pre-timer transport close")
	}
	// Close returns only after the server side has torn down, so the begin
	// event is what orders the close before the callback exit.
	genEmitFor(k, "actual_transport_close_begin", nil)
	client.Close()
	genEmitFor(k, "actual_transport_closed", map[string]interface{}{"owner_ack_not_inferred": true})
	if e := genUntil(func() bool {
		return genCount(k, 1, "callback_exit_rpc_error")+genCount(k, 1, "callback_exit_transport_closed") == 1 && genCount(k, 1, "method_entry") == 1
	}, genBoundedWait); e != nil {
		return e
	}
	if e := genAwaitAck(k, false); e != nil {
		return e
	}
	return genUntil(func() bool { return genCount(k, 1, "callback_returned") == 1 && genCount(k, 1, "method_return") == 1 }, genBoundedWait)
}

func genFrozen(k genKey, g int) map[string]interface{} {
	gr.mu.Lock()
	defer gr.mu.Unlock()
	counts := map[string]int{}
	for name, n := range gr.counts[k][g] {
		counts[name] = n
	}
	return map[string]interface{}{"channel_id": gr.channels[k], "generation": g, "counts": counts, "member": gr.members[k], "acked_generation": gr.acked[k]}
}

// OwnedRegenerate performs explicit new registrations after the old generation's
// real owner ack: a same-channel re-registration through the factory API and a
// new RPC subscription. After a transport close the caller passes a new client.
// For the timer schedule both stay registered across the natural broadcast.
func OwnedRegenerate(client *rpc.Client, role string) error {
	old := gr.selected
	manual := role == "MUT-EARLY"
	if genAcked(old) != 1 || genMember(old) && role != "MUT-STALE-ACK" {
		return fmt.Errorf("old generation not acknowledged before regeneration")
	}
	genEmitFor(old, "regeneration_begin", map[string]interface{}{"schedule": gr.schedule, "old_acked_generation": genAcked(old), "old_member": genMember(old)})
	probe := genStartSameChannel(old)
	defer probe.stop()
	if gr.schedule == genScheduleNotify {
		if e := genUntil(func() bool { return genCount(old, 2, "install") == 1 && genCount(old, 2, "probe_status_received") == 1 }, genBoundedWait); e != nil {
			return e
		}
		genEmitFor(old, "same_channel_registration_delivered", map[string]interface{}{"generation": 2, "route": "install_send"})
		if e := probe.finish(manual); e != nil {
			return e
		}
	} else if e := genUntil(func() bool { return genCount(old, 2, "install") == 1 }, genBoundedWait); e != nil {
		return e
	}
	mark := genCurrentSeq()
	ch := make(chan json.RawMessage, 4)
	ctx, cancel := context.WithTimeout(context.Background(), genBoundedWait)
	defer cancel()
	sub, e := client.EthSubscribe(ctx, ch, "syncing")
	if e != nil {
		return fmt.Errorf("new RPC subscribe: %w", e)
	}
	defer sub.Unsubscribe()
	var fresh genKey
	if e = genUntil(func() bool {
		k, err := genNewCallbackKey(mark)
		if err != nil {
			return false
		}
		fresh = k
		return genCount(k, 1, "install") == 1
	}, genBoundedWait); e != nil {
		return e
	}
	genEmitFor(fresh, "new_rpc_registration_installed", map[string]interface{}{"generation": 1, "distinct_channel": fresh.c != old.c})
	if gr.schedule == genScheduleUngated {
		if e = genTimerBroadcast(old, fresh); e != nil {
			return e
		}
		if e = probe.finish(manual); e != nil {
			return e
		}
	}
	select {
	case raw := <-ch:
		genEmitFor(fresh, "client_notification_received", string(raw))
	case <-time.After(genBoundedWait):
		return fmt.Errorf("new RPC registration did not receive its notification")
	}
	sub.Unsubscribe()
	genEmitFor(fresh, "client_unsubscribe_returned", nil)
	if e = genUntil(func() bool { return genCount(fresh, 1, "callback_exit_rpc_error") == 1 }, genBoundedWait); e != nil {
		return e
	}
	if e = genAwaitAck(fresh, manual); e != nil {
		return e
	}
	time.Sleep(genQuietWindow)
	return nil
}

type genProbe struct {
	k        genKey
	sub      *SyncStatusSubscription
	quit     chan struct{}
	done     chan struct{}
	stopOnce sync.Once
}

// genStartSameChannel re-registers the acknowledged channel itself (generation 2)
// with an owned probe consuming it.
func genStartSameChannel(old genKey) *genProbe {
	p := &genProbe{k: old, quit: make(chan struct{}), done: make(chan struct{})}
	go func() {
		defer close(p.done)
		for {
			select {
			case v := <-old.c:
				ksNativeLifecycle(old.api, "probe_status_received", old.c, nil)
				genEmitFor(old, "probe_payload", fmt.Sprint(v))
			case <-p.quit:
				return
			}
		}
	}()
	p.sub = old.api.SubscribeSyncStatus(old.c)
	return p
}

// finish unsubscribes generation 2 and waits for its real owner ack.
func (p *genProbe) finish(manual bool) error {
	p.sub.Unsubscribe()
	return genAwaitAck(p.k, manual)
}

func (p *genProbe) stop() {
	p.stopOnce.Do(func() { close(p.quit); <-p.done })
}

// genTimerBroadcast waits for the natural 60s done broadcast while generation 2
// of the old channel and the new RPC registration are both installed.
func genTimerBroadcast(old, fresh genKey) error {
	if e := genUntil(func() bool {
		return genCount(fresh, 1, "native_send_end_done") == 1 && genCount(old, 2, "probe_status_received") == 1
	}, genTimerWait); e != nil {
		return fmt.Errorf("native done broadcast to both registrations not observed: %w", e)
	}
	time.Sleep(300 * time.Millisecond)
	if e := genSnapshot("timer-broadcast"); e != nil {
		return e
	}
	genEmitFor(old, "timer_observation_frozen", map[string]interface{}{"old_generation1": genFrozen(old, 1), "old_generation2": genFrozen(old, 2), "new": genFrozen(fresh, 1)})
	return nil
}

// OwnedSummary emits the final per-key generation table.
func OwnedSummary() {
	gr.mu.Lock()
	rows := []map[string]interface{}{}
	for k, id := range gr.channels {
		if k.api != gr.selected.api {
			continue
		}
		rows = append(rows, map[string]interface{}{"channel_id": id, "subscription_id": gr.rpcids[k], "generations": gr.gen[k], "acked_generation": gr.acked[k],
			"member": gr.members[k], "post_ack_same_generation_uses": gr.violations[k], "counts": gr.counts[k]})
	}
	gr.mu.Unlock()
	sort.Slice(rows, func(i, j int) bool { return rows[i]["channel_id"].(int) < rows[j]["channel_id"].(int) })
	genEmitFor(gr.selected, "generation_summary", rows)
}
