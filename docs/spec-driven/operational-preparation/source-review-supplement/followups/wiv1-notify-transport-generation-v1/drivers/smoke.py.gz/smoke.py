"""Pre-matrix smoke: build two roles (general) in the probe clone and run one slot each."""
import json, subprocess, sys, time
from pathlib import Path
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter, transport_instrument as gi
a = ks_adapter.Adapter(sys.argv[1]); out = Path(sys.argv[2]).resolve(); out.mkdir(parents=True)
ks = a.path('KS_ROOT'); ov = ks / 'docs/spec-driven/operational-preparation/source-review-supplement/followups/ticket-dev-gold-v1/private/overlays'
env = a.go_env(a.path('WORK_ROOT') / 'go-build-cache'); src = a.path('WORK_ROOT') / 'probe/source'
res = []
for schedule, role in [('notify-in-flight', 'CAND-A'), ('transport-ungated', 'MUT-STALE-ACK')]:
    raw = gi.stale_ack_overlay((ov / 'CAND-A.go.txt').read_bytes()) if role == 'MUT-STALE-ACK' else (ov / f'{role}.go.txt').read_bytes()
    (src / 'eth/downloader/api.go').write_bytes(gi.instrument(raw, role, a.gofmt)[0])
    for n, f in [('eth/downloader/ks_notify_generation.go', 'notify-bridge.go'), ('cmd/ks-notify-generation/main.go', 'notify-main.go')]:
        (src / n).write_bytes((TOOLS / f).read_bytes())
    b = out / f'{role}.program'
    subprocess.run([a.go, 'build', '-o', str(b), './cmd/ks-notify-generation'], cwd=src, env=env, check=True)
    q = out / f'{schedule}-{role}'; q.mkdir(); (q / 'tmp').mkdir()
    t = time.monotonic()
    p = subprocess.run([str(b)], cwd=src, env={**env, 'TMPDIR': str(q / 'tmp'), 'KS_NATIVE_TRACE': str(q / 'events.jsonl'), 'KS_NATIVE_ROLE': role, 'KS_NATIVE_SCHEDULE': schedule}, capture_output=True, timeout=150)
    (q / 'stdout').write_bytes(p.stdout); (q / 'stderr').write_bytes(p.stderr)
    res.append(dict(schedule=schedule, role=role, exit=p.returncode, seconds=round(time.monotonic() - t, 1)))
    print(res[-1], flush=True)
(out / 'smoke.json').write_text(json.dumps(res, indent=2) + '\n')
