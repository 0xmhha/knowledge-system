"""Source-observation rules for the transport-close and same-channel timer matrix.

The stage-91 rules are kept unchanged: every operation on a status channel in
eth/downloader/api.go gets one trace call. One rule is added: the owner records
map membership immediately before an install, so a re-registration that lands on
a stale entry of the same key is visible even though the channel is the same.
The original timer, StartEvent handling and progress logic are not changed.
"""
import re
import subprocess

STALE_ACK_DELETE = '\t\t\tdelete(syncSubscriptions, u.c)\n'

# (anchor, replacement, {role: expected count}); roles not listed expect 1.
RULES = [
    ('go api.eventLoop()', 'ksNativeCapture(api)\ngo api.eventLoop()', {}),
    ('api.installSyncSubscription <- status', 'ksNativeLifecycle(api,"register_request",status,nil)\napi.installSyncSubscription <- status', {}),
    ('syncSubscriptions[i] = struct{}{}', 'ksNativeLifecycle(api,"before_install",i,syncSubscriptions)\nsyncSubscriptions[i] = struct{}{}\nksNativeLifecycle(api,"install",i,syncSubscriptions)', {}),
    ('case <-checkTimer.C:', 'case <-checkTimer.C:\nksNativeLifecycle(api,"native_timer_fired",nil,nil)', {}),
    ('case StartEvent:', 'case StartEvent:\nksNativeLifecycle(api,"source_StartEvent_received",nil,nil)', {}),
    ('delete(syncSubscriptions, u.c)', 'ksNativeLifecycle(api,"before_delete",u.c,syncSubscriptions)\ndelete(syncSubscriptions,u.c)\nksNativeLifecycle(api,"after_delete",u.c,syncSubscriptions)', {'MUT-STALE-ACK': 0}),
    ('close(u.uninstalled)', 'ksNativeLifecycle(api,"ack_close_begin",u.c,syncSubscriptions)\nclose(u.uninstalled)\nksNativeLifecycle(api,"ack_close_end",u.c,syncSubscriptions)', {}),
    ('c <- notification', 'ksNativeLifecycle(api,"native_send_begin_progress",c,syncSubscriptions)\nc <- notification\nksNativeLifecycle(api,"native_send_end_progress",c,syncSubscriptions)', {}),
    ('c <- false', 'ksNativeLifecycle(api,"native_send_begin_done",c,syncSubscriptions)\nc <- false\nksNativeLifecycle(api,"native_send_end_done",c,syncSubscriptions)', {}),
    ('i <- false', 'ksNativeLifecycle(api,"install_send_begin",i,syncSubscriptions)\ni <- false\nksNativeLifecycle(api,"install_send_end",i,syncSubscriptions)', {}),
    ('statuses := make(chan interface{})', 'statuses := make(chan interface{})\nksNativeCallback(api,"callback_status_created",statuses,rpcSub.ID)', {}),
    ('defer sub.Unsubscribe()', 'defer ksNativeCallback(api,"callback_returned",statuses,rpcSub.ID)\ndefer sub.Unsubscribe()', {}),
    ('case status := <-statuses:', 'case status := <-statuses:\nksNativeCallback(api,"callback_status_received",statuses,rpcSub.ID)', {}),
    ('notifier.Notify(rpcSub.ID, status)', 'ksNativeCallback(api,"callback_notify_begin",statuses,rpcSub.ID)\nnotifier.Notify(rpcSub.ID, status)\nksNativeCallback(api,"callback_notify_end",statuses,rpcSub.ID)', {}),
    ('case <-rpcSub.Err():', 'case <-rpcSub.Err():\nksNativeCallback(api,"callback_exit_rpc_error",statuses,rpcSub.ID)', {}),
    ('case <-notifier.Closed():', 'case <-notifier.Closed():\nksNativeCallback(api,"callback_exit_transport_closed",statuses,rpcSub.ID)', {}),
    ('func (s *SyncStatusSubscription) Unsubscribe() {', 'func (s *SyncStatusSubscription) Unsubscribe() {\nksNativeLifecycle(s.api,"method_entry",s.c,nil)\ndefer ksNativeLifecycle(s.api,"method_return",s.c,nil)', {}),
    ('\t\ts.api.uninstallSyncSubscription <- &req\n', '\t\ts.api.uninstallSyncSubscription <- &req\nksNativeLifecycle(s.api,"method_uninstall_request_sent",s.c,nil)\n',
     {'CAND-A': 0, 'CAND-B': 0, 'MUT-EARLY': 0, 'MUT-STALE-ACK': 0}),
    ('case s.api.uninstallSyncSubscription <- &req:', 'case s.api.uninstallSyncSubscription <- &req:\nksNativeLifecycle(s.api,"method_uninstall_request_sent",s.c,nil)',
     {'ORIGINAL': 0, 'CAND-B': 0, 'MUT-EARLY': 0}),
    ('case send <- &req:', 'case send <- &req:\nksNativeLifecycle(s.api,"method_uninstall_request_sent",s.c,nil)',
     {'ORIGINAL': 0, 'CAND-A': 0, 'MUT-EARLY': 0, 'MUT-STALE-ACK': 0}),
    ('case <-s.c:', 'case <-s.c:\nksNativeLifecycle(s.api,"method_status_received",s.c,nil)', {'CAND-A': 2, 'MUT-STALE-ACK': 2, 'MUT-EARLY': 0}),
    ('case <-req.uninstalled:', 'case <-req.uninstalled:\nksNativeLifecycle(s.api,"method_ack_observed",s.c,nil)', {'MUT-EARLY': 0}),
]

# Status-channel operations that must each be covered by a rule above.
CHANNEL_SITE = re.compile(r'(?:\bi <- false|\bc <- (?:false|notification)|<-statuses|<-s\.c\b|installSyncSubscription <- status|'
                          r'uninstallSyncSubscription <- &req|send <- &req|<-req\.uninstalled|close\(u\.uninstalled\))')


def stale_ack_overlay(cand_a):
    """Derive the violation control: CAND-A whose owner acknowledges without deleting."""
    text = cand_a.decode()
    if text.count(STALE_ACK_DELETE) != 1:
        raise AssertionError('CAND-A delete anchor changed')
    return text.replace(STALE_ACK_DELETE, '').encode()


def channel_sites(raw):
    return [dict(line=n, text=line.strip()) for n, line in enumerate(raw.decode().splitlines(), 1) if CHANNEL_SITE.search(line)]


def instrument(raw, role, gofmt):
    s = raw.decode()
    counts = {}
    for old, new, expected in RULES:
        count = s.count(old)
        want = expected.get(role, 1)
        if count != want:
            raise AssertionError((role, old, count, want))
        counts[old] = count
        s = s.replace(old, new)
    result = subprocess.check_output([gofmt], input=s.encode())
    if b'checkInterval     = time.Second * 60' not in result:
        raise AssertionError('original 60s timer changed')
    return result, counts
