"""Run the Notify-in-flight and ungated transport matrix on owned go-stablenet clones.

Usage: notify_run.py ADAPTER_CONFIG RUN_NAME

Builds one instrumented clone per unique role, runs every declared slot once
(no automatic retry), and records receipts, traces and bindings under
WORK_ROOT/RUN_NAME/evidence. The owned upstream checkout is verified unchanged.
"""
import concurrent.futures
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import transport_instrument as gi  # noqa: E402
import ks_adapter  # noqa: E402

FOLLOWUPS = 'docs/spec-driven/operational-preparation/source-review-supplement/followups'
OVERLAYS = FOLLOWUPS + '/ticket-dev-gold-v1/private/overlays'
BASELINE = FOLLOWUPS + '/wi4-target-subscription-v1/corrective/source-binding.json'
API = 'eth/downloader/api.go'
BRIDGE = 'eth/downloader/ks_notify_generation.go'
MAIN = 'cmd/ks-notify-generation/main.go'
SCHEDULES = {
    'notify-in-flight': ['ORIGINAL', 'CAND-A', 'CAND-B', 'MUT-EARLY'],
    'transport-ungated': ['ORIGINAL', 'CAND-A', 'CAND-B', 'MUT-STALE-ACK'],
}
PROFILES = ['general', 'race']
BUILD_TIMEOUT = 900
PROGRAM_TIMEOUT = 150
PARALLELISM = 2


def load_helpers(ks):
    spec = importlib.util.spec_from_file_location('owner', ks / 'scripts/run-full-host-owner.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod, mod.m


def main(config, run_name):
    a = ks_adapter.Adapter(config)
    ks = a.path('KS_ROOT')
    mod, m = load_helpers(ks)
    work = a.path('WORK_ROOT') / run_name
    work.mkdir()
    out = work / 'evidence'
    out.mkdir()
    env = a.go_env(a.path('WORK_ROOT') / 'go-build-cache')
    parent = a.path('UPSTREAM_SOURCE')
    before = m.source_inventory(parent)
    status = m.git(parent, 'status', '--porcelain', '--untracked-files=all')
    m.write(out / 'original-before.json', before)
    (out / 'original-status-before.txt').write_bytes(status)
    expected = json.loads((ks / BASELINE).read_text())['tracked']
    bridge = (TOOLS / 'notify-bridge.go').read_bytes()
    native_main = (TOOLS / 'notify-main.go').read_bytes()
    roles = sorted({r for rs in SCHEDULES.values() for r in rs})
    slots = [dict(slot_id=f'{s}-{r}-{p}', schedule=s, candidate=r, variant=p, repetition=1)
             for s, rs in SCHEDULES.items() for r in rs for p in PROFILES]
    scope = dict(kind='actual_factory_notify_in_flight_and_ungated_transport_generation_boundary_DEV', source_commit=ks_adapter.COMMIT,
                 knowledge_source_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ks, text=True).strip(),
                 adapter=a.describe(), planned_slots=slots, unique_build_roles=roles, owned_nodes_per_slot=2,
                 native_timer_seconds=60, automatic_retries=0, build_timeout=BUILD_TIMEOUT, program_timeout=PROGRAM_TIMEOUT,
                 runtime_parallelism=PARALLELISM, bridge_sha256=m.sha(bridge), main_sha256=m.sha(native_main),
                 driver_sha256=m.sha(Path(__file__).read_bytes()), instrumentation_sha256=m.sha((TOOLS / 'transport_instrument.py').read_bytes()),
                 adapter_module_sha256=m.sha((TOOLS / 'ks_adapter.py').read_bytes()), environment=a.redact(json.dumps(env, sort_keys=True)),
                 formal_completed=0, independent_approved=0, freeze=None, execution_allowed=False, LLM_calls=0, paid_calls=0)
    m.write(out / 'SCOPE.json', scope)
    built = {}
    for role in roles:
        q = out / 'candidates' / role
        q.mkdir(parents=True)
        src = work / ('source-' + role)
        for label, argv, cwd in [('clone', ['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--shared', '--no-checkout', str(parent), str(src)], work),
                                 ('checkout', ['git', '-c', 'core.hooksPath=/dev/null', 'checkout', '--detach', ks_adapter.COMMIT], src)]:
            r = m.command(argv, cwd, q / label, env, 60)
            if r['exit_code'] != 0 or r['remaining_live_group_members']:
                raise SystemExit(f'{role} {label} failed')
        baseline = m.source_inventory(src)
        if baseline != expected or m.git(src, 'status', '--porcelain'):
            raise SystemExit(role + ' baseline differs from retained binding')
        cand_a = (ks / OVERLAYS / 'CAND-A.go.txt').read_bytes()
        retained = gi.stale_ack_overlay(cand_a) if role == 'MUT-STALE-ACK' else (ks / OVERLAYS / f'{role}.go.txt').read_bytes()
        overlay, counts = gi.instrument(retained, role, a.gofmt)
        files = [(API, overlay), (BRIDGE, bridge), (MAIN, native_main)]
        for name, data in files:
            target = src / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        applied = dict(baseline)
        applied[API] = dict(mode=baseline[API]['mode'], sha256=m.sha(overlay))
        if m.source_inventory(src) != applied:
            raise SystemExit(role + ' applied inventory differs')
        m.write(q / 'source-binding.json', dict(source_commit=ks_adapter.COMMIT, base_tracked_matches_retained=True, applied_api_sha256=m.sha(overlay),
                                                additions={BRIDGE: m.sha(bridge), MAIN: m.sha(native_main)}, retained_api_sha256=m.sha(retained),
                                                derived_from='CAND-A without owner delete' if role == 'MUT-STALE-ACK' else 'retained overlay',
                                                instrumentation_counts=counts, channel_sites=gi.channel_sites(retained), production_patch=False))
        m.write(q / 'tree-binding.json', mod.tree_input(src, q, env, files))
        (q / 'instrumented-api.go').write_bytes(overlay)
        bins = {}
        for v in PROFILES:
            binary = q / (v + '.program')
            argv = [a.go, 'build'] + (['-race'] if v == 'race' else []) + ['-o', str(binary), './cmd/ks-notify-generation']
            r = m.command(argv, src, q / ('build-' + v), env, BUILD_TIMEOUT)
            if r['exit_code'] != 0 or r['remaining_live_group_members']:
                raise SystemExit(f'{role} {v} build failed')
            bins[v] = dict(path=a.redact(str(binary)), sha256=m.sha(binary.read_bytes()), local=str(binary))
            (q / (v + '-build-info.txt')).write_bytes(subprocess.check_output([a.go, 'version', '-m', str(binary)], cwd=src, env=env))
            print('built', role, v, flush=True)
        m.write(q / 'binaries.json', {v: dict(path=b['path'], sha256=b['sha256']) for v, b in bins.items()})
        built[role] = (src, bins, applied)

    def execute(slot):
        q = out / 'slots' / slot['slot_id']
        q.mkdir(parents=True)
        tmp = q / 'tmp'
        tmp.mkdir()
        src, bins, _ = built[slot['candidate']]
        b = bins[slot['variant']]
        r = m.command([b['local']], src, q / 'process',
                      {**env, 'TMPDIR': str(tmp), 'KS_NATIVE_TRACE': str(q / 'events.jsonl'), 'KS_NATIVE_ROLE': slot['candidate'],
                       'KS_NATIVE_SCHEDULE': slot['schedule']}, PROGRAM_TIMEOUT)
        r.update(slot, binary_sha256=b['sha256'], tmp_children_after=sorted(x.name for x in tmp.iterdir()))
        m.write(q / 'receipt.json', r)
        print('slot', slot['slot_id'], 'exit', r['exit_code'], flush=True)
        return r

    attempts = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=PARALLELISM) as pool:
        for r in pool.map(execute, slots):
            attempts.append(r)
            m.write(out / 'attempts.json', attempts)
    for role in roles:
        src, bins, applied = built[role]
        if m.source_inventory(src) != applied or (src / BRIDGE).read_bytes() != bridge or (src / MAIN).read_bytes() != native_main:
            raise SystemExit(role + ' source drifted during run')
        if any(m.sha(Path(b['local']).read_bytes()) != b['sha256'] for b in bins.values()):
            raise SystemExit(role + ' binary drifted during run')
    after = m.source_inventory(parent)
    m.write(out / 'original-after.json', after)
    status_after = m.git(parent, 'status', '--porcelain', '--untracked-files=all')
    (out / 'original-status-after.txt').write_bytes(status_after)
    preserved = before == after and status == status_after
    m.write(out / 'receipt.json', dict(planned=len(slots), attempted=len(attempts), failed=sum(r['exit_code'] != 0 for r in attempts),
                                       automatic_retries=0, source_preserved=preserved, formal_completed=0, independent_approved=0))
    print('notify/ungated transport matrix finished', flush=True)
    return 0 if preserved else 1


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1], sys.argv[2]))
