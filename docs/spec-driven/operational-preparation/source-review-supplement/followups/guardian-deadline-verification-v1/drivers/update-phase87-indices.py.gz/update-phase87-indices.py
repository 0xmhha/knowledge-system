import json,sys
from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');sys.path.insert(0,str(ROOT/'scripts'));import guardian_deadline as p;import viewer_readiness as v
summary=v.read(ROOT/p.PACKET/'SUMMARY.json');ref=p.reference();target=Path('docs/spec-driven/REMAINING-13-EXECUTION.json');d=v.read(ROOT/target)
assert d['optional_active_followups']==9 and d['optional_user_excluded_followups']==1
before_scope=d['user_scope_exclusions'];d['current_activity']='phase87_deadline_false_positive_mechanism_reproduced_test_fixed_and_post_return_contract_verified';d['last_native_validation']=dict(stage=87,path=str(p.PACKET/'SUMMARY.json'),general_pass=summary['native']['test']['pass'],race_pass=summary['native']['race']['pass'],skip_each=18,fresh_Go_source=True,changed_Go_files=1,test_only_change=True,production_runtime_changed=False)
d['current_guardian_deadline_followup']=ref;d['guardian_deadline_disposition']=dict(same_condition_failure_mechanism_reproduced=True,original_diagnostic_failures=2,original_diagnostic_total=400,one_line_control_passed=400,post_return_mutant_rejected=True,test_fixture_corrected=True,production_runtime_changed=False,exact_historical_event_ordering='not_available_in_original_trace',historical_failure_preserved=True)
d['next']='review WI-V1 full12 contract and installed consumer oracle scope; preserve independent gold/freeze requirements and CoreML user exclusion'
assert d['groups_completed']==d['formal_completed']==0 and d['freeze']is None and not d['execution_allowed'] and d['user_scope_exclusions']==before_scope
v.write(ROOT/target,d)
work=dict(path=str(target),sha256=v.sha((ROOT/target).read_bytes()));docs=[v.read(ROOT/n)for n in v.PATHS]
for doc in docs:doc.update(current_readiness_preparation=ref,latest_guardian_deadline_followup=ref,current_execution_state=v.read(ROOT/p.PACKET/'WORKLIST.json'),active_remaining_worklist=work)
v.write(ROOT/v.PATHS[2],docs[2]);link=dict(path=str(v.PATHS[2]),sha256=v.sha((ROOT/v.PATHS[2]).read_bytes()),status='D04_review_pending_local_native_DEV_not_independent_acceptance')
for i in(0,1,3):docs[i]['adoption_acceptance_decision_proposal']=link;v.write(ROOT/v.PATHS[i],docs[i])
assert not p.current_indices(ROOT,docs[0],docs[1]),p.current_indices(ROOT,docs[0],docs[1]);print('phase87 indices linked; CoreML exclusion, parent0/13 and formal0/9 preserved')
