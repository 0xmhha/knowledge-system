from pathlib import Path
ROOT=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');p=ROOT/'docs/spec-driven/CURRENT-HANDOFF.md';old=p.read_text();table=old[old.index('|묶음|'):old.index('\n\nD04미정')]
text='''# 현재 인수인계 — 종료 시한 검사 원인 추적 / 2026-10-20

동일 조건의 실제 시각 계측400회 중2회에서 기존 실패를 재현했다. sleep이 먼저 종료되고 셸이 뒤의 무조건 printf를 실행하면서, 파일이 group kill 호출 중·guardian 반환 전에 생겼다. 기존 검사는 이것도 “종료 후 쓰기”로 보고했다. 두 파일은 반환 시점에 이미 존재했고 stat 오류/반환 후 새 생성은 그 사례들에서 관측되지 않았다.

sleep1;printf를 sleep1&&printf로 한 줄만 바꾼 별도 대조400회는 모두 통과했다. 기존200ms 시한·1초 worker·반환 후1.1초 관찰을 유지했다. 채택한 변경은 시험 파일1개이며 운영 종료 코드는 바꾸지 않았다. 파일 조회 오류와 실제 marker 존재를 별도로 보고한다.

새 검사는 guardian 반환 후에만 writer의 release gate를 연다. owner socket은 계속 열어 절대시한이 종료 원인이 된다. 일반/race 각각3회의 lifecycle 집중 검증은27개씩 통과했다. 실제 후손을 남기는 임시 고장 대조군은 기대한 post-return writer 오류로 실패했고 잔여 프로세스0이다. 처음 대조군의 출력 파이프 대기로 시험 제한에 도달한 시도도 소유 자원을 회수해 보존했으며, 최종 검사는 일반 파일에 진단을 기록한다.

운영 종료 코드의 계측 로그를 제거한 추가400회에서는 실패가 재현되지 않았다. 이 결과도 보존하며, 계측이 드문 실행 순서에 영향을 준다는 제한을 함께 기록한다.

최초 과거1회 실패에는 파일 존재·조회 오류·반환 시각 상세가 없다. 그 사건의 정확한 내부 순서를 사후 확정했다고 주장하지 않는다. 확인한 것은 같은 조건에서 재현한 실패 유형의 원인과 오탐 수정이다. 과거 실패와 모든 진단 시도는 보존하며 모든 환경의 종료 무결함이나 독립 품질 수용을 선언하지 않는다.

새 고정 소스로 기본 전체 일반4273/race4273통과·각18skip·실패0, build/fmt/vet/고정lint/docs 통과다. 입력1815개·Go1305개와 변경된 시험 파일1개를 결속했고 최종 CKS/CKG/CKV는 같은 소스의 고정 후보와 일치한다. 실제 모델/LLM·유료 호출0·운영 적용·게시0이다.

[진단 요약](./operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/SUMMARY.json) · [시도·실패·한계](./operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/REPORT.txt) · [명세](./operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/SPEC.json) · [13묶음 원장](./REMAINING-13-EXECUTION.json).

CoreML은 사용자 지시로 작업·평가·배포와 완료 조건에서 제외했다. 모델/tokenizer/배포 대상을 요구하지 않고 기존 서명된 소스 검증 이력만 보존한다. 기본 Ollama + BGE-M3와 활성 선택 기능9개를 유지한다. [제외 기록](./operational-preparation/source-review-supplement/followups/user-excluded-coreml-scope-v1/SCOPE.json).

## 다음 작업

WI-V1의 남은 전체12계약과 설치된 소비자 oracle 범위를 우선 검토한다. 기존 owner4/별도 통제 late-drain1 범위 채택과 독립 gold/수용을 구분한다. 익명 검토 역할 미정·새 DEV/FINAL·정답/매칭/충분성·F01~08 동결은 임의로 승인하지 않는다.

## 남은 전체13묶음 — 완료0/13

'''+table+'''

D04미정·독립승인0·FINAL0·freeze null·execution_allowed=false·정식0/9를 유지한다. 실명/연락처를 요구하지 않으며 익명 역할로 검토할 수 있다. 보안 전용 gold/ACL/비공개/위조와 감사 기능 평가는 사용자 보류다. 실제 LLM 답변 평가는 모델·인증·총 비용 상한 결정 후 진행한다.

## 보존한 앞선 근거

- [단계86 고정 소스 검증](./operational-preparation/source-review-supplement/followups/coreml-transport-v1/SUMMARY.json): 최초 race 실패와 원본400회 이전 진단20/80회, BGE 기존/새10hits 일치, 당시4272개 기본 회귀. 제외된 기능의 과거 모델 미수용도 보존한다.
- [단계85 공개 형식](./operational-preparation/source-review-supplement/followups/public-v2-surface-v1/SUMMARY.json): 실제 CLI/HTTP 인용11개·hash 일치와 원시 그래프244989/1964193 전 행 대조, 취소/출력 정리 근거.
- [단계84 규모](./operational-preparation/source-review-supplement/followups/scale-long-functions-v1/SUMMARY.json): retained1.242GB/긴 함수3개·21요청의 partial/budget/복구 근거이며 용량 SLA·의미 품질 수용과 구분한다.
- [단계81 owner 범위 채택](./operational-preparation/source-review-supplement/followups/owner-schedule-contract-v1/ADOPTION-MANIFEST.json): 실제4/통제1, 옛 구독·새 등록 전 범위이며 전체12/독립 gold 수용은 아니다.
- [단계80 viewer](./operational-preparation/source-review-supplement/followups/viewer-lifecycle-v1/SUMMARY.json): 당시 built UI 상호작용·소유 backend 종료이며 Atlas·전체 접근성은 미검증이다.
''';p.write_text(text)
p=ROOT/'docs/REMAINING-WORK.md';s=p.read_text().replace('followups/coreml-transport-v1/SUMMARY.json','followups/guardian-deadline-diagnosis-v1/SUMMARY.json').replace('각각4272통과','각각4273통과')
s=s.replace('최초 전체race의 guardian 종료 시한 검사1회 실패는 후속 통과에도 원인 미확정으로 유지한다.','같은 조건400회에서2회의 오탐을 재현해 반환 전 파일 생성으로 확인했다. 대기 성공 조건을 사용한 한 줄 대조400회는 통과했으며, 반환 후 쓰기 gate·실제 후손 잔존 대조군도 검증했다. 과거 최초1회의 정확한 내부 순서는 상세 로그가 없어 사후 확정하지 않는다.')
s=s.replace('다음 우선순위는 이 종료 시한 실패의 원인 추적이다.','다음 우선순위는 WI-V1의 전체12계약·설치 소비자 oracle 범위 검토다.');p.write_text(s)
p=ROOT/'docs/spec-driven/OPERATIONAL-ACCEPTANCE-PROTOCOL.md';s=p.read_text();s+='\n단계87의 [종료 시한 진단](./operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/SUMMARY.json)은 계측400회 중2회의 반환 전 marker와 한 줄 대조400회 통과, 무계측400회 비재현을 모두 보존한다. 기존200ms 시한과 관찰 시간을 유지해 시험 오탐을 고쳤고 실제 반환 후 쓰기 대조군이 거부되는 것을 확인했다. 최초 과거 사건의 정확한 내부 순서는 상세 로그가 없어 확정하지 않는다. 운영 종료 코드 변경이나 독립 수용 승인이 아니다.\n';p.write_text(s)
print('current handoff and remaining work updated; historical trace limit retained')
