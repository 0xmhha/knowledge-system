import json,gzip,sys,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import latest_role_api as x
p=root/x.PACKET;work=Path('/private/tmp/ks-phase89-four-role-20261020');rpc=Path('/private/tmp/ks-phase89-rpc-negative-20261020/evidence')
def compress(source,target):target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
# Preserve execution transcripts, exact source bindings and all failures. Rebuildable binaries,
# data clones and isolated CLI caches are deliberately excluded.
for src in (work/'native').rglob('*'):
 if src.is_file()and src.name not in ['cks','live.json']:compress(src,p/'native'/(str(src.relative_to(work/'native'))+'.gz'))
for top in [work/'evidence',*[work/('P76-'+r)for r in x.roles.ROLES]]:
 for src in top.rglob('*'):
  if not src.is_file()or src.is_symlink():continue
  parts=src.relative_to(work).parts
  if 'claude-config'in parts or'tmp'in parts or any(n.endswith('.lock')for n in parts):continue
  compress(src,p/'roles'/(str(src.relative_to(work))+'.gz'))
for name,target in [('data/dataset-identity.json','dataset-identity.json.gz'),('data/graph/manifest.json','graph-manifest.json.gz')]:compress(work/name,p/'roles'/target)
(p/'roles/empty-live-source.json').write_text(json.dumps(dict(files=sorted(str(n.relative_to(work/'empty-live-source'))for n in(work/'empty-live-source').rglob('*')if n.is_file())))+'\n')
for src in rpc.rglob('*'):
 if src.is_file()and src.name!='live.json'and not src.name.endswith('.program'):compress(src,p/'rpc'/(str(src.relative_to(rpc))+'.gz'))
for src in(work/'mcp-errors').rglob('*'):
 if src.is_file()and src.name!='live.json':compress(src,p/'mcp'/(str(src.relative_to(work/'mcp-errors'))+'.gz'))
for name in ['phase89-build-cks.py','phase89-run-four-role.py','phase89-run-rpc-negative.py','phase89-api-negative-main.go','phase89-run-mcp-errors.py','phase89-four-role-driver.log','phase89-rpc-driver.log','phase89-mcp-errors-driver.log']:
 compress(Path('/private/tmp')/name,p/'drivers'/(name+'.gz'))
compress(work/'RUNPLAN.json',p/'drivers/RUNPLAN.json.gz')
d=x.derive(p);(p/'SUMMARY.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');x.seal(p);errors=x.check();assert not errors,errors
print(json.dumps(d,ensure_ascii=False))
