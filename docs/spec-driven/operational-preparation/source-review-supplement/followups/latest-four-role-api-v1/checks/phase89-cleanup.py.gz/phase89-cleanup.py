import os,sys,json,gzip,subprocess,shutil,hashlib,time
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import latest_role_api as x
p=root/x.PACKET;assert not x.check(),x.check();work=Path('/private/tmp/ks-phase89-four-role-20261020');pgids=set();pids=set()
for q in work.glob('P76-*/exit.json'):
 d=json.loads(q.read_text());pgids.add(d['host_pid']);pids.add(d['host_pid'])
for q in work.glob('P76-*/mcp-frames.jsonl'):
 for line in q.read_text().splitlines():
  r=json.loads(line)
  if r['kind']=='start':pids.update([r['wrapper_pid'],r['child_pid']])
d=json.loads((work/'mcp-errors/session.json').read_text());pgids.add(d['pgid']);pids.add(d['pid'])
rows=subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines();remaining=[dict(pid=int(v[0]),pgid=int(v[1]),state=v[2])for row in rows if len(v:=row.split())==3 and (int(v[0])in pids or int(v[1])in pgids)and not v[2].startswith('Z')]
assert not remaining,remaining
# Check all archived evidence against its manifest once more before deleting temporary originals.
manifest=x.read(p/'manifest.json');assert all(x.sha((p/n).read_bytes())==h for n,h in manifest['artifacts'].items())
paths=[Path('/private/tmp/ks-phase89-go-build-cache'),Path('/private/tmp/ks-phase89-upstream-go-build-cache'),Path('/private/tmp/ks-phase89-four-role-20261020'),Path('/private/tmp/ks-phase89-rpc-negative-20261020')]
before=subprocess.check_output(['df','-k','/private/tmp'],text=True);deleted=[]
for target in paths:
 assert target.parent==Path('/private/tmp')and target.name.startswith('ks-phase89-')and target.is_dir()
 size=int(subprocess.check_output(['du','-sk',str(target)],text=True).split()[0]);shutil.rmtree(target);deleted.append(dict(path=str(target),allocated_bytes_before=size*1024,removed=not target.exists()))
cleanup=dict(kind='owned_cache_data_source_clone_and_rebuildable_binary_cleanup_after_sealed_evidence',owned_process_ids=sorted(pids),owned_host_or_MCP_group_ids=sorted(pgids),remaining_live_owned_members=remaining,deleted=deleted,removed_allocated_bytes=sum(r['allocated_bytes_before']for r in deleted),all_targets_absent=all(not n.exists()for n in paths),before_df=before,after_df=subprocess.check_output(['df','-k','/private/tmp'],text=True),preserved=['original go-stablenet checkout','original knowledge datasets','pinned consumer checkout','global application caches and shared module stores','sealed compressed task evidence and source fixtures'],evidence_manifest_verified_before_deletion=True)
(p/'CLEANUP.json').write_text(json.dumps(cleanup,indent=2)+'\n');x.seal(p);assert not x.check(),x.check();print(json.dumps(dict(removed_GiB=round(cleanup['removed_allocated_bytes']/2**30,3),remaining_owned_processes=len(remaining),temporary_directories_absent=True)))
