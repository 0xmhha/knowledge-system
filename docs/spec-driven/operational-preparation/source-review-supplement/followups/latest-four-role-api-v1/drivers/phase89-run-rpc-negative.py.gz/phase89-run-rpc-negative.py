import os,sys,json,subprocess,importlib.util,hashlib
from pathlib import Path
root=Path.cwd();work=Path('/private/tmp/ks-phase89-rpc-negative-20261020');work.mkdir();out=work/'evidence';out.mkdir();sys.path.insert(0,str(root/'scripts'))
s=importlib.util.spec_from_file_location('owner_run',root/'scripts/run-full-host-owner.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod);m=mod.m
parent=Path('/private/tmp/ks-wi4-target-20261019/source');before=m.source_inventory(parent);status=m.git(parent,'status','--porcelain','--untracked-files=all');m.write(out/'original-before.json',before);(out/'original-status-before.txt').write_bytes(status)
fixture=Path('/private/tmp/phase89-api-negative-main.go').read_bytes();main='cmd/ks-owned-negative-matrix/main.go';api='eth/downloader/api.go';draft=root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/ticket-dev-gold-v1';roles=['ORIGINAL','CAND-A','CAND-B','MUT-REINTRO','MUT-EARLY'];unique=[r for r in roles if r!='MUT-REINTRO']
settings=json.loads(Path('/private/tmp/ks-wi4-target-20261019/dependency-plan.json').read_text())['task_environment'];settings.update(GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GOCACHE='/private/tmp/ks-phase89-upstream-go-build-cache')
env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(settings,PATH='/Users/kevin/.gvm/gos/go1.23.12/bin:/usr/bin:/bin:/usr/sbin:/sbin',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',PYTHONDONTWRITEBYTECODE='1');go='/Users/kevin/.gvm/gos/go1.23.12/bin/go'
m.write(out/'SCOPE.json',dict(source_commit=m.COMMIT,unique_build_roles=unique,alias_roles={'MUT-REINTRO':'ORIGINAL'},planned_slots=[r+'-'+v for r in roles for v in ('general','race')],negative_cases=12,expected_api_errors=120,positive_registry_and_post_error_health_controls=10,source_instrumentation=False,only_declared_overlay_and_main=True,original_timer_not_exercised=True,real_factory_node=True,no_external_peers=True,HTTP='actual ServeHTTP invoked in-process without network listener',automatic_retries=0,formal_completed=0,independent_approved=0,fixture_sha256=m.sha(fixture),driver_sha256=m.sha(Path(__file__).read_bytes()),environment_settings=settings))
expected=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/wi4-target-subscription-v1/corrective/source-binding.json').read_text())['tracked'];built={}
for role in unique:
 q=out/'candidates'/role;q.mkdir(parents=True);src=work/('source-'+role)
 for label,argv,cwd in [('clone',['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(parent),str(src)],work),('checkout',['git','-c','core.hooksPath=/dev/null','checkout','--detach',m.COMMIT],src)]:
  r=m.command(argv,cwd,q/label,env,60);assert r['exit_code']==0 and not r['remaining_live_group_members'],r
 baseline=m.source_inventory(src);assert baseline==expected and not m.git(src,'status','--porcelain')
 overlay=(draft/'private/overlays'/(role+'.go.txt')).read_bytes();(src/api).write_bytes(overlay);(src/main).parent.mkdir();(src/main).write_bytes(fixture)
 applied=dict(baseline);applied[api]=dict(mode=baseline[api]['mode'],sha256=m.sha(overlay));assert m.source_inventory(src)==applied
 m.write(q/'source-binding.json',dict(base_tracked=baseline,applied_tracked=applied,additions={main:m.sha(fixture)},source_commit=m.COMMIT,api_sha256=m.sha(overlay),production_patch=False,source_instrumentation=False));m.write(q/'tree-binding.json',mod.tree_input(src,q,env,[(api,overlay),(main,fixture)]));(q/'api.go').write_bytes(overlay)
 bins={}
 for variant in ('general','race'):
  binary=q/(variant+'.program');r=m.command([go,'build']+(['-race']if variant=='race'else[])+['-o',str(binary),'./cmd/ks-owned-negative-matrix'],src,q/('build-'+variant),env,900);assert r['exit_code']==0 and not r['remaining_live_group_members'],(role,variant,r)
  info=subprocess.check_output([go,'version','-m',str(binary)],cwd=src,env=env);(q/(variant+'-build-info.txt')).write_bytes(info);bins[variant]=dict(path=str(binary),sha256=m.sha(binary.read_bytes()));print('built '+role+' '+variant,flush=True)
 m.write(q/'binaries.json',bins);built[role]=(src,bins,applied)
built['MUT-REINTRO']=built['ORIGINAL'];attempts=[]
for role in roles:
 for variant in ('general','race'):
  sid=role+'-'+variant;q=out/'slots'/sid;q.mkdir(parents=True);tmp=q/'tmp';tmp.mkdir();src,bins,applied=built[role];b=bins[variant];r=m.command([b['path']],src,q/'process',{**env,'TMPDIR':str(tmp)},30);r.update(slot=sid,candidate=role,profile=variant,binary_sha256=b['sha256'],tmp_children_after=sorted(x.name for x in tmp.iterdir()));m.write(q/'receipt.json',r);attempts.append(r);m.write(out/'attempts.json',attempts);print('slot '+sid+' exit '+str(r['exit_code']),flush=True)
  assert r['exit_code']==0 and not r['timeout']and not r['remaining_live_group_members']and not r['tmp_children_after'],r
for role in unique:
 src,bins,applied=built[role];assert m.source_inventory(src)==applied and (src/main).read_bytes()==fixture;assert all(m.sha(Path(b['path']).read_bytes())==b['sha256']for b in bins.values())
after=m.source_inventory(parent);m.write(out/'original-after.json',after);(out/'original-status-after.txt').write_bytes(m.git(parent,'status','--porcelain','--untracked-files=all'));assert before==after and status==m.git(parent,'status','--porcelain','--untracked-files=all')
m.write(out/'receipt.json',dict(planned=10,attempted=len(attempts),failed=0,negative_api_cases=120,formal_completed=0,independent_approved=0,source_preserved=True,source_instrumentation=False,full12_requirement_acceptance=False));print('RPC matrix complete',flush=True)
