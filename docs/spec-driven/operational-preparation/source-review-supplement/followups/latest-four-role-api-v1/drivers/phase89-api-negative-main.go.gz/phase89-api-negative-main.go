package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/eth"
	"github.com/ethereum/go-ethereum/eth/downloader"
	"github.com/ethereum/go-ethereum/eth/ethconfig"
	"github.com/ethereum/go-ethereum/node"
	"github.com/ethereum/go-ethereum/p2p"
	"github.com/ethereum/go-ethereum/params"
	"github.com/ethereum/go-ethereum/rpc"
	"math/big"
	"net/http/httptest"
	"os"
	"strings"
	"time"
)

func emit(k string, v interface{}) {
	_ = json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"event": k, "value": v})
}
func main() {
	if e := run(); e != nil {
		emit("error", e.Error())
		os.Exit(1)
	}
	emit("complete", map[string]interface{}{"negative_cases": 12, "independent_approved": 0, "formal_completed": 0, "native_timer_not_exercised": true})
}
func run() error {
	dir, e := os.MkdirTemp("", "ks-api-negative-")
	if e != nil {
		return e
	}
	defer os.RemoveAll(dir)
	stack, e := node.New(&node.Config{Name: "ks-api-negative", DataDir: dir, P2P: p2p.Config{NoDiscovery: true, NoDial: true, MaxPeers: 0}})
	if e != nil {
		return e
	}
	closed := false
	defer func() {
		if !closed {
			_ = stack.Close()
		}
	}()
	chain := *params.AllEthashProtocolChanges
	chain.TerminalTotalDifficulty = big.NewInt(0)
	chain.TerminalTotalDifficultyPassed = true
	cfg := ethconfig.Defaults
	cfg.Genesis = &core.Genesis{Config: &chain, GasLimit: 30000000, BaseFee: big.NewInt(params.InitialBaseFee), Difficulty: big.NewInt(0)}
	cfg.SyncMode = downloader.FullSync
	cfg.TxLookupLimit = 128
	cfg.EthDiscoveryURLs = nil
	cfg.SnapDiscoveryURLs = nil
	service, e := eth.New(stack, &cfg)
	if e != nil {
		return e
	}
	if e = stack.Start(); e != nil {
		return e
	}
	emit("factory_started", map[string]interface{}{"real_downloader": service.Downloader() != nil, "no_dial": stack.Server().NoDial, "no_discovery": stack.Server().NoDiscovery, "max_peers": stack.Server().MaxPeers, "tx_lookup_limit": cfg.TxLookupLimit, "source_instrumentation": false})
	client := stack.Attach()
	defer client.Close()
	handler, e := stack.RPCHandler()
	if e != nil {
		return e
	}
	// Exercise the real registered server's HTTP handler without a network listener.
	request := httptest.NewRequest("POST", "http://owned.invalid", strings.NewReader(`{"jsonrpc":"2.0","id":1,"method":"eth_subscribe","params":["syncing"]}`))
	request.Header.Set("Content-Type", "application/json")
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	var wire struct {
		Error *struct {
			Code    int    `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if e = json.Unmarshal(response.Body.Bytes(), &wire); e != nil {
		return e
	}
	if wire.Error == nil || wire.Error.Code != -32601 || wire.Error.Message != "notifications not supported" {
		return fmt.Errorf("HTTP unsupported differs: %s", response.Body.String())
	}
	emit("negative", map[string]interface{}{"id": "RPC-N01", "route": "actual_factory_HTTP_ServeHTTP_no_listener", "code": wire.Error.Code, "message": wire.Error.Message, "classification": "EXPECTED_API_ERROR_not_symptom_RED", "HTTP_status": response.Code, "wire": response.Body.String()})
	check := func(id, method string, want int, args ...interface{}) error {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		var value json.RawMessage
		e := client.CallContext(ctx, &value, method, args...)
		re, ok := e.(rpc.Error)
		if !ok || re.ErrorCode() != want || e.Error() == "" {
			return fmt.Errorf("%s expected RPC error %d, got %T %v result %s", id, want, e, e, value)
		}
		emit("negative", map[string]interface{}{"id": id, "route": "actual_factory_inproc_RPC", "method": method, "arguments": args, "code": re.ErrorCode(), "message": e.Error(), "classification": "EXPECTED_API_ERROR_not_symptom_RED", "result": string(value)})
		return nil
	}
	cases := []struct {
		id, method string
		code       int
		args       []interface{}
	}{
		{"RPC-N02", "eth_subscribe", -32602, nil},
		{"RPC-N03", "eth_subscribe", -32602, []interface{}{7}},
		{"RPC-N04", "eth_subscribe", -32602, []interface{}{nil}},
		{"RPC-N05", "eth_subscribe", -32601, []interface{}{"ks_no_such_subscription"}},
		{"RPC-N06", "ks_unknown_subscribe", -32601, []interface{}{"syncing"}},
		{"RPC-N07", "eth_subscribe", -32602, []interface{}{"syncing", "extra"}},
		{"RPC-N08", "eth_unsubscribe", -32000, []interface{}{"0xks_missing"}},
		{"RPC-N09", "eth_unsubscribe", -32602, nil},
		{"RPC-N10", "eth_unsubscribe", -32602, []interface{}{7}},
		{"RPC-N12", "eth_unsubscribe", -32602, []interface{}{"0xks_missing", "extra"}},
	}
	for _, c := range cases {
		if e = check(c.id, c.method, c.code, c.args...); e != nil {
			return e
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	var sid rpc.ID
	if e = client.CallContext(ctx, &sid, "eth_subscribe", "syncing"); e != nil || sid == "" {
		return fmt.Errorf("positive subscribe: %v", e)
	}
	var ok bool
	if e = client.CallContext(ctx, &ok, "eth_unsubscribe", sid); e != nil || !ok {
		return fmt.Errorf("positive unsubscribe: %v", e)
	}
	emit("positive_registry_control", map[string]interface{}{"subscription_id": sid, "unsubscribe_true": ok, "downstream_completion_not_inferred": true})
	if e = check("RPC-N11", "eth_unsubscribe", -32000, sid); e != nil {
		return e
	}
	var syncing json.RawMessage
	if e = client.CallContext(ctx, &syncing, "eth_syncing"); e != nil {
		return fmt.Errorf("post_error_health: %v", e)
	}
	emit("post_error_health", map[string]interface{}{"eth_syncing": string(syncing)})
	client.Close()
	if e = stack.Close(); e != nil {
		return fmt.Errorf("node close: %v", e)
	}
	closed = true
	emit("owned_node_closed", true)
	return nil
}
