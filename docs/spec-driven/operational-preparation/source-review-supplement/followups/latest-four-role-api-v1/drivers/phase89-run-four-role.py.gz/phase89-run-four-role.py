import os,sys,json,hashlib,importlib.util
from pathlib import Path
root=Path.cwd();work=Path('/private/tmp/ks-phase89-four-role-20261020');revision='b8e3488e302e30efb21128032df3b8a9b4607528'
sys.path.insert(0,str(root/'scripts'))
s=importlib.util.spec_from_file_location('four_role_reuse',root/'scripts/run-four-role-current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
metadata=dict(kind='phase89_latest_clean_CKS_actual_roles_scripted_transport',previous_driver_revision_constant=m.REVISION,effective_driver_revision=revision,override='only module REVISION constant; binary build metadata must match current clean HEAD',legacy_case_and_scope_labels='P76 and corrective1 labels inherited from sealed driver; these are new phase89 executions, not retries or historical result reuse',effective_runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reused_driver_sha256=hashlib.sha256((root/'scripts/run-four-role-current.py').read_bytes()).hexdigest(),actual_LLM_calls=0,external_paid_calls=0,cache_cleanup_required=True)
(work/'RUNPLAN.json').write_text(json.dumps(metadata,indent=2));m.REVISION=revision;m.run(work)
print('phase89 four actual roles complete',flush=True)
