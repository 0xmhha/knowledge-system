import os,json,subprocess,importlib.util,hashlib,time
from pathlib import Path
root=Path.cwd();work=Path('/private/tmp/ks-phase89-four-role-20261020');work.mkdir();out=work/'native';out.mkdir();revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert revision=='b8e3488e302e30efb21128032df3b8a9b4607528' and not subprocess.check_output(['git','status','--porcelain'])
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
prior=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/current-source-binding.json').read_text())
# Preserve the full prior native input map, but bind this new build to current clean HEAD.
sha=lambda b:hashlib.sha256(b).hexdigest();maps={k:v for k,v in prior.items()if k.endswith('sha256')and isinstance(v,dict)}
for values in maps.values():
 for n,h in values.items():assert sha((root/n).read_bytes())==h,n
binding=dict(source_revision=revision,current_clean=True,input_maps=maps,prior_binding_sha256=sha((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/guardian-deadline-diagnosis-v1/current-source-binding.json').read_bytes()))
m.write(out/'source-binding.json',binding)
go='/Users/kevin/.gvm/gos/go1.26.8';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=go+'/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT=go,GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-phase89-go-build-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',PYTHONDONTWRITEBYTECODE='1')
r=m.command(['go','build','-o',str(out/'cks'),'./cmd/cks'],root,out/'build',env,900);assert r['exit_code']==0 and not r['timeout']and not r['remaining_live_group_members'],r
info=subprocess.check_output(['go','version','-m',str(out/'cks')],env=env);assert ('vcs.revision='+revision).encode()in info and b'vcs.modified=false'in info;(out/'build-info.txt').write_bytes(info)
for values in maps.values():
 for n,h in values.items():assert sha((root/n).read_bytes())==h,n
assert not subprocess.check_output(['git','status','--porcelain'])
m.write(out/'binary.json',dict(sha256=m.sha((out/'cks').read_bytes()),source_revision=revision,clean_source=True,source_binding_sha256=m.sha((out/'source-binding.json').read_bytes()),build='fresh_go1.26.8_offline_default_profile'))
print('fresh clean CKS built and bound to '+revision,flush=True)
