import os,sys,json,importlib.util,copy
from pathlib import Path
root=Path.cwd();work=Path('/private/tmp/ks-phase89-four-role-20261020');out=work/'mcp-errors';out.mkdir();sys.path.insert(0,str(root/'scripts'))
s=importlib.util.spec_from_file_location('pilot',root/'scripts/run-wi6-pair-pilot.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p);p.BINARY=work/'native/cks'
config=out/'cks.yaml';import re
text=(work/'cks.yaml').read_text();text,n=re.subn(r'(?m)^(\s*)ollama_url:.*$',r'\1ollama_url: http://127.0.0.1:11434',text);assert n==1;config.write_text(text)
pins=json.loads((work/'evidence/SCOPE.json').read_text())['source_pins'];q=dict(node_id=pins['node_id'],expected_commit=pins['source_commit'],expected_source_sha256=pins['function_sha256']);vd='cks.context.value_dependencies';rc='cks.context.rule_candidates'
invalid=[{},dict(node_id='a',canonical_id='b'),dict(node_id=None),dict(node_id=17),dict(node_id=''),dict(canonical_id=False),dict(node_id='a',unknown=True),dict(node_id='a',expected_commit='main'),dict(node_id='a',expected_source_sha256='bad'),dict(node_id='a',expected_snapshot_sha256=None)]
invalid +=[dict(node_id='a',limits=dict(max_nodes=x))for x in [0,1025,1.5,None]]
cases=[]
for i,args in enumerate(invalid):
 cases.append(dict(id='MCP-V-'+str(i+1).zfill(2),tool=vd,args=args,expected='tool_error'))
 cases.append(dict(id='MCP-R-'+str(i+1).zfill(2),tool=rc,args=dict(function=args,rule_pack='go-local-review@1.0.0'),expected='tool_error'))
cases += [dict(id='MCP-R-15',tool=rc,args=dict(function=q,rule_pack='no-such-pack@0'),expected='tool_error'),dict(id='MCP-R-16',tool=rc,args=dict(rule_pack='go-local-review@1.0.0'),expected='tool_error'),dict(id='MCP-T-01',tool='cks.context.no_such_tool',args={},expected='protocol_or_tool_error')]
for tool,label in [(vd,'V'),(rc,'R')]:
 for kind,payload,status in [('source',dict(q,expected_source_sha256='0'*64),'source_mismatch'),('node',dict(node_id='ks_no_such_node'),'not_found')]:
  cases.append(dict(id='MCP-'+label+'-semantic-'+kind,tool=tool,args=payload if tool==vd else dict(function=payload,rule_pack='go-local-review@1.0.0'),expected=status))
p.write(out/'SCOPE.json',dict(kind='current_CKS_MCP_validation_errors_and_structured_status_not_symptom_RED',cases=cases,negative_cases=len(cases),positive_controls=2,paid_calls=0,automatic_retries=0,source_pins=pins))
client=p.Client(out,config);results=[]
try:
 init=client.request('initialize',dict(protocolVersion='2024-11-05',capabilities={},clientInfo=dict(name='phase89-owned-error-check',version='1')));p.write(out/'initialize.json',init);assert 'result'in init['raw_response']
 for case in cases:
  record=client.request('tools/call',dict(name=case['tool'],arguments=case['args']));wire=record['raw_response'];result=wire.get('result',{});payload=result.get('structuredContent');err=bool(wire.get('error')or result.get('isError'))
  if payload is None and result.get('content'):
   try:payload=json.loads(result['content'][0].get('text',''))
   except ValueError:pass
  expected=case['expected'];status=payload.get('status')if isinstance(payload,dict)else None
  passed=err if expected in ['tool_error','protocol_or_tool_error']else not err and status==expected
  record.update(case_id=case['id'],expected=expected,actual_status=status,actual_error=err,classification='EXPECTED_API_ERROR_OR_UNCERTAIN_STATUS_not_symptom_RED',passed=passed);results.append(record);p.write(out/'results.json',results)
  if not passed:raise ValueError('MCP outcome differs '+case['id']+' expected '+expected+' got '+str(wire)[:1400])
 for tool in [vd,rc]:
  args=q if tool==vd else dict(function=q,rule_pack='go-local-review@1.0.0');record=client.request('tools/call',dict(name=tool,arguments=args));wire=record['raw_response'];result=wire.get('result',{});payload=result.get('structuredContent')or json.loads(result['content'][0]['text']);assert not wire.get('error')and not result.get('isError')and payload['status']=='partial' and payload['analysis']['source']['sha256']==pins['function_sha256'];record.update(case_id='positive-'+tool,status='partial',passed=True);results.append(record);p.write(out/'results.json',results)
finally:client.close()
session=json.loads((out/'session.json').read_text());assert session['exit_code']==0 and not any(session[k]for k in ['term_sent','kill_sent','remaining_live_group_members']);p.write(out/'receipt.json',dict(negative_cases=len(cases),positive_controls=2,all_passed=True,formal_completed=0,independent_approved=0));print('MCP negative cases',len(cases),'positive2',flush=True)
