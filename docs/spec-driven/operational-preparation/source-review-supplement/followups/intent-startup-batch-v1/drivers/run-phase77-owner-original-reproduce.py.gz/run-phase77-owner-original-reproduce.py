import importlib.util,os
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system')
s=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
go='/Users/kevin/.gvm/gos/go1.26.8/bin/go';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=str(Path(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod')
for race in (True,):
 r=m.command([go,'test']+(['-race']if race else[])+['-json','-count=20','-run=^TestGuardianActualOwnerKillStopsWriterAndReleasesLease$','-timeout=3m','./internal/setup'],root,Path('/private/tmp/ks-phase77-owner-original-reproduce-20261019')/('race'if race else'general'),env,240)
 print(r['exit_code'],flush=True)
 if r['exit_code']:raise SystemExit(1)
