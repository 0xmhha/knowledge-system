import importlib.util,json,os,subprocess
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system')
source=Path('/private/tmp/ks-phase77-candidate-final-20261019/source-binding.json');binding=json.loads(source.read_text());assert binding['base_revision']=='7d5a5537c24a73a2a191d2f94b6243fb98c0d059'and len(binding['changed_native_files'])==9
spec=importlib.util.spec_from_file_location('native',root/'scripts/verify-wi3-reasons-native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
env={k:os.environ[k]for k in ('HOME','USER','LOGNAME','SHELL','TMPDIR','LANG','LC_ALL','CGO_ENABLED','CC','CXX','PKG_CONFIG_PATH')if k in os.environ};env.update(PATH='/Users/kevin/.gvm/gos/go1.26.8/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod');env['GIT_CONFIG_GLOBAL']='/dev/null';env['GIT_CONFIG_NOSYSTEM']='1';os.environ.clear();os.environ.update(env)
out=Path('/private/tmp/ks-phase77-native-corrective2-20261019');m.run(root,out,binding,Path('/private/tmp/ks-go-cache'))
p=out/'binary.json';data=json.loads(p.read_text());data['source_mode']=binding['source_mode'];p.write_text(json.dumps(data,indent=2)+'\n')
expected=json.loads(Path('/private/tmp/ks-phase77-candidate-final-20261019/binary.json').read_text())['sha256'];assert data['sha256']==expected
print('final native binary matches actual runtime candidate',flush=True)
