import os,json,subprocess,importlib.util,hashlib
from pathlib import Path
root=Path('/Users/kevin/work/github/0xmhha/auto-coding/knowledge/knowledge-system');out=Path('/private/tmp/ks-phase77-candidate-final-20261019');out.mkdir()
spec=importlib.util.spec_from_file_location('owned',root/'scripts/run-wi4-target-subscription.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/local-reliability-v1/source-binding.json').read_text());names=set(old['source_sha256']);inventory=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.go'],cwd=root,text=True).splitlines();names.update(n for n in inventory if n.startswith(('cmd/','pkg/','internal/')))
current={n:m.sha((root/n).read_bytes())for n in sorted(names)};revision='7d5a5537c24a73a2a191d2f94b6243fb98c0d059';changes=[]
for n in current:
 r=subprocess.run(['git','show',revision+':'+n],cwd=root,capture_output=True)
 if r.returncode or m.sha(r.stdout)!=current[n]:changes.append(n)
binding=dict(base_revision=revision,source_mode='working_tree_9_bound_Go_changes',source_sha256=current,approved_input_sha256=old['approved_input_sha256'],changed_native_files=changes)
assert len(changes)==9 and all(n.endswith('.go')for n in changes)
m.write(out/'source-binding.json',binding)
go='/Users/kevin/.gvm/gos/go1.26.8/bin/go';env={k:os.environ[k]for k in ('HOME','USER','TMPDIR','LANG','LC_ALL')if k in os.environ};env.update(PATH=str(Path(go).parent)+':/usr/bin:/bin:/usr/sbin:/sbin',GOROOT='/Users/kevin/.gvm/gos/go1.26.8',GOTOOLCHAIN='local',GOWORK='off',GOPROXY='off',GOSUMDB='off',GOCACHE='/private/tmp/ks-go-cache',GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod')
r=m.command([go,'build','-o',str(out/'cks'),'./cmd/cks'],root,out/'build',env,900);assert r['exit_code']==0 and not r['remaining_live_group_members']
for n,h in{**current,**binding['approved_input_sha256']}.items():assert m.sha((root/n).read_bytes())==h
info=subprocess.check_output([go,'version','-m',str(out/'cks')],cwd=out,env=env);(out/'build-info.txt').write_bytes(info)
m.write(out/'binary.json',dict(sha256=m.sha((out/'cks').read_bytes()),source_revision=revision,source_mode=binding['source_mode'],source_binding_sha256=m.sha((out/'source-binding.json').read_bytes())))
print('candidate source files',len(current),'changed',changes,flush=True)
