package intent

import (
	"context"
	"errors"
	"fmt"
	"math"
	"sort"
	"strings"

	"go.uber.org/zap"

	"github.com/0xmhha/knowledge-system/internal/system/footprint"
	"github.com/0xmhha/knowledge-system/pkg/system/contract"
)

// DefaultUnknownThreshold is the cosine-similarity cutoff below which
// Classify returns IntentUnknown (composer falls back to broad fan-out).
// Calibrated 2026-07-09 against bge-m3 with the ticket-style anchor set:
// real bugfix/feature prompts score 0.57-0.82, off-topic chatter tops out
// near 0.53. 0.55 separates them with a small margin; 0.6 (the previous
// value) sent virtually every real prompt to Unknown.
const DefaultUnknownThreshold = 0.55

// Classification is the result of one Classify call.
type Classification struct {
	// Intent is the chosen Intent, or IntentUnknown when no anchor is
	// close enough.
	Intent contract.Intent
	// Confidence is the cosine similarity to the winning anchor
	// (1.0 = identical direction, 0 = orthogonal). For IntentUnknown
	// results this is the best similarity observed (still below the
	// threshold), useful for debugging.
	Confidence float64
	// BestAnchor is the text of the anchor that won. Empty when Intent
	// is IntentUnknown.
	BestAnchor string
}

// Option configures a Classifier.
type Option func(*Classifier)

// WithFootprint attaches a footprint.Logger; Classify emits a
// composer.intent_classified event on each call. Nil-safe.
func WithFootprint(fp *footprint.Logger) Option {
	return func(c *Classifier) { c.fp = fp }
}

// WithUnknownThreshold overrides the default cosine cutoff that maps
// "no close anchor" to IntentUnknown.
func WithUnknownThreshold(t float64) Option {
	return func(c *Classifier) { c.unknownThreshold = t }
}

// WithAnchors overrides the default anchor map. Useful for tests and for
// project-specific anchor injection (a project skill loader can add
// domain anchors).
func WithAnchors(anchors map[contract.Intent][]string) Option {
	return func(c *Classifier) { c.anchors = anchors }
}

// Classifier maps a vibe prompt to an Intent by comparing the prompt's
// embedding to a set of per-Intent anchor embeddings.
type Classifier struct {
	embedder         Embedder
	fp               *footprint.Logger
	anchors          map[contract.Intent][]string // raw anchors, set via option or default
	embedded         map[contract.Intent][]anchor // embedded at New() time
	unknownThreshold float64
}

type anchor struct {
	Text string
	Vec  []float32
}

// New constructs a Classifier and eagerly embeds every configured anchor.
// Failures during anchor embedding abort construction so callers see the
// problem at startup, not on the first user prompt.
func New(ctx context.Context, embedder Embedder, opts ...Option) (*Classifier, error) {
	if embedder == nil {
		return nil, errors.New("intent: nil embedder")
	}
	c := &Classifier{
		embedder:         embedder,
		anchors:          defaultAnchors,
		unknownThreshold: DefaultUnknownThreshold,
	}
	for _, opt := range opts {
		opt(c)
	}

	if err := validateAnchors(c.anchors); err != nil {
		return nil, err
	}
	if ctx == nil {
		return nil, errors.New("intent: nil context")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	c.embedded = make(map[contract.Intent][]anchor, len(c.anchors))
	if batch, ok := embedder.(BatchEmbedder); ok {
		if err := c.embedAnchorBatch(ctx, batch); err != nil {
			return nil, err
		}
		return c, nil
	}
	for intentVal, texts := range c.anchors {
		for _, text := range texts {
			vec, err := embedder.Embed(ctx, text)
			if err != nil {
				return nil, fmt.Errorf("intent: pre-embed anchor %q for %s: %w", text, intentVal, err)
			}
			c.embedded[intentVal] = append(c.embedded[intentVal], anchor{Text: text, Vec: vec})
		}
	}
	return c, nil
}

func (c *Classifier) embedAnchorBatch(ctx context.Context, batch BatchEmbedder) error {
	keys := make([]string, 0, len(c.anchors))
	for key := range c.anchors {
		keys = append(keys, string(key))
	}
	sort.Strings(keys)
	var texts []string
	var owners []contract.Intent
	for _, key := range keys {
		owner := contract.Intent(key)
		for _, text := range c.anchors[owner] {
			texts = append(texts, text)
			owners = append(owners, owner)
		}
	}
	if len(texts) == 0 {
		return nil
	}
	vecs, err := batch.EmbedBatch(ctx, append([]string(nil), texts...))
	if err != nil {
		return fmt.Errorf("intent: pre-embed anchor batch: %w", err)
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if len(vecs) != len(texts) {
		return fmt.Errorf("intent: pre-embed anchor batch returned %d vectors for %d texts", len(vecs), len(texts))
	}
	dim := len(vecs[0])
	for i, vec := range vecs {
		if dim == 0 || len(vec) != dim {
			return fmt.Errorf("intent: pre-embed anchor batch has inconsistent or empty dimension at %d", i)
		}
		for _, value := range vec {
			if math.IsNaN(float64(value)) || math.IsInf(float64(value), 0) {
				return fmt.Errorf("intent: pre-embed anchor batch has nonfinite vector at %d", i)
			}
		}
		c.embedded[owners[i]] = append(c.embedded[owners[i]], anchor{Text: texts[i], Vec: append([]float32(nil), vec...)})
	}
	return nil
}

// validateAnchors rejects anchor maps with structural problems before any
// embedder call is made:
//   - unknown contract.Intent values (typos, deleted enum members),
//   - empty anchor list for a declared Intent (would never match),
//   - empty / whitespace-only anchor text (would embed to noise).
//
// Runs before pre-embedding so failures surface without burning embedder
// quota on bad input.
func validateAnchors(m map[contract.Intent][]string) error {
	for intentVal, texts := range m {
		if !intentVal.IsValid() {
			return fmt.Errorf("intent: anchor map contains unknown Intent %q", intentVal)
		}
		if len(texts) == 0 {
			return fmt.Errorf("intent: anchor list for %s is empty", intentVal)
		}
		for i, t := range texts {
			if strings.TrimSpace(t) == "" {
				return fmt.Errorf("intent: anchor text for %s[%d] is empty or whitespace", intentVal, i)
			}
		}
	}
	return nil
}

// Classify embeds prompt and returns the Intent whose closest anchor has
// the highest cosine similarity, or IntentUnknown when the best similarity
// is below the threshold.
//
// Errors: empty prompt, embedder failure. Composer callers should fall
// back to IntentUnknown handling (broad fan-out) on error rather than
// aborting the whole pipeline.
func (c *Classifier) Classify(ctx context.Context, prompt string) (Classification, error) {
	if prompt == "" {
		return Classification{Intent: contract.IntentUnknown}, errors.New("intent: empty prompt")
	}

	promptVec, err := c.embedder.Embed(ctx, prompt)
	if err != nil {
		return Classification{Intent: contract.IntentUnknown}, fmt.Errorf("intent: embed prompt: %w", err)
	}

	bestIntent := contract.IntentUnknown
	bestSim := math.Inf(-1) // start at -inf so any real cosine wins on first pass
	bestAnchor := ""

	for intentVal, anchors := range c.embedded {
		for _, a := range anchors {
			sim := cosine(promptVec, a.Vec)
			if sim > bestSim {
				bestSim = sim
				bestIntent = intentVal
				bestAnchor = a.Text
			}
		}
	}

	// Normalize the "no anchors at all" edge case (would leave -inf).
	if math.IsInf(bestSim, -1) {
		bestSim = 0
	}

	below := bestSim < c.unknownThreshold
	result := Classification{
		Intent:     bestIntent,
		Confidence: bestSim,
		BestAnchor: bestAnchor,
	}
	if below {
		result.Intent = contract.IntentUnknown
		result.BestAnchor = ""
	}

	c.emitFootprint(ctx, result, below)
	return result, nil
}

func (c *Classifier) emitFootprint(ctx context.Context, r Classification, below bool) {
	if c.fp == nil {
		return
	}
	c.fp.Event(ctx, "composer.intent_classified",
		zap.String("intent", string(r.Intent)),
		zap.Float64("confidence", r.Confidence),
		zap.String("best_anchor", r.BestAnchor),
		zap.Bool("below_threshold", below),
	)
}

// cosine returns the cosine similarity of two equal-length vectors, or 0
// when either is empty, length-mismatched, or zero-magnitude.
func cosine(a, b []float32) float64 {
	if len(a) == 0 || len(a) != len(b) {
		return 0
	}
	var dot, magA, magB float64
	for i := range a {
		ai := float64(a[i])
		bi := float64(b[i])
		dot += ai * bi
		magA += ai * ai
		magB += bi * bi
	}
	if magA == 0 || magB == 0 {
		return 0
	}
	return dot / (math.Sqrt(magA) * math.Sqrt(magB))
}
