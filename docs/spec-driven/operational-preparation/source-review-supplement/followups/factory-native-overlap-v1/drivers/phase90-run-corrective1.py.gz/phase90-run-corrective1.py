import os,sys,json,subprocess,importlib.util,concurrent.futures,hashlib
from pathlib import Path
root=Path.cwd();work=Path('/private/tmp/ks-phase90-native-rpc-corrective1-20261020');work.mkdir();out=work/'evidence';out.mkdir();sys.path.insert(0,str(root/'scripts'));sys.path.insert(0,'/private/tmp');from phase90_instrument import instrument
s=importlib.util.spec_from_file_location('owner',root/'scripts/run-full-host-owner.py');mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod);m=mod.m
parent=Path('/private/tmp/ks-wi4-target-20261019/source');before=m.source_inventory(parent);status=m.git(parent,'status','--porcelain','--untracked-files=all');m.write(out/'original-before.json',before);(out/'original-status-before.txt').write_bytes(status)
bridge=Path('/private/tmp/phase90-native-rpc-bridge-corrective1.go').read_bytes();main=Path('/private/tmp/phase90-native-rpc-main.go').read_bytes();API='eth/downloader/api.go';BRIDGE='eth/downloader/ks_native_rpc_overlap.go';MAIN='cmd/ks-native-rpc-overlap/main.go'
roles=['ORIGINAL','CAND-A','CAND-B','MUT-REINTRO','MUT-EARLY'];unique=[r for r in roles if r!='MUT-REINTRO'];draft=root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/ticket-dev-gold-v1'
settings=json.loads(Path('/private/tmp/ks-wi4-target-20261019/dependency-plan.json').read_text())['task_environment'];settings.update(GOMODCACHE='/Users/kevin/.gvm/pkgsets/go1.26.8/global/pkg/mod',GOCACHE='/private/tmp/ks-phase90-go-build-cache')
env={k:os.environ[k]for k in ['HOME','USER','TMPDIR','LANG','LC_ALL']if k in os.environ};env.update(settings,PATH='/Users/kevin/.gvm/gos/go1.23.12/bin:/usr/bin:/bin:/usr/sbin:/sbin',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',PYTHONDONTWRITEBYTECODE='1');go='/Users/kevin/.gvm/gos/go1.23.12/bin/go'
slots=[dict(slot_id=r+'-'+v,candidate=r,variant=v,repetition=1)for r in roles for v in ['general','race']]
scope=dict(kind='actual_factory_loopback_peer_native60_broadcast_RPC_unsubscribe_callback_overlap_DEV',source_commit=m.COMMIT,knowledge_source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),planned_slots=slots,unique_build_roles=unique,alias_roles={'MUT-REINTRO':'ORIGINAL'},owned_nodes_per_slot=2,actual_source_sync_not_injected=True,native_timer_seconds=60,declared_gate='hold selected receiver native done-broadcast immediately before its actual unbuffered send; perform actual eth_unsubscribe and observe callback Err exit/method entry, then release',cancellation_route='same_session_eth_unsubscribe_true_not_connection_close',source_instrumentation='constructor identity, lifecycle, callback status/id/exit/defer, before-send scheduling gate; original timer/StartEvent/Progress untouched',independent_families=0,repetitions_per_role_profile=1,automatic_retries=0,original_five_or_full12_acceptance=False,formal_completed=0,independent_approved=0,freeze=None,execution_allowed=False,operational_nodes_started=0,LLM_calls=0,paid_calls=0,build_timeout=900,program_timeout=100,runtime_parallelism=2,bridge_sha256=m.sha(bridge),main_sha256=m.sha(main),driver_sha256=m.sha(Path(__file__).read_bytes()),instrumentation_sha256=m.sha(Path('/private/tmp/phase90-instrument.py').read_bytes()),environment=settings)
m.write(out/'SCOPE.json',scope);built={};expected=json.loads((root/'docs/spec-driven/operational-preparation/source-review-supplement/followups/wi4-target-subscription-v1/corrective/source-binding.json').read_text())['tracked']
for role in unique:
 q=out/'candidates'/role;q.mkdir(parents=True);src=work/('source-'+role)
 for label,argv,cwd in [('clone',['git','-c','core.hooksPath=/dev/null','clone','--shared','--no-checkout',str(parent),str(src)],work),('checkout',['git','-c','core.hooksPath=/dev/null','checkout','--detach',m.COMMIT],src)]:
  r=m.command(argv,cwd,q/label,env,60);assert r['exit_code']==0 and not r['remaining_live_group_members'],r
 baseline=m.source_inventory(src);assert baseline==expected and not m.git(src,'status','--porcelain');retained=(draft/'private/overlays'/(role+'.go.txt')).read_bytes();overlay,counts=instrument(retained,role)
 files=[(API,overlay),(BRIDGE,bridge),(MAIN,main)]
 for n,data in files:target=src/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 applied=dict(baseline);applied[API]=dict(mode=baseline[API]['mode'],sha256=m.sha(overlay));assert m.source_inventory(src)==applied
 m.write(q/'source-binding.json',dict(source_commit=m.COMMIT,base_tracked=baseline,applied_tracked=applied,additions={BRIDGE:m.sha(bridge),MAIN:m.sha(main)},retained_api_sha256=m.sha(retained),instrumented_api_sha256=m.sha(overlay),instrumentation_counts=counts,production_patch=False));m.write(q/'tree-binding.json',mod.tree_input(src,q,env,files));(q/'instrumented-api.go').write_bytes(overlay)
 bins={}
 for v in ['general','race']:
  binary=q/(v+'.program');r=m.command([go,'build']+(['-race']if v=='race'else[])+['-o',str(binary),'./cmd/ks-native-rpc-overlap'],src,q/('build-'+v),env,900);assert r['exit_code']==0 and not r['remaining_live_group_members'],r
  bins[v]=dict(path=str(binary),sha256=m.sha(binary.read_bytes()));(q/(v+'-build-info.txt')).write_bytes(subprocess.check_output([go,'version','-m',str(binary)],cwd=src,env=env));print('built '+role+' '+v,flush=True)
 m.write(q/'binaries.json',bins);built[role]=(src,bins,applied)
built['MUT-REINTRO']=built['ORIGINAL'];attempts=[]
def execute(slot):
 q=out/'slots'/slot['slot_id'];q.mkdir(parents=True);tmp=q/'tmp';tmp.mkdir();src,bins,applied=built[slot['candidate']];b=bins[slot['variant']];r=m.command([b['path']],src,q/'process',{**env,'TMPDIR':str(tmp),'KS_NATIVE_TRACE':str(q/'events.jsonl'),'KS_NATIVE_ROLE':slot['candidate']},100);r.update(slot,binary_sha256=b['sha256'],tmp_children_after=sorted(x.name for x in tmp.iterdir()));m.write(q/'receipt.json',r);print('slot '+slot['slot_id']+' exit '+str(r['exit_code']),flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for r in pool.map(execute,slots):attempts.append(r);m.write(out/'attempts.json',attempts)
for role in unique:
 src,bins,applied=built[role];assert m.source_inventory(src)==applied and (src/BRIDGE).read_bytes()==bridge and (src/MAIN).read_bytes()==main;assert all(m.sha(Path(b['path']).read_bytes())==b['sha256']for b in bins.values())
after=m.source_inventory(parent);m.write(out/'original-after.json',after);(out/'original-status-after.txt').write_bytes(m.git(parent,'status','--porcelain','--untracked-files=all'));assert before==after and status==m.git(parent,'status','--porcelain','--untracked-files=all')
m.write(out/'receipt.json',dict(planned=10,attempted=len(attempts),failed=sum(r['exit_code']!=0 for r in attempts),automatic_retries=0,source_preserved=True,full12_acceptance=False,formal_completed=0,independent_approved=0));print('native RPC actual-factory matrix finished',flush=True)
