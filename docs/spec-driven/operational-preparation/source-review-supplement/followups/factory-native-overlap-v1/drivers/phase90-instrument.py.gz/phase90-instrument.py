import subprocess
GOFMT='/Users/kevin/.gvm/gos/go1.23.12/bin/gofmt'
def instrument(raw,role):
 s=raw.decode();rules=[
 ('go api.eventLoop()','ksNativeCapture(api)\ngo api.eventLoop()'),
 ('syncSubscriptions[i] = struct{}{}','syncSubscriptions[i] = struct{}{}\nksNativeLifecycle(api,"install",i,syncSubscriptions)'),
 ('case <-checkTimer.C:','case <-checkTimer.C:\nksNativeLifecycle(api,"native_timer_fired",nil,nil)'),
 ('case StartEvent:','case StartEvent:\nksNativeLifecycle(api,"source_StartEvent_received",nil,nil)'),
 ('delete(syncSubscriptions, u.c)','ksNativeLifecycle(api,"before_delete",u.c,syncSubscriptions)\ndelete(syncSubscriptions,u.c)\nksNativeLifecycle(api,"after_delete",u.c,syncSubscriptions)'),
 ('close(u.uninstalled)','ksNativeLifecycle(api,"ack_close_begin",u.c,syncSubscriptions)\nclose(u.uninstalled)\nksNativeLifecycle(api,"ack_close_end",u.c,syncSubscriptions)'),
 ('c <- notification','ksNativeLifecycle(api,"native_send_begin_progress",c,syncSubscriptions)\nc <- notification\nksNativeLifecycle(api,"native_send_end_progress",c,syncSubscriptions)'),
 ('c <- false','ksNativeLifecycle(api,"native_send_begin_done",c,syncSubscriptions)\nc <- false\nksNativeLifecycle(api,"native_send_end_done",c,syncSubscriptions)'),
 ('i <- false','ksNativeLifecycle(api,"install_send_begin",i,syncSubscriptions)\ni <- false\nksNativeLifecycle(api,"install_send_end",i,syncSubscriptions)'),
 ('statuses := make(chan interface{})','statuses := make(chan interface{})\nksNativeCallback(api,"callback_status_created",statuses,rpcSub.ID)'),
 ('defer sub.Unsubscribe()','defer ksNativeCallback(api,"callback_returned",statuses,rpcSub.ID)\ndefer sub.Unsubscribe()'),
 ('case <-rpcSub.Err():','case <-rpcSub.Err():\nksNativeCallback(api,"callback_exit_rpc_error",statuses,rpcSub.ID)'),
 ('case <-notifier.Closed():','case <-notifier.Closed():\nksNativeCallback(api,"callback_exit_transport_closed",statuses,rpcSub.ID)'),
 ('func (s *SyncStatusSubscription) Unsubscribe() {','func (s *SyncStatusSubscription) Unsubscribe() {\nksNativeLifecycle(s.api,"method_entry",s.c,nil)\ndefer ksNativeLifecycle(s.api,"method_return",s.c,nil)'),
 ('case <-s.c:','case <-s.c:\nksNativeLifecycle(s.api,"method_status_received",s.c,nil)'),
 ('case <-req.uninstalled:','case <-req.uninstalled:\nksNativeLifecycle(s.api,"method_ack_observed",s.c,nil)')]
 counts={}
 for old,new in rules:
  count=s.count(old);expected=0 if role=='MUT-EARLY'and old in ['case <-s.c:','case <-req.uninstalled:'] else 2 if role=='CAND-A'and old=='case <-s.c:' else 1
  assert count==expected,(role,old,count,expected);counts[old]=count;s=s.replace(old,new)
 result=subprocess.check_output([GOFMT],input=s.encode());assert b'checkInterval     = time.Second * 60'in result
 return result,counts
