// Owned source-observation bridge. The pre-send gate deliberately orders cancellation.
package downloader

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/rpc"
	"os"
	"runtime"
	"sync"
	"time"
)

type nativeKey struct {
	api *DownloaderAPI
	c   chan interface{}
}
type nativeRecorder struct {
	mu                       sync.Mutex
	file                     *os.File
	path                     string
	start                    time.Time
	seq                      int
	apis                     map[*DownloaderAPI]int
	created                  map[*DownloaderAPI]time.Time
	channels                 map[nativeKey]int
	rpcids                   map[nativeKey]string
	counts                   map[nativeKey]map[string]int
	members                  map[nativeKey]bool
	selected                 nativeKey
	gateEntered, gateRelease chan struct{}
	gateSeen                 bool
	releaseOnce              sync.Once
}

var nr *nativeRecorder

func OwnedNativeInit(path string) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	nr = &nativeRecorder{file: f, path: path, start: time.Now(), apis: map[*DownloaderAPI]int{}, created: map[*DownloaderAPI]time.Time{}, channels: map[nativeKey]int{}, rpcids: map[nativeKey]string{}, counts: map[nativeKey]map[string]int{}, members: map[nativeKey]bool{}, gateEntered: make(chan struct{}), gateRelease: make(chan struct{})}
	return nil
}
func OwnedNativeFinish() {
	if nr != nil {
		_ = nr.file.Close()
	}
}
func nativeEmitLocked(api *DownloaderAPI, name string, c chan interface{}, owner bool, member bool, value interface{}) {
	r := nr
	k := nativeKey{api, c}
	if api != nil && r.apis[api] == 0 {
		r.apis[api] = len(r.apis) + 1
		r.created[api] = time.Now()
	}
	id := 0
	if c != nil {
		if r.channels[k] == 0 {
			r.channels[k] = len(r.channels) + 1
		}
		id = r.channels[k]
		if r.counts[k] == nil {
			r.counts[k] = map[string]int{}
		}
		r.counts[k][name]++
		if owner {
			r.members[k] = member
		}
	}
	age := int64(0)
	if api != nil {
		age = time.Since(r.created[api]).Nanoseconds()
	}
	r.seq++
	if e := json.NewEncoder(r.file).Encode(map[string]interface{}{"sequence": r.seq, "event": name, "elapsed_ns": time.Since(r.start).Nanoseconds(), "api_id": r.apis[api], "api_age_ns": age, "channel_id": id, "subscription_id": r.rpcids[k], "owner_map_observed": owner, "member": member, "value": value}); e != nil {
		panic(e)
	}
}
func ksNativeCapture(api *DownloaderAPI) {
	nr.mu.Lock()
	defer nr.mu.Unlock()
	nativeEmitLocked(api, "factory_API_created", nil, false, false, nil)
}
func ksNativeCallback(api *DownloaderAPI, name string, c chan interface{}, sid rpc.ID) {
	nr.mu.Lock()
	defer nr.mu.Unlock()
	nr.rpcids[nativeKey{api, c}] = string(sid)
	nativeEmitLocked(api, name, c, false, false, nil)
}
func ksNativeLifecycle(api *DownloaderAPI, name string, c chan interface{}, members map[chan interface{}]struct{}) {
	r := nr
	r.mu.Lock()
	_, member := members[c]
	nativeEmitLocked(api, name, c, members != nil, member, nil)
	wait := name == "native_send_begin_done" && nativeKey{api, c} == r.selected
	if wait && !r.gateSeen {
		r.gateSeen = true
		close(r.gateEntered)
	}
	r.mu.Unlock()
	if wait {
		<-r.gateRelease
	}
}
func nativeEmit(name string, value interface{}) {
	r := nr
	r.mu.Lock()
	defer r.mu.Unlock()
	nativeEmitLocked(r.selected.api, name, r.selected.c, false, false, value)
}
func nativeCount(name string) int {
	r := nr
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.counts[r.selected][name]
}
func nativeMember() bool { nr.mu.Lock(); defer nr.mu.Unlock(); return nr.members[nr.selected] }
func nativeUntil(p func() bool, limit time.Duration) error {
	end := time.Now().Add(limit)
	for time.Now().Before(end) {
		if p() {
			return nil
		}
		time.Sleep(time.Millisecond)
	}
	return fmt.Errorf("bounded native overlap observation did not complete")
}
func nativeRelease() {
	nr.releaseOnce.Do(func() { nativeEmit("native_gate_release", nil); close(nr.gateRelease) })
}
func nativeSnapshot(name string) error {
	b := make([]byte, 2<<20)
	n := runtime.Stack(b, true)
	if n == len(b) {
		return fmt.Errorf("truncated stack")
	}
	return os.WriteFile(nr.path+"."+name+".stack", b[:n], 0600)
}
func OwnedNativePrepare(d *Downloader, chain *core.BlockChain, mux *event.TypeMux, sid string) error {
	return nativeUntil(func() bool {
		r := nr
		r.mu.Lock()
		defer r.mu.Unlock()
		for api := range r.apis {
			if api.d != d || api.chain != chain || api.mux != mux {
				continue
			}
			for k, id := range r.rpcids {
				if k.api == api && id == sid && r.counts[k]["install"] == 1 {
					r.selected = k
					nativeEmitLocked(api, "selected_factory_subscription", k.c, false, false, map[string]interface{}{"same_downloader": true, "same_blockchain": true, "same_mux": true, "new_API_calls_from_probe": 0, "unbuffered_status_channel": cap(k.c) == 0, "subscription_id": sid})
					return true
				}
			}
		}
		return false
	}, 3*time.Second)
}
func nativeCleanup() error {
	nativeEmit("cleanup_begin", nil)
	nativeRelease()
	rescue := false
	if nativeCount("native_send_begin_done") > nativeCount("native_send_end_done") {
		rescue = true
		nativeEmit("owned_rescue_status_receive_begin", nil)
		select {
		case value := <-nr.selected.c:
			if value != false {
				return fmt.Errorf("unexpected owned cleanup payload: %v", value)
			}
		case <-time.After(2 * time.Second):
			return fmt.Errorf("owned native send cleanup stalled")
		}
		nativeEmit("owned_rescue_status_receive_end", nil)
	}
	if nativeCount("method_return") == 1 && nativeMember() {
		rescue = true
		nativeEmit("owned_rescue_manual_uninstall_begin", nil)
		req := uninstallSyncSubscriptionRequest{c: nr.selected.c, uninstalled: make(chan struct{})}
		select {
		case nr.selected.api.uninstallSyncSubscription <- &req:
		case <-time.After(2 * time.Second):
			return fmt.Errorf("owned cleanup uninstall not accepted")
		}
		select {
		case <-req.uninstalled:
		case <-time.After(2 * time.Second):
			return fmt.Errorf("owned cleanup real acknowledgement missing")
		}
		nativeEmit("owned_rescue_manual_uninstall_end", nil)
	}
	if e := nativeUntil(func() bool {
		return nativeCount("callback_returned") == 1 && nativeCount("method_return") == 1 && nativeCount("after_delete") == 1 && nativeCount("ack_close_end") == 1 && !nativeMember()
	}, 3*time.Second); e != nil {
		return e
	}
	nativeEmit("cleanup_end", map[string]interface{}{"rescue_used": rescue, "owner_member": nativeMember(), "callback_returned": nativeCount("callback_returned"), "method_return": nativeCount("method_return"), "real_owner_delete": nativeCount("after_delete"), "real_owner_ack": nativeCount("ack_close_end"), "fake_acknowledgements": 0})
	return nil
}
func OwnedNativeExercise(client *rpc.Client, sid, role string) (err error) {
	defer func() {
		if e := nativeCleanup(); e != nil {
			if err == nil {
				err = e
			} else {
				err = fmt.Errorf("%v; cleanup: %w", err, e)
			}
		}
	}()
	select {
	case <-nr.gateEntered:
	case <-time.After(75 * time.Second):
		return fmt.Errorf("original native timer never entered selected send gate")
	}
	nativeEmit("native_broadcast_gate_observed", map[string]interface{}{"native_timer_seconds": 60, "payload": false, "send_not_yet_offered": true, "declared_schedule_gate": true})
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	var ok bool
	if e := client.CallContext(ctx, &ok, "eth_unsubscribe", sid); e != nil || !ok {
		return fmt.Errorf("actual RPC unsubscribe: %v", e)
	}
	nativeEmit("actual_RPC_unsubscribe_true", map[string]interface{}{"subscription_id": sid, "same_client_session": true, "downstream_complete_not_inferred": true})
	if e := nativeUntil(func() bool { return nativeCount("callback_exit_rpc_error") == 1 && nativeCount("method_entry") == 1 }, 3*time.Second); e != nil {
		return e
	}
	nativeEmit("callback_exit_and_method_entered_before_gate_release", map[string]interface{}{"callback_exit_rpc_error": nativeCount("callback_exit_rpc_error"), "method_entry": nativeCount("method_entry"), "owner_delete": nativeCount("after_delete"), "ack": nativeCount("ack_close_end")})
	if e := nativeSnapshot("before-native-release"); e != nil {
		return e
	}
	nativeRelease()
	if role == "CAND-A" || role == "CAND-B" {
		if e := nativeUntil(func() bool { return nativeCount("callback_returned") == 1 && nativeCount("ack_close_end") == 1 }, 3*time.Second); e != nil {
			return e
		}
	} else {
		time.Sleep(300 * time.Millisecond)
	}
	if e := nativeSnapshot("before-rescue"); e != nil {
		return e
	}
	result := map[string]interface{}{"native_send_begin": nativeCount("native_send_begin_done"), "native_send_end": nativeCount("native_send_end_done"), "callback_exit_rpc_error": nativeCount("callback_exit_rpc_error"), "callback_exit_transport_closed": nativeCount("callback_exit_transport_closed"), "callback_returned": nativeCount("callback_returned"), "method_entry": nativeCount("method_entry"), "method_return": nativeCount("method_return"), "method_status_received": nativeCount("method_status_received"), "method_ack_observed": nativeCount("method_ack_observed"), "owner_delete": nativeCount("after_delete"), "owner_ack": nativeCount("ack_close_end"), "owner_member": nativeMember(), "rescue_started": false}
	nativeEmit("observation_frozen", result)
	fixed := role == "CAND-A" || role == "CAND-B"
	early := role == "MUT-EARLY"
	if nativeCount("native_send_begin_done") != 1 || nativeCount("callback_exit_rpc_error") != 1 || nativeCount("method_entry") != 1 {
		return fmt.Errorf("actual RPC/native route missing")
	}
	if fixed {
		if nativeCount("native_send_end_done") != 1 || nativeCount("method_status_received") != 1 || nativeCount("after_delete") != 1 || nativeCount("method_ack_observed") != 1 || nativeCount("method_return") != 1 || nativeCount("callback_returned") != 1 || nativeMember() {
			return fmt.Errorf("candidate did not drain real native send and await real owner acknowledgement")
		}
	} else {
		if nativeCount("native_send_end_done") != 0 || nativeCount("after_delete") != 0 || nativeCount("ack_close_end") != 0 || !nativeMember() {
			return fmt.Errorf("expected pre-rescue blocked owner missing")
		}
		if early {
			if nativeCount("method_return") != 1 || nativeCount("callback_returned") != 1 {
				return fmt.Errorf("early-return control did not return")
			}
		} else {
			if nativeCount("method_return") != 0 || nativeCount("callback_returned") != 0 {
				return fmt.Errorf("original paired wait unexpectedly returned")
			}
		}
	}
	return nil
}
