import sys,json,subprocess,shutil,gzip
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import factory_native_overlap as x
p=root/x.PACKET;assert not x.check(),x.check();pgids=set()
for source in [p/'actual',p/'initial']:
 for q in source.rglob('receipt.json.gz'):
  d=x.read(q)
  if isinstance(d,dict)and 'pgid'in d:pgids.add(d['pgid'])
rows=subprocess.check_output(['ps','-axo','pid=,pgid=,stat='],text=True).splitlines();live=[dict(pid=int(v[0]),pgid=int(v[1]),state=v[2])for row in rows if len(v:=row.split())==3 and int(v[1])in pgids and not v[2].startswith('Z')];assert not live,live
paths=[Path('/private/tmp/ks-phase90-go-build-cache'),Path('/private/tmp/ks-phase90-native-rpc-20261020'),Path('/private/tmp/ks-phase90-native-rpc-corrective1-20261020')]
before=subprocess.check_output(['df','-k','/private/tmp'],text=True);deleted=[]
for target in paths:
 assert target.parent==Path('/private/tmp')and target.name.startswith('ks-phase90-')and target.is_dir()
 size=int(subprocess.check_output(['du','-sk',str(target)],text=True).split()[0]);shutil.rmtree(target);deleted.append(dict(path=str(target),allocated_bytes_before=size*1024,removed=not target.exists()))
d=dict(kind='owned_native_overlap_cache_source_binary_cleanup_after_raw_evidence_hash_verification',owned_process_group_ids=sorted(pgids),remaining_live_owned_members=live,deleted=deleted,removed_allocated_bytes=sum(r['allocated_bytes_before']for r in deleted),all_targets_absent=all(not n.exists()for n in paths),before_df=before,after_df=subprocess.check_output(['df','-k','/private/tmp'],text=True),preserved=['original go-stablenet source checkout','knowledge datasets and pinned consumers','global application caches and shared module store','compressed successful and failed execution evidence/source fixtures'],sealed_evidence_verified_before_delete=True)
(p/'CLEANUP.json').write_text(json.dumps(d,indent=2)+'\n');x.seal(p);assert not x.check(),x.check();print(json.dumps(dict(removed_GiB=round(d['removed_allocated_bytes']/2**30,3),remaining_owned_processes=0,all_targets_absent=d['all_targets_absent'])))
