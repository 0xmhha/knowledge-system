import json,gzip,sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import factory_native_overlap as x
p=root/x.PACKET
actual=Path('/private/tmp/ks-phase90-native-rpc-corrective1-20261020/evidence');initial=Path('/private/tmp/ks-phase90-native-rpc-20261020/evidence')
def compress(src,target):target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(src.read_bytes(),mtime=0))
assert x.read(actual/'receipt.json')['attempted']==10 and x.read(actual/'receipt.json')['failed']==0
for label,folder in [('actual',actual),('initial',initial)]:
 for src in folder.rglob('*'):
  if src.is_file()and src.name!='live.json'and not src.name.endswith('.program'):
   compress(src,p/label/(str(src.relative_to(folder))+'.gz'))
for name in ['phase90-run.py','phase90-run-corrective1.py','phase90-instrument.py','phase90_instrument.py','phase90-native-rpc-bridge-initial.go','phase90-native-rpc-bridge-corrective1.go','phase90-native-rpc-main.go','phase90-driver.log','phase90-corrective1-driver.log']:
 compress(Path('/private/tmp')/name,p/'drivers'/(name+'.gz'))
spec=x.read(p/'SPEC.json');spec['attempt_history']=dict(initial='one invalid fixture compile before any runtime nodes: ack channel declared chan struct instead of source chan interface',corrective1='only cleanup request acknowledgement channel type corrected; fresh source clones, same declared ten slots; all raw attempts retained',automatic_retries=0,initial_runtime_nodes=0,valid_runtime_nodes=20);(p/'SPEC.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
summary=x.derive(p);(p/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');x.seal(p);errors=x.check();assert not errors,errors
print(json.dumps({k:v for k,v in summary.items()if k!='rows'},ensure_ascii=False))
