// Copyright 2015 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package downloader

import (
	"context"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/core"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/rpc"
)

// DownloaderAPI provides an API which gives information about the current
// synchronisation status. It offers only methods that operates on data that
// can be available to anyone without security risks.
type DownloaderAPI struct {
	d                         *Downloader
	chain                     *core.BlockChain
	mux                       *event.TypeMux
	installSyncSubscription   chan chan interface{}
	uninstallSyncSubscription chan *uninstallSyncSubscriptionRequest
}

// NewDownloaderAPI creates a new DownloaderAPI. The API has an internal event loop that
// listens for events from the downloader through the global event mux. In case it receives one of
// these events it broadcasts it to all syncing subscriptions that are installed through the
// installSyncSubscription channel.
func NewDownloaderAPI(d *Downloader, chain *core.BlockChain, m *event.TypeMux) *DownloaderAPI {
	api := &DownloaderAPI{
		d:                         d,
		chain:                     chain,
		mux:                       m,
		installSyncSubscription:   make(chan chan interface{}),
		uninstallSyncSubscription: make(chan *uninstallSyncSubscriptionRequest),
	}
	ksNativeCapture(api)
	go api.eventLoop()
	return api
}

// eventLoop runs a loop until the event mux closes. It will install and uninstall
// new sync subscriptions and broadcasts sync status updates to the installed sync
// subscriptions.
//
// The sync status pushed to subscriptions can be a stream like:
// >>> {Syncing: true, Progress: {...}}
// >>> {false}
//
// If the node is already synced up, then only a single event subscribers will
// receive is {false}.
func (api *DownloaderAPI) eventLoop() {
	var (
		sub               = api.mux.Subscribe(StartEvent{})
		syncSubscriptions = make(map[chan interface{}]struct{})
		checkInterval     = time.Second * 60
		checkTimer        = time.NewTimer(checkInterval)

		// status flags
		started bool
		done    bool

		getProgress = func() ethereum.SyncProgress {
			prog := api.d.Progress()
			if txProg, err := api.chain.TxIndexProgress(); err == nil {
				prog.TxIndexFinishedBlocks = txProg.Indexed
				prog.TxIndexRemainingBlocks = txProg.Remaining
			}
			return prog
		}
	)
	defer checkTimer.Stop()

	for {
		select {
		case i := <-api.installSyncSubscription:
			syncSubscriptions[i] = struct{}{}
			ksNativeLifecycle(api, "install", i, syncSubscriptions)
			if done {
				ksNativeLifecycle(api, "install_send_begin", i, syncSubscriptions)
				i <- false
				ksNativeLifecycle(api, "install_send_end", i, syncSubscriptions)
			}
		case u := <-api.uninstallSyncSubscription:
			ksNativeLifecycle(api, "before_delete", u.c, syncSubscriptions)
			delete(syncSubscriptions, u.c)
			ksNativeLifecycle(api, "after_delete", u.c, syncSubscriptions)
			ksNativeLifecycle(api, "ack_close_begin", u.c, syncSubscriptions)
			close(u.uninstalled)
			ksNativeLifecycle(api, "ack_close_end", u.c, syncSubscriptions)
		case event := <-sub.Chan():
			if event == nil {
				return
			}
			switch event.Data.(type) {
			case StartEvent:
				ksNativeLifecycle(api, "source_StartEvent_received", nil, nil)
				started = true
			}
		case <-checkTimer.C:
			ksNativeLifecycle(api, "native_timer_fired", nil, nil)
			if !started {
				checkTimer.Reset(checkInterval)
				continue
			}
			prog := getProgress()
			if !prog.Done() {
				notification := &SyncingResult{
					Syncing: true,
					Status:  prog,
				}
				for c := range syncSubscriptions {
					ksNativeLifecycle(api, "native_send_begin_progress", c, syncSubscriptions)
					c <- notification
					ksNativeLifecycle(api, "native_send_end_progress", c, syncSubscriptions)
				}
				checkTimer.Reset(checkInterval)
				continue
			}
			for c := range syncSubscriptions {
				ksNativeLifecycle(api, "native_send_begin_done", c, syncSubscriptions)
				c <- false
				ksNativeLifecycle(api, "native_send_end_done", c, syncSubscriptions)
			}
			done = true
		}
	}
}

// Syncing provides information when this nodes starts synchronising with the Ethereum network and when it's finished.
func (api *DownloaderAPI) Syncing(ctx context.Context) (*rpc.Subscription, error) {
	notifier, supported := rpc.NotifierFromContext(ctx)
	if !supported {
		return &rpc.Subscription{}, rpc.ErrNotificationsUnsupported
	}

	rpcSub := notifier.CreateSubscription()

	go func() {
		statuses := make(chan interface{})
		ksNativeCallback(api, "callback_status_created", statuses, rpcSub.ID)
		sub := api.SubscribeSyncStatus(statuses)
		defer ksNativeCallback(api, "callback_returned", statuses, rpcSub.ID)
		defer sub.Unsubscribe()

		for {
			select {
			case status := <-statuses:
				ksNativeCallback(api, "callback_status_received", statuses, rpcSub.ID)
				ksNativeCallback(api, "callback_notify_begin", statuses, rpcSub.ID)
				notifier.Notify(rpcSub.ID, status)
				ksNativeCallback(api, "callback_notify_end", statuses, rpcSub.ID)
			case <-rpcSub.Err():
				ksNativeCallback(api, "callback_exit_rpc_error", statuses, rpcSub.ID)
				return
			case <-notifier.Closed():
				ksNativeCallback(api, "callback_exit_transport_closed", statuses, rpcSub.ID)
				return
			}
		}
	}()

	return rpcSub, nil
}

// SyncingResult provides information about the current synchronisation status for this node.
type SyncingResult struct {
	Syncing bool                  `json:"syncing"`
	Status  ethereum.SyncProgress `json:"status"`
}

// uninstallSyncSubscriptionRequest uninstalls a syncing subscription in the API event loop.
type uninstallSyncSubscriptionRequest struct {
	c           chan interface{}
	uninstalled chan interface{}
}

// SyncStatusSubscription represents a syncing subscription.
type SyncStatusSubscription struct {
	api       *DownloaderAPI   // register subscription in event loop of this api instance
	c         chan interface{} // channel where events are broadcasted to
	unsubOnce sync.Once        // make sure unsubscribe logic is executed once
}

// Unsubscribe uninstalls the subscription from the DownloadAPI event loop.
// The status channel that was passed to subscribeSyncStatus isn't used anymore
// after this method returns.
func (s *SyncStatusSubscription) Unsubscribe() {
	ksNativeLifecycle(s.api, "method_entry", s.c, nil)
	defer ksNativeLifecycle(s.api, "method_return", s.c, nil)
	s.unsubOnce.Do(func() {})
}

// SubscribeSyncStatus creates a subscription that will broadcast new synchronisation updates.
// The given channel must receive interface values, the result can either.
func (api *DownloaderAPI) SubscribeSyncStatus(status chan interface{}) *SyncStatusSubscription {
	ksNativeLifecycle(api, "register_request", status, nil)
	api.installSyncSubscription <- status
	return &SyncStatusSubscription{api: api, c: status}
}
