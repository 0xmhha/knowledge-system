"""Archive a finished run into the packet: redact machine paths, gzip deterministically.

Usage: archive.py ADAPTER_CONFIG RUN_NAME PACKET_DIR

Binaries, owned Git indexes and per-slot temporary directories are not archived;
their hashes are already bound in binaries.json and receipts. Every file whose
bytes changed under redaction is listed with both digests in REDACTION.json.
"""
import gzip
import hashlib
import json
import os
import re
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter  # noqa: E402

SKIP_SUFFIXES = ('.program',)
SKIP_NAMES = ('owned-index',)
DRIVERS = ['generation_run.py', 'generation_instrument.py', 'ks_adapter.py', 'adapter_preflight.py', 'compile_probe.py',
           'archive.py', 'archive_checks.py', 'smoke.py', 'generation-bridge.go', 'generation-main.go']

# Locations outside the adapter map: the per-user temporary root and the bare
# account name that appears in the recorded environment.
TMP_LOCATION = re.compile(rb'/(?:private/)?var/folders/[^\s"\'\\\\:]+')


def scrub(data):
    data = TMP_LOCATION.sub(b'${TMPDIR}', data)
    user = os.environ.get('USER', '').encode()
    if user:
        data = data.replace(b'"' + user + b'"', b'"${USER}"').replace(b'\\"' + user + b'\\"', b'\\"${USER}\\"')
    return data


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(target, data):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise SystemExit('refusing to overwrite '+str(target))
    target.write_bytes(gzip.compress(data, mtime=0))


def main(config, run_name, packet):
    a = ks_adapter.Adapter(config)
    evidence = a.path('WORK_ROOT') / run_name / 'evidence'
    packet = Path(packet)
    redactions, skipped = [], []
    for source in sorted(evidence.rglob('*')):
        rel = source.relative_to(evidence)
        if not source.is_file():
            continue
        if source.suffix in SKIP_SUFFIXES or source.name in SKIP_NAMES or 'tmp' in rel.parts:
            skipped.append(dict(path=str(rel), sha256=sha(source.read_bytes())))
            continue
        data = source.read_bytes()
        archived = scrub(a.redact(data))
        if archived != data:
            redactions.append(dict(path=str(rel), raw_sha256=sha(data), archived_sha256=sha(archived)))
        put(packet / 'actual' / (str(rel) + '.gz'), archived)
    for name in DRIVERS:
        put(packet / 'drivers' / (name + '.gz'), (TOOLS / name).read_bytes())
    (packet / 'actual-REDACTION.json').write_text(json.dumps(dict(rule='machine locations replaced by ${PLACEHOLDER}; longest first; /private alias included',
                                                               placeholders=list(ks_adapter.PLACEHOLDERS), changed=redactions, not_archived=skipped), indent=2) + '\n')
    print('archived', run_name, 'redacted', len(redactions), 'not archived', len(skipped))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3])
