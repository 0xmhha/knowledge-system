"""Check that the adapter reproduces the retained phase-90 native inputs on this machine.

Nothing here builds or starts a node. It verifies the toolchain, the owned upstream
checkout, offline dependency resolution, and that the retained phase-90 drivers,
with only their machine paths remapped, produce the same instrumented sources and
Git build trees that the packet recorded.
"""
import difflib
import gzip
import importlib.util
import json
import shutil
import subprocess
import sys
import types
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter  # noqa: E402

P90 = 'docs/spec-driven/operational-preparation/source-review-supplement/followups/factory-native-overlap-v1'
SUBSCRIPTION = 'docs/spec-driven/operational-preparation/source-review-supplement/followups/wi4-target-subscription-v1'
OVERLAYS = 'docs/spec-driven/operational-preparation/source-review-supplement/followups/ticket-dev-gold-v1/private/overlays'
ROLES = ['ORIGINAL', 'CAND-A', 'CAND-B', 'MUT-EARLY']
NATIVE_PACKAGES = ['./eth/...', './node', './consensus/ethash', './core', './p2p', './params', './rpc']


def gz(path):
    return gzip.decompress(Path(path).read_bytes())


def load_helpers(ks):
    spec = importlib.util.spec_from_file_location('owned', ks / 'scripts/run-wi4-target-subscription.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def remap_instrument(adapter, raw):
    old = "GOFMT='/Users/kevin/.gvm/gos/go1.23.12/bin/gofmt'"
    if raw.count(old) != 1:
        raise AssertionError('retained instrument GOFMT anchor changed')
    return raw.replace(old, 'GOFMT=' + repr(adapter.gofmt))


def unified(name, before, after, adapter):
    lines = difflib.unified_diff(before.splitlines(True), after.splitlines(True), 'retained/' + name, 'adapted/' + name)
    return adapter.redact(''.join(lines))


def main(config, out):
    adapter = ks_adapter.Adapter(config)
    ks = adapter.path('KS_ROOT')
    m = load_helpers(ks)
    out.mkdir(parents=True)
    work = adapter.path('WORK_ROOT') / 'preflight-trees'
    if work.exists():
        raise SystemExit('owned preflight tree directory already exists')
    cache = adapter.path('WORK_ROOT') / 'preflight-go-cache'
    env = adapter.go_env(cache)
    checks = {}

    version = subprocess.check_output([adapter.go, 'version'], cwd=adapter.path('WORK_ROOT'), env=env, text=True).strip()
    checks['go_version'] = dict(output=adapter.redact(version), ok=version.split()[2] == ks_adapter.GO_VERSION)

    src = adapter.path('UPSTREAM_SOURCE')
    head = m.git(src, 'rev-parse', 'HEAD').decode().strip()
    dirty = m.git(src, 'status', '--porcelain', '--untracked-files=all')
    expected = json.loads((ks / SUBSCRIPTION / 'corrective/source-binding.json').read_text())['tracked']
    inventory = m.source_inventory(src)
    checks['upstream_source'] = dict(head=head, clean=not dirty, tracked_files=len(inventory),
                                     inventory_matches_retained=inventory == expected,
                                     ok=head == ks_adapter.COMMIT and not dirty and inventory == expected)

    listed = subprocess.run([adapter.go, 'list', '-deps'] + NATIVE_PACKAGES, cwd=src, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    checks['offline_dependencies'] = dict(exit_code=listed.returncode, packages=len(listed.stdout.splitlines()),
                                          stderr=adapter.redact(listed.stderr.decode())[-2000:], ok=listed.returncode == 0)

    retained_instrument = gz(ks / P90 / 'drivers/phase90-instrument.py.gz').decode()
    adapted_instrument = remap_instrument(adapter, retained_instrument)
    (out / 'phase90-instrument.adapter.diff').write_text(unified('phase90-instrument.py', retained_instrument, adapted_instrument, adapter))
    module = types.ModuleType('phase90_instrument_adapted')
    exec(compile(adapted_instrument, 'phase90-instrument.adapted', 'exec'), module.__dict__)

    bridge = gz(ks / P90 / 'drivers/phase90-native-rpc-bridge-corrective1.go.gz')
    native_main = gz(ks / P90 / 'drivers/phase90-native-rpc-main.go.gz')
    roles = {}
    work.mkdir(parents=True)
    for role in ROLES:
        recorded_source = json.loads(gz(ks / P90 / f'actual/candidates/{role}/source-binding.json.gz'))
        recorded_tree = json.loads(gz(ks / P90 / f'actual/candidates/{role}/tree-binding.json.gz'))
        retained = (ks / OVERLAYS / f'{role}.go.txt').read_bytes()
        overlay, counts = module.instrument(retained, role)
        clone = work / role
        subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', 'clone', '--quiet', '--shared', '--no-checkout', str(src), str(clone)],
                       env=env, check=True)
        q = work / (role + '-index')
        q.mkdir()
        files = [('eth/downloader/api.go', overlay),
                 ('eth/downloader/ks_native_rpc_overlap.go', bridge),
                 ('cmd/ks-native-rpc-overlap/main.go', native_main)]
        tree = tree_input(m, clone, q, env, files)
        roles[role] = dict(
            retained_overlay_sha256=m.sha(retained),
            retained_overlay_matches=m.sha(retained) == recorded_source['retained_api_sha256'],
            instrumented_api_sha256=m.sha(overlay),
            instrumented_api_matches=m.sha(overlay) == recorded_source['instrumented_api_sha256'],
            instrumentation_counts_match=counts == recorded_source['instrumentation_counts'],
            applied_project_tree=tree['project'], applied_project_tree_matches=tree['project'] == recorded_tree['applied_project_tree'],
            build_input_tree=tree['build'], build_input_tree_matches=tree['build'] == recorded_tree['build_input_tree'])
        roles[role]['ok'] = all(v for k, v in roles[role].items() if k.endswith('_matches'))
    checks['phase90_inputs_reproduced'] = dict(roles=roles, ok=all(r['ok'] for r in roles.values()))

    retained_driver = gz(ks / P90 / 'drivers/phase90-run-corrective1.py.gz').decode()
    (out / 'phase90-run-corrective1.location-map.json').write_text(json.dumps(
        dict(retained_driver_sha256=m.sha(retained_driver.encode()),
             hard_coded_locations=[dict(previous=p, replaced_by=r, occurrences=retained_driver.count(p.split('*')[0]))
                                   for p, r in ks_adapter.PREVIOUS_LOCATIONS],
             note='The retained driver is not re-executed; its locations are replaced by adapter placeholders in the new driver.'),
        indent=2) + '\n')

    shutil.rmtree(work)
    shutil.rmtree(cache, ignore_errors=True)
    result = dict(adapter=adapter.describe(), checks=checks, ok=all(c['ok'] for c in checks.values()),
                  nodes_started=0, builds=0, owned_trees_removed=not work.exists())
    (out / 'PREFLIGHT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print('adapter preflight:', 'PASS' if result['ok'] else 'FAIL')
    return 0 if result['ok'] else 1


def tree_input(m, src, q, env, files):
    local = {**env, 'GIT_INDEX_FILE': str(q / 'owned-index')}
    subprocess.run(['git', 'read-tree', ks_adapter.COMMIT], cwd=src, env=local, check=True, capture_output=True)
    project = None
    for name, data in files:
        oid = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], input=data, cwd=src, env=local).decode().strip()
        subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644,' + oid + ',' + name], cwd=src, env=local, check=True)
        if name == 'eth/downloader/api.go':
            project = subprocess.check_output(['git', 'write-tree'], cwd=src, env=local).decode().strip()
    build = subprocess.check_output(['git', 'write-tree'], cwd=src, env=local).decode().strip()
    return dict(project=project, build=build)


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1], Path(sys.argv[2])))
