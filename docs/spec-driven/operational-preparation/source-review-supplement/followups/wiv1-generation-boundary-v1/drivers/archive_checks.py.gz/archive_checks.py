"""Archive host verification, compile probes and smoke attempts into packet/checks with redaction."""
import gzip, hashlib, json, re, sys
from pathlib import Path
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import ks_adapter
a = ks_adapter.Adapter(sys.argv[1]); packet = Path(sys.argv[2]); host = Path(sys.argv[3]).resolve()
TMP = re.compile(r'/(?:private/)?var/folders/[^\s"\':]+')
def red(data):
    t = data.decode('utf-8', 'surrogateescape')
    for v in (str(host), str(host).replace('/private', '', 1)):
        t = t.replace(v, '${HOST_VERIFY_ROOT}')
    t = TMP.sub('${TMPDIR}', a.redact(t))
    return t.encode('utf-8', 'surrogateescape')
rows = []
def put(rel, src):
    data = src.read_bytes(); out = red(data); target = packet / 'checks' / (rel + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists(): raise SystemExit('refusing overwrite ' + rel)
    target.write_bytes(gzip.compress(out, mtime=0))
    rows.append(dict(path=rel, raw_sha256=hashlib.sha256(data).hexdigest(), archived_sha256=hashlib.sha256(out).hexdigest()))
for run in ('run1-go1.26.8', 'run2-go1.26.9'):
    d = host if run.startswith('run1') else host / 'run2'
    for n in ('env.txt', 'results.txt', 'build.log', 'lint.log', 'test-race.log', 'manager-test.log'):
        put(f'host/{run}/{n}', d / n)
w = a.path('WORK_ROOT')
for probe in ('out1', 'out2'):
    put(f'compile-probe/{probe}.json', w / 'probe' / probe / 'compile-probe.json')
for f in sorted((w / 'probe/smoke1').rglob('*')) + sorted((w / 'probe/smoke2').rglob('*')):
    if f.is_file() and f.suffix != '.program':
        put('smoke/' + str(f.relative_to(w / 'probe')), f)
(packet / 'checks-REDACTION.json').write_text(json.dumps(dict(rule='adapter placeholders, ${HOST_VERIFY_ROOT}, ${TMPDIR}', files=rows), indent=2) + '\n')
print('archived checks', len(rows))
